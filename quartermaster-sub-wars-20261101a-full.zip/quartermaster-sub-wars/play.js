"use strict"

/* globals data layout view player send_action send_query send_message game_cookie toast */

/*
 * 军需官 · 次要战场 —— 客户端
 *
 * 生命周期（由 /common/client.js 驱动）：
 *   window load  ->  build_map()      构建静态地图（只跑一次）
 *   state 消息   ->  on_update()      用 view 数据刷新（每次状态变化都调用）
 *
 * 注意：view 是 client.js 提供的全局变量，本文件不要重新声明。
 */

/*
 * ===== BEGIN send_action shim =====
 * 【2026-10-24】兼容"定制部署的 client.js 把 simple action 当数组"的 bug。
 *
 * 官方约定（见 /common/client.js）：
 *   view.actions[verb] === 1 / true / 字符串  ->  该动作可提交，参数任意（object/undefined）
 *   Array.isArray(view.actions[verb])         ->  才是"参数必须在候选列表里"
 *
 * 但某些定制部署把 send_action 简化成了无条件比较：
 *   if (view.actions[verb].includes(realnoun)) { ... }
 * 于是对值为 1 的动作（本模块绝大多数动作都是 1）会抛
 *   TypeError: view.actions[verb].includes is not a function
 * 异常发生在 send_message 之前 -> 请求根本发不出去 -> 表现为"点了没反应、
 * 一直卡在当前阶段"（实测：线上测试服开局弃牌，actions 全是 1，点确认即崩）。
 *
 * 本 shim：先走平台实现；若抛异常，按官方语义自行发送。
 * 在官方 client.js 上 try 分支直接成功，零副作用；本文件所有 send_action(...)
 * 调用（以及 client.js 内按名查找 send_action 的按钮处理器）都会经过这里。
 * ===== END send_action shim =====
 */
;(function () {
	if (typeof send_action !== 'function') return
	const _orig = send_action
	const _patched = function (verb, noun) {
		try {
			return _orig(verb, noun)
		} catch (e) {
			/* 落到下面的官方语义实现 */
		}
		try {
			const va = view && view.actions && view.actions[verb]
			if (!va) return false
			if (typeof send_message !== 'function') return false
			const arg = (noun === undefined) ? null : noun
			if (va === 1 || va === true || typeof va === 'string') {
				if (noun === undefined || noun === null || typeof noun === 'object') {
					view.actions = null
					send_message('action', [verb, arg, game_cookie])
					return true
				}
				return false
			}
			if (Array.isArray(va)) {
				const real = Array.isArray(noun) ? noun[0] : noun
				if (va.indexOf(real) < 0) return false
				view.actions = null
				send_message('action', [verb, arg, game_cookie])
				return true
			}
			return false
		} catch (e2) {
			try { toast('动作发送失败：' + (e2 && e2.message)) } catch (e3) {}
			return false
		}
	}
	try { window.send_action = _patched } catch (e) {}
})()

const MAP_W = 4835
const MAP_H = 1612

/* 阵营 -> 显示信息 */
const SIDE_INFO = {
	axis:   { role: "Axis",   label: "轴心国", cls: "axis" },
	allies: { role: "Allies", label: "同盟国", cls: "allies" },
}

const NATION_CLS = {
	"德国": "germany", "日本": "japan", "意大利": "italy",
	"英国": "uk", "法国": "france", "苏联": "ussr",
	"美国": "usa", "中国": "china",
}

const TYPE_LABEL = { army: "陆", navy: "海", air: "空", reserve: "预", base: "本" }

/* 客户端本地状态 */
const ui = {
	spaces: {},      // id -> element
	piece_el: {},    // piece id -> element
	marker_el: {},   // space id -> 计分标记胶囊 element
	/* 【2026-10-28 性能】card id -> 手牌卡元素：同一张牌复用上一帧的 DOM，
	 * 不再每帧 innerHTML="" 全量重建（卡图 probe + 事件绑定都在重建里） */
	hand_el: {},
	placed: {},      // piece id -> space id（上次渲染的位置，用于增量更新）
	built: false,
	selected: null,  // 当前选中的格位 id
	debug_mode: null, // null | "place" | "remove"
}

/* ============================================================
 * 一、静态地图构建（只跑一次）
 * ============================================================ */

function build_map() {
	if (ui.built)
		return

	const wrap = document.getElementById("spaces")
	if (!wrap)
		return

	/* 按 id 顺序遍历 data.spaces（索引 0 是占位空对象） */
	for (let s = 1; s < data.spaces.length; s++) {
		const sp = data.spaces[s]
		if (!sp || !sp.name)
			continue

		const box = layout[sp.name]
		if (!box) {
			console.warn("layout 缺少格位: " + sp.name)
			continue
		}
		const [x, y, w, h] = box

		const elt = document.createElement("div")
		elt.space_id = s
		elt.className = "space " + sp.terrain + markup_classes(sp)
		elt.style.left = x + "px"
		elt.style.top = y + "px"
		elt.style.width = w + "px"
		elt.style.height = h + "px"

		const name = document.createElement("div")
		name.className = "space_name"
		name.textContent = sp.name
		elt.appendChild(name)

		elt.addEventListener("click", on_click_space)
		elt.addEventListener("mouseenter", on_focus_space)
		elt.addEventListener("mouseleave", on_blur_space)

		wrap.appendChild(elt)
		ui.spaces[s] = elt
	}

	ui.built = true

	/* 构建完立刻渲染一次（view 可能已经到了） */
	update_map()
}

/*
 * 地块 CSS class。
 *
 * 【补给点走动态层】2026-09-23：
 * 不再直接读 sp.supply（那是地图标定的静态值），
 * 而是读 view.supply_by_id —— 它反映卡牌改过的当前状态，
 * 且区分"仅对某个阵营有效"。
 *
 * 返回：
 *   ""                 不是补给点
 *   " supply"          两个阵营都视为补给点
 *   " supply half"     仅某一阵营视为补给点（半星，视觉上要能看出区别）
 */
function markup_classes(sp) {
	let c = ""
	if (sp.home_base) c += " home_base"
	if (sp.strait) c += " strait"
	const d = view && view.supply_by_id && view.supply_by_id[sp.id]
	if (d) {
		const both = d.axis && d.allies
		c += both ? " supply" : " supply half"
	}
	return c
}

/* ============================================================
 * 二、每帧刷新（on_update 由 client.js 调用）
 * ============================================================ */

function on_update() {
	update_map()
}

function update_map() {
	if (!view)
		return
	if (!ui.built)
		build_map()

	update_side_info()
	update_phase_panel()
	update_pieces()
	/* 【2026-10-24】update_strait_line() 已移除：侧栏「海峡：」行删除（见该函数位置的注释） */
	update_supply_line()
	update_neutral_line()
	/* 补给点可被卡牌改变，class 要跟着刷新 */
	update_supply_classes()

	/*
	 * 顺序很重要：先渲染手牌，再渲染两个面板。
	 *
	 * update_hand_panel() 只负责重画手牌区 + 状态文字，它【不会】去更新
	 * #resource_box（那需要知道 pending_resource / air_move 的状态，
	 * 否则会互相递归）。而"点了手牌选代价"的反馈恰恰体现在面板上，
	 * 所以面板必须由这里统一刷新。
	 */
	update_hand_panel()
	update_response_panel()
	/* 【2026-10-24】敌方状态卡栏（永远暗置），紧跟响应卡栏刷新 */
	update_enemy_status()
	/* 【2026-10-24】日志面板折叠状态 + "N 条新"（平台先 update_log 再 on_update，顺序安全） */
	update_log_toggle()
	/* 【2026-10-04】响应卡效果需要玩家选择时的窗口（日本响应牌第二批） */
	update_response_choice_box()
	update_resource_box()
	/* 【2026-10-01】国家技能弃牌代价弹框（英国国家技能） */
	update_skill_discard_box()
	update_peek_box()
	update_echo_discard_box()
	update_event_done_button()
	update_air_box()
	update_violations()
	/* 【2026-10-20】卡牌"部分成功"的失败清单 -> toast（服务端下发，客户端只负责显示） */
	update_card_fail_toast()

	/* 【2026-10-22】行动记录抽屉 + 回退提议横幅 */
	update_history_ui()
	update_rollback_bar()

	/* 计分：分数面板 + 地图上的计分标记 */
	update_score_panel()
	update_markers()

	/*
	 * 手牌/目标可能因这次 view 更新而失效（如卡已被打出），
	 * 重新应用一次高亮，保证与实际可选项一致。
	 */
	if (pending_card)
		highlight_targets(pending_targets)
	/*
	 * 【2026-10-06】选部队（need:'piece'）的高亮：
	 * 算子 DOM 会随 view 刷新重建，类会丢 —— 与上面地区高亮同款，
	 * 每次刷新后重新贴一次。
	 */
	if (pending_event_targets && pending_event_targets.need === 'piece')
		highlight_event_pieces(pending_event_targets)
	/*
	 * 【2026-10-17】armed 增强卡多步选部队（need:'piece'，如 15406 选被进攻的敌方单位）
	 * 的高亮同样要【每帧重贴】：update_armed_offer_box 里虽调过 highlight_pieces，
	 * 但算子 DOM 会在 update_pieces() 重建后丢掉 .pickable 类，表现为
	 * "敌军能点选却不显示高亮"。这里与 event_piece 同款，在末尾按
	 * pending_armed.candidates 重贴一次，保证只要还在选部队步就一定有高亮。
	 */
	if (pending_armed && pending_armed.need === 'piece') {
		highlight_pieces(pending_armed.candidates || [], 'armed')
		/* 【2026-10-17】连同可空打的空白合法地块一起每帧重贴（15406） */
		if ((pending_armed.spaceCandidates || []).length)
			highlight_targets({ spaces: pending_armed.spaceCandidates.map(id => ({ id: id })) })
	}
	/*
	 * 【2026-10-17】armed 选地区(need:'space')步（如 17506 沉睡的巨人、15406 空打）
	 * 的地区高亮同样要【每帧重贴】：update_armed_offer_box 里虽调过 highlight_targets，
	 * 但地区 DOM 会随 view 刷新重建、丢 .target 类，表现为"能点选却不显示高亮"。
	 */
	if (pending_armed && pending_armed.need === 'space')
		highlight_targets({ spaces: (pending_armed.candidates || []).map(id => ({ id: id })) })
	/*
	 * 【2026-10-22】"收回部队"询问（view.pending_ask）的候选高亮同样要每帧重贴：
	 * 交互改成"点地图上的算子收回"之后，高亮丢了就等于没提示。
	 */
	if (view && view.pending_ask && (view.pending_ask.pieces || []).length)
		highlight_pieces(view.pending_ask.pieces.map(p => p.id), 'ask_remove')
	/*
	 * 【2026-10-07】战斗预算(event_budget)的目标高亮同样要【每帧重贴】。
	 *
	 * 高亮是【全局共享】的 DOM class（.target），任何面板的清理都会抹掉它；
	 * 预算面板在 render 中比某些"窗口消失即清理"的面板更早执行
	 * （见 update_pending_autobahn_box），高亮会被顺手清掉。
	 * 这里在 render 末尾按服务端下发的 targets 重新贴一次，
	 * 保证"只要预算还在，高亮就一定在"（与 pending_card 同款处理）。
	 *
	 * 【2026-10-20】升级为 reapply_all_highlights()：除战斗预算外，一并每帧重贴
	 * 【建设 / 状态卡选地 / 发起单位 / 让权委托】的候选 —— 这些此前没有重贴保护，
	 * 高亮活不过一帧（点击判定读内存变量故仍正确，于是"点击正确、高亮不正确"）。
	 */
	reapply_all_highlights()

	/*
	 * 【2026-10-23 兜底】响应卡决策框（发动 / 不发动）必须【最后】渲染。
	 *
	 * 它是阻塞式询问：玩家不表态，对局无法推进。而 update_map 里各
	 * update_*_box 共享同一个 #ask_box、且都无条件 render_ask_box ——
	 * 谁最后调用谁赢。同类事故已出现两次：
	 *   ① 服务端把"待发动"帧也下发给 view.response_choice，导致本框早退（已修）；
	 *   ② 17732 德国军事顾问的常驻提示框在它之后调用，把按钮整个盖掉（本次）。
	 * 故在渲染末尾再补一次，保证它永远在最上层。
	 * 本函数幂等：pending_trigger 为空时只清理自己的 ask_state。
	 */
	update_pending_trigger_box()
}

/*
 * 重新贴一次战斗预算的候选目标高亮（数据源：view.event_budget.targets，
 * 客户端不二次过滤，见 rtt-client-server-contract 第四节）。
 */
function reapply_event_budget_highlight() {
	const eb = view && view.event_budget
	if (!eb || !eb.can_finish || !eb.targets || !eb.targets.length) return
	/*
	 * 【2026-10-07 修复】预算机会用尽(remaining<=0)后，客户端地图高亮应清除。
	 * 此时预算卡仍未结算（eb 仍非空、targets 仍非空），若直接走下面的
	 * highlight_targets 会保留上一帧贴的 .target 高亮，造成"用完全部预算后
	 * 高亮不消失"的 bug。故在 remaining 耗尽时主动清掉地图高亮，
	 * 预算面板本身仍照常显示（剩余 0 次、可点「结束」）。
	 */
	if (eb.remaining <= 0) {
		clear_target_highlight()
		return
	}
	highlight_targets({ spaces: eb.targets.map(id => ({ id: id })) })
}

/*
 * 【2026-10-20】统一【每帧重贴】高亮：建设 / 发起战斗 / 委托 / 预算。
 *
 * 病根：highlight_targets() 内部会先 clear_target_highlight()【全清】再贴，
 * 而 update_map 每帧都会跑一次 —— 凡是不在"每帧重贴名单"里的候选，高亮活不过一帧；
 * 但点击判定读的是内存变量（status_build_cands、battle_flow、autobahn_cands…），
 * 与 DOM class 无关，于是表现为"【点击正确、高亮不正确】"。
 *
 * 修法：一个函数按【与 on_click_space 相同的优先级】重贴，命中第一个有候选的
 * 层级即贴并 return —— 保证高亮与点击判定同源，不会出现"高亮 A、点了走 B"。
 *
 * 层级顺序（对应 on_click_space 的分支先后）：
 *   1 armed 选地/选部队   2 状态卡选地   3 battle_flow（发起单位/目标）
 *   4 建设预算            5 让权委托     6 基本卡目标    7 战斗预算
 */
function reapply_all_highlights() {
	/* 1. 增强卡 armed：选部队(need:'piece') / 选地(need:'space')，含空打地块 */
	if (pending_armed && pending_armed.need === 'piece') {
		highlight_pieces(pending_armed.candidates || [], 'armed')
		if ((pending_armed.spaceCandidates || []).length)
			highlight_targets({ spaces: pending_armed.spaceCandidates.map(id => ({ id: id })) })
		return
	}
	if (pending_armed && pending_armed.need === 'space') {
		highlight_targets({ spaces: (pending_armed.candidates || []).map(id => ({ id: id })) })
		return
	}
	/* 2. 状态卡选地：建设候选 或 战斗候选（二者互斥，由 status_build_pending 区分） */
	if (status_act_phase === 'space') {
		if (status_build_pending && (status_build_cands || []).length)
			highlight_targets({
				spaces: status_build_cands.map(id => ({ id: id, reason: '建设候选' })),
			})
		else if ((status_battle_cands || []).length)
			highlight_targets({
				spaces: status_battle_cands.map(id => ({ id: id, reason: '可发起战斗的地区' })),
			})
		return
	}
	/*
	 * 3. 战斗流程 battle_flow：
	 *    from   -> 目标地区(.target) + 可发起算子(.pickable)，两者都要贴；
	 *    target -> 目标地区。
	 *    ⚠ 算子高亮是独立的 .pickable 类，highlight_targets 的全清不会抹掉它。
	 */
	if (battle_flow) {
		if (battle_flow.step === 'from') {
			if (pending_targets) highlight_targets(pending_targets)
			if ((battle_flow.initiators || []).length)
				highlight_pieces(battle_flow.initiators.map(u => u.id), 'initiator')
		} else if (battle_flow.step === 'target' && pending_targets) {
			highlight_targets(pending_targets)
		}
		return
	}
	/*
	 * 3.5 战区移动 pending_theater（2026-10-25）：每步候选由 RPC 现算并缓存，
	 *     这里每帧重贴【地区】与【算子】两类高亮 —— 步骤切换时缓存会被清空，
	 *     因此不会出现"上一步高亮残留"。
	 */
	if (view && view.pending_theater) {
		if ((theater_space_cands || []).length)
			highlight_targets({
				spaces: theater_space_cands.map(id => ({ id: id, reason: '建设候选' })),
			})
		if ((theater_piece_cands || []).length)
			highlight_pieces(theater_piece_cands, 'theater')
		return
	}
	/* 4. 建设预算 pending_autobahn（候选由 RPC 返回，已缓存到 autobahn_cands） */
	if (view && view.pending_autobahn) {
		if ((autobahn_cands || []).length)
			highlight_targets({
				spaces: autobahn_cands.map(id => ({ id: id, reason: '建设候选' })),
			})
		return
	}
	/* 4.5 17531 现购自运政策：已选兵种，按 targets 每帧重贴（只含该兵种合法地区） */
	if (view && view.us_merchant && view.us_merchant.step === 'space' &&
		(view.us_merchant.targets || []).length) {
		highlight_targets({
			spaces: view.us_merchant.targets.map(t => ({
				id: t.id, reason: '征召候选',
			})),
		})
		return
	}
	/* 5. 让权委托（候选随 view 下发，无需缓存） */
	const dg = (view && (view.su_build_delegate || view.uk_build_delegate ||
		view.us_china_build || view.us_theater_delegate)) || null
	if (dg && dg.candidates && dg.candidates.length) {
		highlight_targets({
			spaces: dg.candidates.map(c => ({ id: c.id, reason: '委托建设候选' })),
		})
		return
	}
	/* 6. 基本卡目标 */
	if (pending_card && pending_targets) { highlight_targets(pending_targets); return }
	/* 7. 战斗预算（保留既有逻辑，含 remaining<=0 时清除高亮） */
	reapply_event_budget_highlight()
}

/* 安全取元素并写文本 */
function set_text(id, text) {
	const el = document.getElementById(id)
	if (el)
		el.textContent = text
}

function update_side_info() {
	const side = view.side
	const info = SIDE_INFO[side]
	if (!info)
		return

	/* 本方高亮（client.js 会给 body 加 role class，这里补充显示） */
	if (!document.body.classList.contains(info.cls))
		document.body.classList.add(info.cls)

	/*
	 * 【2026-09-26 修正】"行动方"要读 view.active，不能读 view.side。
	 * view.side 恒等于【本方】阵营，旧写法会让两边都显示自己是行动方，
	 * 挂起等待时完全看不出时点变化。
	 */
	const act = (view.active === "Allies") ? "allies"
		: (view.active === "Axis" ? "axis" : null)
	const actInfo = SIDE_INFO[act] || info
	set_text("turn_line",
		`第 ${view.turn} 回合 · 行动方：${actInfo.label}` +
		(act && act !== side ? "（本方：" + info.label + "）" : "") +
		(view.phase ? " · " + view.phase : ""))
	const sc = view.score || { axis: 0, allies: 0 }
	set_text("axis_stat", sc.axis + " 分")
	set_text("allies_stat", sc.allies + " 分")

	/* 是否是本人的回合（client.js 之后还会按 view.actions 再设一次） */
	const header = document.querySelector("header")
	if (header)
		header.classList.toggle("your_turn", is_my_turn())
}

/*
 * 回合状态机面板：显示当前行动国 + 7 阶段进度条
 * 进度条上每个阶段一个小格，当前阶段高亮，已过的打勾。
 */
function update_phase_panel() {
	const nation = view.current_nation || "?"
	const idx = (view.phase_index || 1) - 1     /* 0-based */

	set_text("phase_nation", nation)
	set_text("phase_name", view.turn_phase_zh || "—")
	set_text("phase_step", (idx + 1) + "/" + (view.phase_total || 7))
	/*
	 * 挂起等待时把"在等谁"写在阶段面板上：
	 * 决策方有各自的询问框，另一方（waiting_for）只能靠这行知道时点。
	 */
	// 等待某一方（如让权经济战、战斗挂起）—— 顶部阶段栏提示
	const waitTxt = view.waiting_for ? view.waiting_for.text : ""
	// 17805 红色管弦乐队：决策方（德国）顶端提示其需选择
	const redTxt = (view.pending_red && view.pending_red.prompt) ? view.pending_red.prompt : ""
	// 17805 红色管弦乐队：非决策方（等待德国选择）顶端提示
	const suRedWaitTxt = (view.pending_red && !view.pending_red.prompt)
		? "等待【" + (view.pending_red.waiting_for || "德国") + "】选择《红色管弦乐队》" : ""
	const headTxt = suRedWaitTxt || waitTxt || redTxt
	set_text("phase_note", headTxt
		? headTxt + (view.phase_note ? " · " + view.phase_note : "")
		: (view.phase_note || ""))

	/* 阶段进度条 */
	const track = document.getElementById("phase_track")
	if (track && view.phases) {
		track.innerHTML = view.phases.map((p, i) => {
			const cls = i < idx ? "done" : (i === idx ? "cur" : "")
			const mark = i < idx ? "✓" : (i + 1)
			return '<span class="ph ' + cls + '" title="' + p.zh + '">' + mark + "</span>"
		}).join("")
	}

	/* 按钮只在轮到自己、且没有待决事项时可点（含 17510 挂起给英国期间禁用） */
	const btn = document.getElementById("btn_next_phase")
	if (btn) {
		/* 【2026-10-22】"收回部队"询问挂起期间也不能推进（须先移除或点「跳过」） */
		const askPending = !!(view && view.pending_ask)
		btn.disabled = !can_act_in_turn() || !!(view && view.us_political) || askPending
		if (btn.disabled && askPending)
			btn.title = "请先处理「收回部队」询问（选择要收回的部队，或点「跳过」）"
		else if (btn.disabled && view && view.us_political)
			btn.title = "等待【英国】选择《我们的政治哲学》的[响应卡]，期间不可推进阶段"
		else
			btn.title = ""
	}

	update_phase_buttons()
}

/*
 * 阶段相关的可选动作按钮（出牌三选一 / 资源再分配 / 收回询问开关）。
 */
function update_phase_buttons() {
	/* 见 can_act_in_turn：挂起等待期间不给回合内操作 */
	const mine = can_act_in_turn()

	const inPlay = mine && view.turn_phase === "play"
	const play = document.getElementById("play_choices")
	if (play)
		play.classList.toggle("hide", !inPlay)

	/* 弃牌阶段：打牌/弃牌 模式开关的可见性（离开弃牌阶段自动复位为弃牌模式） */
	const inDiscard = mine && view.turn_phase === "discard"
	if (!inDiscard && discard_playmode)
		discard_playmode = false

	/* 空军阶段："弃 1 张手牌调度空军"的入口按钮 */
	const air = document.getElementById("btn_air_move")
	if (air) {
		const inAir = mine && view.turn_phase === "airforce" && !view.my_air_done
		air.classList.toggle("hide", !(mine && view.turn_phase === "airforce"))
		air.disabled = !inAir
		air.textContent = view.my_air_done
			? "空军阶段：本回合已行动"
			: "调度空军…（弃 1 张手牌）"
	}

	/*
	 * 资源再分配按钮：每回合只能一次。
	 * 手牌不足 3 张、或本回合已用过 -> 禁用（并说明原因）。
	 */
	const res = document.getElementById("btn_resource")
	if (res) {
		const inResource = mine && view.turn_phase === "resource"
		const canSwap = inResource && view.can_resource_swap
		res.classList.toggle("hide", !inResource)
		res.disabled = !canSwap
		/*
		 * 【2026-10-24】文案去重：括号说明与 #phase_note 里那句
		 * 「英国 资源再分配阶段（可弃 3 张换 1 张基本卡，每回合一次）」完全重复，
		 * 侧栏窄、原文案还会折成两行，这里只留按钮名。
		 */
		res.textContent = view.rs_disabled_reason
			? view.rs_disabled_reason
			: (view.my_swap_count
				? "资源再分配：本回合已用"
				: "资源再分配…")
	}

	/*
	 * 先做状态清理，再更新 UI 文案 —— 顺序反了会让按钮显示上一次的
	 * 数量（曾经出现"已选 0 张"却写着"确认弃牌（1 张）"）。
	 */
	/* 阶段切换后清掉上一阶段的弃牌选择，避免误提交旧牌。
	 * 初始阶段：仅当"不在我方回合"时清（切到对方国家弃牌时，
	 * 把本方上一轮的旧选择清掉；我方自己弃牌途中要保留）。 */
	if (view.turn_phase !== "discard" && !(view.opening && is_my_turn()) && discard_pick.length)
		discard_pick = []

	/*
	 * 弃牌阶段的【确认弃牌】按钮：
	 * 只在弃牌阶段显示，选中 0 张时禁用。
	 */
	const confirmBtn = document.getElementById("btn_confirm_discard")
	if (confirmBtn) {
		const inOpening = !!view.opening && is_my_turn()
		const show = inDiscard || inOpening
		confirmBtn.classList.toggle("hide", !show)
		/*
		 * 【2026-10-23】弃牌阶段手牌超上限：服务端下发 pending_hand_limit.need，
		 * 必须【恰好】弃够 need 张（否则服务端拒绝）。
		 * 与开局布阵「必须恰好 3 张」同一套按钮文案，无新增控件。
		 */
		const _hl = view.pending_hand_limit
		const hlMine = !!(_hl && _hl.nation === view.my_nation && _hl.need > 0)
		if (inOpening) {
			confirmBtn.disabled = discard_pick.length !== 3
			confirmBtn.textContent = discard_pick.length === 3
				? "确认弃 3 张"
				: "请选 3 张（" + discard_pick.length + "/3）"
		} else if (inDiscard && hlMine) {
			confirmBtn.disabled = discard_pick.length !== _hl.need
			confirmBtn.textContent = discard_pick.length === _hl.need
				? "确认弃 " + _hl.need + " 张（达上限）"
				: "请选 " + _hl.need + " 张（" + discard_pick.length + "/" + _hl.need + "）"
		} else {
			confirmBtn.disabled = !discard_pick.length
			confirmBtn.textContent = discard_pick.length
				? "确认弃牌（" + discard_pick.length + " 张）"
				: "确认弃牌"
		}
	}

	/* 弃牌阶段：打牌模式切换按钮（仅在弃牌阶段、轮到本方时显示） */
	const dpBtn = document.getElementById("btn_discard_playmode")
	if (dpBtn) {
		dpBtn.classList.toggle("hide", !inDiscard)
		dpBtn.disabled = !inDiscard
		dpBtn.textContent = discard_playmode ? "退出打牌模式" : "打牌模式"
	}

	/* 资源弹框开着时，若已不可再换（阶段变了 / 已用过）则自动关闭 */
	if (pending_resource && !view.can_resource_swap) {
		pending_resource = null
		update_resource_box()
	}
	/*
	 * 【2026-10-01】国家技能弃牌弹框开着时，若窗口已消失
	 * （点了不使用 / 换阶段了 / 已用过），自动关掉并还原手牌区高亮。
	 */
	if (pending_skill_discard && !(view && view.national_skill)) {
		pending_skill_discard = null
		update_skill_discard_box()
	}
	update_ask_box_from_view()

	const toggle = document.getElementById("btn_toggle_ask")
	if (toggle) {
		toggle.textContent = "询问收回部队：" + (view.ask_remove ? "开" : "关")
		toggle.disabled = !mine
	}

	/*
	 * 出牌阶段每回合只能三选一：已行动后两个选项都禁用，
	 * 手牌区也据此禁用点击（见 update_hand_panel）。
	 */
	const done = !!view.my_play_done
	for (const id of ["btn_discard_mode", "btn_minus_score"]) {
		const b = document.getElementById(id)
		if (b)
			b.disabled = !mine || done
	}

	/* 资源再分配面板 / 询问面板随状态重建 */
	update_resource_box()
	update_ask_box_from_view()
	/* 防守方：战斗挂起时弹出"是否用空军代受"的询问 */
	update_pending_battle_box()
	/* 响应卡挂起：持有方弹"发动 / 不发动"询问 */
	update_pending_trigger_box()
	/* 经济战挂起：受击方依次弹"损耗 / 移除海军"询问 */
	update_pending_econ_box()
	/* 战斗预算(event_budget)面板：独立于 ask_box，展示剩余机会/目标/结束按钮 */
	update_event_budget_box()
	/* 【2026-10-21 方案 B】事件卡分步执行机的步骤边界面板（下一步 / 待处理窗口） */
	update_event_step_box()
	/* 【2026-10-18】17851 天王星行动：重复选择菜单 */
	update_uranus_box()
	/* 【2026-10-18】17852 罗科索夫斯基：选牌打出状态卡 */
	update_status_play_box()
	/* 17817 进攻是最好的防守 + 17850 大清洗 联动面板 */
	update_su_17817_box()
	/* 高速公路（15228）：玩家在地图逐一选择建设位置 */
	update_pending_autobahn_box()
	/* 【2026-10-25】战区移动（17532）：分步状态机面板（移除 → 建海军 → 建陆军） */
	update_pending_theater_box()
	/* 【2026-10-25】15328 破译恩尼格码：英国回合开始时的延迟窗口 */
	update_uk_enigma_box()
	/* 多步脚本卡（15229/15239/14503）：牌堆 / 手牌 / 暗牌 的选牌框 */
	update_pending_script_box()
	/* 国家技能：★卡结算后的机会窗口 */
	update_national_skill_box()
	/* 【2026-10-01】"打出XX后…"型增强卡：手牌机会窗口（优先级低于上面各框） */
	update_armed_offer_box()
	/* 【2026-10-19 重构】17805 红色管弦乐队：德国二选一（通用 ask_box；苏联选卡/是否使用走 armed_offer 通用 UI） */
	update_su_red_delegate_box()
	/* 【2026-10-06】《气球炸弹》结算后的可选窗口（回手 / 弃牌） */
	update_balloon_box()
	/* 【2026-10-08】17721 钢铁条约：德国可打出 1 张状态卡的委托提示框 */
	update_it_delegate_box()
	/* 【2026-10-08】17729 卡佩里尼：轴心依次链提示框 */
	update_italy_chain_box()
	/* 【2026-10-08】16703 罗马尼亚铁卫团：德国弃牌摸牌提示框 */
	update_italy_german_draw_box()
	/* 【2026-10-08】17732 德国军事顾问：借用德国状态卡选择框 */
	update_italy_borrow_box()
	/* 【2026-10-10】17553 抗日义勇军：让权日本弃牌提示框 */
	update_us_japan_box()
	/* 【2026-10-10】16304 中国远征军：让权美国选相邻地区（高亮地图） */
	update_us_china_box()
	/* 【2026-10-10】17526 民主兵工厂：让权英国建设（高亮地图） */
	update_uk_build_box()
	/* 【2026-10-10】17529 摩尔曼斯克运输船队：让权苏联建设（高亮地图） */
	update_su_build_box()
	/* 【2026-10-10】17537 美国人民同情中国：美国帮中国征召（高亮地图） */
	update_us_china_build()
	/* 【2026-10-10】17532 战区移动：美国移除己方棋子 + 建设（高亮地图/棋子） */
	update_us_theater_box()
	/* 【2026-10-10】17528/17531/17535 美国事件卡挂起项 */
	update_us_replay()
	/* 【2026-10-20】17528 重打接手：牌已回手牌 + 拿到免费额外打出权 */
	update_us_replay_armed()
	/* 【2026-10-17】17513 战时生产委员会：选状态卡重置 */
	update_us_wartime_box()
	update_us_merchant()
	update_delegate_box()
	/* 【2026-10-12】17510 我们的政治哲学：英国弃牌堆选响应卡打出（挂起给英国，卡图选择） */
	update_us_political_box()
	/* 【2026-10-10】17555 大萧条的余波：结束中立奖励按钮 */
	update_us_depression_box()
	/* 【2026-10-15】17555 大萧条的余波 ①：打出事件/状态卡后强制自选弃 1 张手牌 */
	update_us_depression_discard_box()
	/* 桌面状态卡渲染（含可触发高亮） */
	update_table_status()
	/*
	 * 【2026-09-30 德国增强】
	 *   - update_pending_echo_box：15214 战术革新 两步选牌（弃桌状态卡 / 免费打状态卡）
	 * 【2026-10-12】15215 卓越规划的置顶/置底已并入通用 update_peek_box
	 *   （原 update_deck_inspect_box 与其并存会双弹框，已删除）。
	 */
	update_pending_echo_box()
}

/* 出牌阶段②：进入"弃 1 张手牌"模式（再点手牌即弃置） */
let discard_mode = false

/*
 * 弃牌阶段：被"框住"选中的手牌（实体牌 id 列表）。
 * 点卡切换选中，最后点侧栏【确认弃牌】一次性提交。
 */
let discard_pick = []

/*
 * 【2026-10-24】提交前确认服务端真的授权了该动作。
 *
 * 平台 common/client.js 的 send_action 会先查 view.actions[verb]：
 * 没有登记就【静默 return false】——不发请求、也不报错。
 * 旧代码在这之后照样 toast「已提交」并把选择清空，于是线上表现为
 * "开局选了 3 张、点确认、界面毫无变化、一直卡在初始阶段"，
 * 而本地（role 恰好正确、actions 有登记）完全正常。
 *
 * 这里显式拦下并给出 actions / block_reason，把静默失败变成看得见的原因。
 */
function action_allowed(name) {
	const a = view && view.actions
	return !!(a && a[name])
}
function action_reject_text(name) {
	const a = (view && view.actions) || null
	const keys = a ? Object.keys(a).join(",") : "null"
	return "服务端未授权 " + name + "（actions=" + keys + "）；原因：" +
		((view && view.block_reason) || "未知")
}

/* 确认弃掉当前选中的所有手牌 */
function confirm_discard() {
	if (view.opening) {
		if (!is_my_turn()) {
			toast("初始阶段：等待【" + view.opening.current_nation + "】弃 3 张，本方暂不可操作")
			return
		}
		if (discard_pick.length !== 3) {
			toast("初始阶段：必须恰好选 3 张弃牌")
			return
		}
		if (!action_allowed("opening_discard")) {
			toast(action_reject_text("opening_discard"))
			return
		}
		send_action("opening_discard", { cards: discard_pick.slice() })
		toast("已提交弃 3 张")
		discard_pick = []
		update_hand_panel()
		update_phase_buttons()
		return
	}
	if (view.turn_phase !== "discard") {
		toast("只有弃牌阶段才能主动弃牌")
		return
	}
	if (!discard_pick.length) {
		toast("请先点手牌选择要弃置的牌")
		return
	}
	if (!action_allowed("discard_in_discard_phase")) {
		toast(action_reject_text("discard_in_discard_phase"))
		return
	}
	send_action("discard_in_discard_phase", { cards: discard_pick.slice() })
	toast("已弃置 " + discard_pick.length + " 张手牌")
	discard_pick = []
	update_hand_panel()
	update_phase_buttons()
}

function toggle_discard_mode() {
	discard_mode = !discard_mode
	toast(discard_mode ? "请点要弃置的手牌（Esc 取消）" : "已退出弃牌模式")
	update_hand_panel()
}

/* 出牌阶段③：减 1 分 */
function do_minus_score() {
	send_action("minus_score", {})
}

/* Esc / 右键时也退出弃牌模式 */
function cancel_discard_mode() {
	if (!discard_mode)
		return
	discard_mode = false
	update_hand_panel()
}

/* 弃牌阶段：打牌/弃牌 模式开关（默认 false = 弃牌模式，点手牌框选弃置） */
let discard_playmode = false

function toggle_discard_playmode() {
	discard_playmode = !discard_playmode
	toast(discard_playmode
		? "打牌模式：点【可打出】的时点卡即打出（再点按钮退出）"
		: "已退出打牌模式，回到弃牌框选")
	update_hand_panel()
	update_phase_buttons()
}

function cancel_discard_playmode() {
	if (!discard_playmode)
		return
	discard_playmode = false
	update_hand_panel()
}

/*
 * 是否轮到本方（RTT 把 player 设成 role 名）。
 *
 * 【2026-09-26 修正】旧写法拿 view.side（= 本方阵营，恒等于自己的阵营）
 * 和自己的阵营比，结果【永远为 true】——于是就算挂在等对方表态，
 * 顶栏依旧显示本方回合、按钮也照常可点（点了才被服务端拒）。
 *
 * 正确口径是比 view.active（服务端的操作权归属）：
 * 战斗/响应挂起时服务端会把 active 临时让给"该表态的那一方"，
 * 所以这里会自动变成 false，界面即切到"等待对方行动"。
 */
function is_my_turn() {
	const a = view && view.active
	if (!a || !player)
		return false
	if (a === player)
		return true
	/* 兼容 "Both" / 数组（其它模块可能这么写） */
	return a === "Both" || (Array.isArray(a) && a.indexOf(player) >= 0)
}

/*
 * 本方当前能否执行"回合内操作"（推进阶段 / 出牌 / 弃牌 / 调度 / 减分…）。
 *
 * 挂起时即便操作权让给了本方，也【只能】回答那一个待决事项，
 * 不能顺手打牌或推进阶段 —— 否则等对方代受的英国界面上
 * 会冒出德国的"出牌阶段三选一"按钮。
 */
function can_act_in_turn() {
	return is_my_turn() && !view.opening && !view.pending_battle &&
		!view.pending_trigger && !view.pending_econ && !view.pending_uranus && !view.pending_status_play && !view.pending_autobahn &&
		!view.pending_script && !view.pending_armed_delegate &&
		!(view.delegate && (view.delegate.mode === 'order' || view.delegate.mode === 'german_draw')) &&
		!(view.italy_borrow && view.italy_borrow.pending) &&
		/* 17553 让权日本期间：双方都不能顺手做回合内操作 */
		!view.us_japan_delegate &&
		/* 17526/17529 让权英国/苏联建设期间：被让权方只能回答该建设事项 */
		!view.uk_build_delegate && !view.su_build_delegate &&
		/* 17537 美国帮中国征召期间：美国只能回答该事项 */
		!view.us_china_build &&
		/* 17532 战区移动期间：美国只能回答该事项 */
		!view.us_theater_delegate &&
		/* 17528/17531/17535 美国事件卡挂起期间：只能回答对应事项 */
		!view.us_replay && !view.us_merchant && !view.us_wartime && !(view.delegate && view.delegate.mode === 'single') &&
		/* 17510 我们的政治哲学：美国选英国弃牌堆响应卡期间 */
		!view.us_political
	}

/* 推进阶段 */
function do_next_phase() {
	send_action("next_phase", {})
}

/* ---------------- 手牌渲染 ---------------- */

/*
 * 手牌渲染（仿 PoG：卡用真实卡图，悬停放大到 #tooltip）
 *
 * 手牌上限 7（HAND_LIMIT）：
 *   · 上限内   -> 正常显示
 *   · 超过上限 -> 面板标题显示红色 "（超出 N 张，弃牌阶段将弃到 7）"
 */
const HAND_LIMIT = 7

/*
 * 卡图 URL。
 *
 * 【2026-10-22 素材转 WebP】cards/ 下原 PNG 每张 ~400 KB（384x576 RGBA），
 * 转 WebP q85 后 ~38 KB，总体 172.4 MB -> 17.0 MB（省 90%，实测卡面小字清晰）。
 * 转换脚本：tools/optimize_images.py（原 png 保留作母版，发布包排除）。
 *
 * 因此：cards.js 的 img 字段仍是 "xxx.png"（只当文件名基用，不改 446 处），
 * 这里统一把扩展名换成 .webp。扩展名变了 = 天然破缓存，无需 ?v=。
 */
const CARD_IMG_EXT = ".webp"

function card_image_url(c) {
	if (!c || !c.img)
		return null
	return "cards/" + String(c.img).replace(/\.png$/i, "") + CARD_IMG_EXT
}

/* 建一张卡元素（卡图优先，缺图则回落为文字卡） */
function build_card_elt(c) {
	const d = document.createElement("div")
	d.className = "card t-" + c.type
	d.card = c

	const url = card_image_url(c)
	if (url)
		d.style.backgroundImage = "url(" + JSON.stringify(url) + ")"

	/* 回落层：卡图加载失败或缺失时显示文字 */
	const fb = document.createElement("div")
	fb.className = "card_fallback"
	const nm = document.createElement("div")
	nm.className = "card_name"
	nm.textContent = c.name
	const ty = document.createElement("div")
	ty.className = "card_type"
	ty.textContent = (view.card_types && view.card_types[c.type]
		? view.card_types[c.type].zh : c.type)
	fb.append(nm, ty)
	d.appendChild(fb)

	/* 卡图存在时隐藏文字回落层（onerror 时再显示） */
	if (url) {
		fb.style.display = "none"
		const probe = new Image()
		probe.onerror = () => { fb.style.display = "" }
		probe.src = url
	}

	d.title = c.name + "\n" + (view.card_types && view.card_types[c.type]
		? view.card_types[c.type].zh : c.type) + "\n" + c.text
	/*
	 * 【2026-10-28 性能】记住"原始"标题：手牌元素改为复用之后，
	 * 置灰原因（hr.reason）会写进 title，恢复可用时必须能还原回原始文案
	 * （以前每帧重建元素，天然还原）。
	 */
	d.__base_title = d.title

	/* 悬停：在 #tooltip 显示放大卡图（仿 PoG） */
	d.addEventListener("mouseenter", () => on_focus_card(d.__card))
	d.addEventListener("mouseleave", on_blur_card)

	/*
	 * ---- 点击处理 ----
	 *
	 * 关键教训：卡片的点击行为【不能】在渲染时算好存进闭包。
	 *
	 * 之前把 `d.__act = () => {...}` 在 update_hand_panel() 里赋值，
	 * 结果踩了坑：资源再分配要先 `send_query('deck_basics')` 走一个
	 * 网络往返，返回前 on_update 又重绘了一次手牌区 —— 那时
	 * pending_resource 还是 null，于是 __act 被写成"请先点按钮"的提示，
	 * 之后即便面板打开了，卡片也不会再重绘，__act 就永远是那句废话，
	 * 表现为"资源再分配选不中手牌"。
	 *
	 * 现在改为：只在元素上标记【是哪张牌】（d.__card），
	 * 点击时再调用 on_click_hand_card() 现算当前该做什么。
	 */
	d.__card = c
	/*
	 * 【2026-10-28 性能】点击/悬停一律取元素上的 __card，而不是闭包里的 c：
	 * 手牌元素现在是复用的，牌对象每帧由服务端重新下发，
	 * 闭包里的 c 会变成"上一帧的旧对象"，而 __card 每帧都刷新。
	 */
	d.addEventListener("click", (ev) => {
		ev.stopPropagation()
		on_click_hand_card(d.__card, d)
	})

	return d
}

/*
 * 桌面响应卡可视化（2026-09-25）
 *   遍历 view.table_responses（仅本方、已暴露卡面）画正面卡；
 *   再按 view.table_responses_opponent_count 画对应数量的背面卡（对方暗置）。
 *   与 build_card_elt 不同：这些卡【只展示】，不挂“打出”点击。
 */
/*
 * 【2026-10-22 卡背分国家颜色·方案 B】
 * 国名 -> CSS 后缀（.card.back-de / -uk / -jp / -su / -it / -us / -fr / -cn）。
 * 拿不到国名时回落阵营色（back-axis / back-allies），再不行就是默认深蓝。
 */
const NATION_BACK_KEY = {
	"德国": "de", "英国": "uk", "日本": "jp", "苏联": "su",
	"意大利": "it", "美国": "us", "法国": "fr", "中国": "cn",
}
function response_back_class(meta) {
	if (!meta) return ""
	const k = NATION_BACK_KEY[meta.nation]
	if (k) return " back-" + k
	if (meta.owner_side === "axis") return " back-axis"
	if (meta.owner_side === "allies") return " back-allies"
	return ""
}

function build_response_card_elt(c, faceUp, meta) {
	const d = document.createElement("div")
	if (faceUp && c) {
		d.className = "card t-" + (c.type || "RESPONSE")
		const url = card_image_url(c)      /* 【2026-10-22】统一走 webp */
		if (url)
			d.style.backgroundImage = "url(" + JSON.stringify(url) + ")"
		const fb = document.createElement("div")
		fb.className = "card_fallback"
		const nm = document.createElement("div")
		nm.className = "card_name"
		nm.textContent = c.name
		const ty = document.createElement("div")
		ty.className = "card_type"
		ty.textContent = (view.card_types && view.card_types[c.type]
			? view.card_types[c.type].zh : (c.type || "响应"))
		fb.append(nm, ty)
		d.appendChild(fb)
		if (url) {
			fb.style.display = "none"
			const probe = new Image()
			probe.onerror = () => { fb.style.display = "" }
			probe.src = url
		}
		d.title = c.name + "\n" + ty.textContent + "\n" + (c.text || "")
		d.addEventListener("mouseenter", () => on_focus_card(c))
		d.addEventListener("mouseleave", on_blur_card)
	} else {
		d.className = "card back" + response_back_class(meta)
		d.title = (meta && meta.nation)
			? ("对方响应卡（背面向上 · " + meta.nation + "）")
			: "对方响应卡（背面向上）"
	}
	return d
}

function update_response_panel() {
	const box = document.getElementById("response_cards")
	const note = document.getElementById("response_note")
	if (!box)
		return
	box.innerHTML = ""

	const own = (view.table_responses || [])
	/*
	 * 【2026-10-22】对手背面逐张带 nation（服务端只给元数据）；
	 * 旧服务端没有该字段时，按数量退回"无国籍"的统一样式。
	 */
	const opp = view.table_responses_opponent
		|| new Array(view.table_responses_opponent_count || 0).fill(null)

	for (const c of own)
		box.appendChild(build_response_card_elt(c, true))
	for (const o of opp)
		box.appendChild(build_response_card_elt(null, false, o))

	if (note)
		note.textContent = "（本方 " + own.length + " · 对方 " + opp.length + "）"

	if (!own.length && !opp.length)
		box.innerHTML = '<div class="hand_empty">（桌面暂无响应卡）</div>'
}

/*
 * 【2026-10-24 玩家口径】敌方状态卡栏 —— **卡面可见、永远不可操作**。
 *
 * 与"桌面状态卡"同款渲染（复用 build_response_card_elt，正面卡图 + 悬停放大），
 * 但一律套 .ts-disabled 灰置（灰度 + 降亮度），并且【不绑 onclick】：
 * 服务端 table_status_opponent 也不下发 ready / ready_reason / cost_*，
 * 所以不存在"点了能发动"的路径 —— 与手牌在非本方回合的灰置体验一致。
 */
function update_enemy_status() {
	const box = document.getElementById("enemy_status_cards")
	const note = document.getElementById("enemy_status_note")
	if (!box)
		return
	const opp = view.table_status_opponent || []
	box.innerHTML = ""
	for (const c of opp) {
		const el = build_response_card_elt({
			id: c.card,
			name: c.name,
			img: c.img,
			text: c.text || c.desc || '',
			type: 'STATUS',
		}, true)
		el.classList.add('es-card', 'ts-disabled')
		el.setAttribute('data-card', c.card)

		/* 角标：明确这是敌方的、且不可操作 */
		const b = document.createElement('div')
		b.className = 'ts-badge gray'
		b.textContent = '敌方'
		el.appendChild(b)

		el.title = c.name +
			'\n' + (c.text || c.desc || '') +
			'\n（敌方 · ' + (c.nation || '') + '，不可操作）'
		/* 刻意不绑 onclick：敌方状态卡不能由本方发动 */
		box.appendChild(el)
	}
	if (note)
		note.textContent = opp.length ? ("（对方 " + opp.length + " 张）") : ""
	if (!opp.length)
		box.innerHTML = '<div class="hand_empty">（对方桌面暂无状态卡）</div>'
}

/*
 * 手牌点击的唯一入口：按【点击那一刻】的状态决定行为。
 * 顺序即优先级（资源再分配的选代价 > 空军调度选代价 > 平时出牌）。
 */
/*
 * ============================================================
 * 打牌的阶段限制（与 rules.js 的 check_phase_for_card 保持一致）
 *
 *   ① 出牌阶段：打 1 张（增强卡除外，它不占名额）
 *   ② 其他阶段：只允许【卡面有特殊说明】的卡
 *   ③ 增强卡(EFFECT)：按时点打出（CARD_TRIGGERS），
 *      不是"任何阶段都能打"（2026-09-25 修正）
 * ============================================================
 */

/* 增强卡：type 判断（置灰逻辑里已不单独用它跳过，保留供 has_phase_note 等复用） */
function is_enhance_card(c) {
	return !!c && c.type === "EFFECT"
}

/*
 * 兼容保留：旧逻辑里"按时机打出"的三种卡。
 * 现在只有增强卡真正不受阶段限制，其余仍按卡面说明判定。
 */
function is_timing_card(c) {
	return !!c && (c.type === "RESPONSE" || c.type === "EFFECT" || c.type === "STATUS")
}

/* 《空军力量》：卡面说明限定其只能在空军阶段使用 */
function is_airforce_only(c) {
	return !!c && c.name === "空军力量"
}

/* 卡面文本里是否点了阶段名 */
const PHASE_NAME_RE = /(资源再分配|出牌阶段|空军阶段|补给阶段|计分阶段|弃牌阶段|摸牌阶段)/

/* 卡面是否针对某阶段作了特殊说明（不传 phaseZh 则只要提到阶段名即可） */
function has_phase_note(c, phaseZh) {
	if (!c || !c.text || !PHASE_NAME_RE.test(c.text))
		return false
	return phaseZh ? c.text.indexOf(phaseZh) >= 0 : true
}

/* 当前阶段的中文名（用于提示文案） */
const PHASE_ZH = {
	resource: "资源再分配阶段",
	play: "出牌阶段",
	airforce: "空军阶段",
	supply: "补给阶段",
	scoring: "计分阶段",
	discard: "弃牌阶段",
	draw: "摸牌阶段",
}

/*
 * 【2026-09-28 修正】阶段 key -> 卡面关键词（has_phase_note 的第二参）。
 * 与 rules.js 的 PHASE_KEYWORD【必须保持一致】（pitfalls 通用教训 3）。
 *
 * 注意措辞差异：卡面写的是「资源再分配」（不带"阶段"），
 * 而 PHASE_ZH.resource 是「资源再分配阶段」—— 不能拿 PHASE_ZH 去匹配。
 *
 * 用途：判定"卡面是否【针对当前阶段】写了说明"。
 * 不指定的话，只要卡面出现任意阶段名就被放行，
 * 会让 15345/15338 这类把「出牌阶段」当【触发代价】描述的状态卡
 * 在任何阶段都显示为可打出（彩色）—— 这是 bug。
 */
const PHASE_KEYWORD = {
	resource: "资源再分配",
	play: "出牌阶段",
	airforce: "空军阶段",
	supply: "补给阶段",
	scoring: "计分阶段",
	discard: "弃牌阶段",
	draw: "摸牌阶段",
}

/*
 * 【2026-09-28 玩家口径】卡面【打出/执行时机】的声明。
 * 必须与 rules.js 的 PHASE_DECL_RE / PHASE_NAME_TO_KEY 完全一致（同源）。
 *
 * 判据为什么是"开始时/结束时"：卡面提到阶段名有两种语义——
 *   ① 打出时机：「计分阶段**开始时**：在<北非>征召陆军…」(14923)
 *      -> 只能在计分阶段打出，出牌阶段不行
 *   ② 被动结算：「计分阶段：<加拿大>…获得1分」(15340)
 *      -> 打出时机仍是出牌阶段，只是效果在计分阶段结算
 * 不区分的话，② 类状态卡会被错误地限制成"只能在计分阶段打出"。
 */
const PHASE_DECL_RE =
	/(资源再分配|出牌阶段|空军阶段|补给阶段|计分阶段|弃牌阶段|摸牌阶段)\s*(?:开始时|结束时)/
const PHASE_NAME_TO_KEY = {
	"资源再分配": "resource",
	"出牌阶段": "play",
	"空军阶段": "airforce",
	"补给阶段": "supply",
	"计分阶段": "scoring",
	"弃牌阶段": "discard",
	"摸牌阶段": "draw",
}

/* 卡面声明的【打出/执行阶段】key；无声明返回 null */
function declared_phase_of(c) {
	if (!c || !c.text) return null
	const m = c.text.match(PHASE_DECL_RE)
	if (!m) return null
	return PHASE_NAME_TO_KEY[m[1]] || null
}

/*
 * 【2026-09-30】额外打出 —— 德国事件卡「可打出 1 张手牌 / 1 张[北方行动] /
 * 1 张以此法抽到的牌」。
 *
 * 服务端把它做成 game.extra_play（view.extra_play），只记【权利】不替玩家选牌：
 * 出牌阶段那一次正常执行完后，还能【再】打一张，日志里记为"因《XX》的额外打出"。
 *
 * filter 与 rules.js 的 extra_play_allows 必须保持一致（pitfalls R3 同源原则）：
 *   hand  —— 任意手牌
 *   north —— 卡面带 [北方行动] 的牌
 *   drawn —— view.extra_play.cards 指定的那些（《战略规划》抽到的）
 */
const NORTH_OPS_FACES = ["15211", "15220", "15224", "15241", "15249"]

function extra_play_allows_card(c) {
	const ep = view && view.extra_play
	if (!ep || !c) return false
	const face = String(c.card_id || c.id)
	if (ep.filter === "north") return NORTH_OPS_FACES.indexOf(face) >= 0
	if (ep.filter === "drawn")
		return Array.isArray(ep.cards) && ep.cards.indexOf(c.id) >= 0
	/*
	 * 【2026-10-21】17528《广阔的资源》重打：只此【指定实例那一张】可额外打出。
	 * 与 drawn 同款（ep.cards 存实例 id，c.id 也是实例 id，直接比）。
	 * 缺这个分支会落到末尾 return true —— 每张牌都挂"额外打出"角标。
	 */
	if (ep.filter === "card")
		return Array.isArray(ep.cards) && ep.cards.indexOf(c.id) >= 0
	/* 【2026-09-30】国家技能：只能额外打出【状态卡】 */
	if (ep.filter === "status") return c.type === "STATUS"
	/* 【2026-10-01】英国国家技能：事件牌或状态牌 */
	if (ep.filter === "event_status") return c.type === "STATUS" || c.type === "EVENT"
	if (ep.filter === "status_response") return c.type === "STATUS" || c.type === "RESPONSE"
	/* 【2026-10-07】意大利国家技能：状态卡或经济战卡 */
	if (ep.filter === "status_econ") return c.type === "STATUS" || c.type === "ECON"
	/* 【2026-10-08】日本国家技能：响应牌 */
	if (ep.filter === "response") return c.type === "RESPONSE"
	/* 【2026-10-10】17542 空中堡垒：轰炸行动 */
	if (ep.filter === "bombing") return c.type === "EVENT" && (c.text || "").indexOf("轰炸行动") >= 0
	return true
}

/* 额外打出的提示文案（给面板 / toast 用） */
function extra_play_hint() {
	const ep = view && view.extra_play
	if (!ep) return ""
	if (ep.filter === "north") return "可额外打出 1 张[北方行动]"
	if (ep.filter === "drawn") return "可额外打出 1 张刚刚抽到的牌"
	/* 【2026-10-21】17528 重打：只此一张 */
	if (ep.filter === "card") return "可额外打出 1 张指定牌（不占名额）"
	if (ep.filter === "status") return "可额外打出 1 张状态卡（国家技能，不占名额）"
	if (ep.filter === "event_status") return "可额外打出 1 张事件牌或状态牌（国家技能，不占名额）"
	if (ep.filter === "status_response") return "可额外打出 1 张状态卡或响应牌（国家技能，不占名额）"
	if (ep.filter === "status_econ") return "可额外打出 1 张状态卡或经济战卡（国家技能，不占名额）"
	if (ep.filter === "response") return "可额外打出 1 张响应牌（国家技能，不占名额）"
	if (ep.filter === "bombing") return "可额外打出 1 张[轰炸行动]牌（不占名额）"
	return "可额外打出 1 张手牌"
}

/* ============================================================
 * 【2026-10-01】"打出XX后…"型增强卡的手牌机会窗口
 *
 * 事件发生后（含"英国 15329 拦截经济战之后"），服务端扫【手牌】，
 * 若手上有匹配的增强卡（如《G7e 鱼雷》），给出 view.armed_offer。
 * 这里弹 ask 框：每张候选卡一个"打出"按钮 + "不打出"。
 *
 * 卡【仍留在手牌】，点了才真正打出（服务端 use_armed_offer 才移除+结算）。
 *
 * 优先级：本框【最低】—— 只有更高优先级的框（响应/战斗/经济战/脚本/
 * 国家技能…）都【没有】占用 ask_box 时才渲染，避免互相覆盖
 * （pitfalls：#ask_box 争抢）。
 * ============================================================ */
/*
 * 【2026-10-06】《气球炸弹》结算后的可选窗口（与 national_skill/armed_offer 同款可选窗口）。
 * 服务端 view.balloon 仅在窗口归属方为可见，客户端只判断其是否存在。
 * 结算绑定：弃 3 张手牌（条件/代价，走通用弃牌 UI）→ 本卡回手（效果）。二者一次完成，可整体跳过。
 */
function update_balloon_box() {
	const b = view && view.balloon
	if (!b) {
		if (ask_state && ask_state.kind === 'balloon') {
			ask_state = null
			render_ask_box(null, null, null)
		}
		return
	}
	const opt = []
	opt.push({
		label: b.can_pay ? '弃 3 张手牌 → 回手本卡' : '弃 3 张手牌（手牌不足，不可用）',
		cls: b.can_pay ? 'primary' : 'disabled',
		onClick: () => {
			if (!b.can_pay) return
			ask_state = null
			render_ask_box(null, null, null)
			start_one_step_picker({ need: 3, min: 3, source_name: '气球炸弹·弃3回手', submit_action: 'balloon_discard' })
		},
	})
	opt.push({
		label: '完成',
		cls: 'ghost',
		onClick: () => {
			ask_state = null
			render_ask_box(null, null, null)
			send_action('balloon_done', {})
		},
	})
	ask_state = { kind: 'balloon' }
	render_ask_box('气球炸弹（可选）',
		'获得 1 分。可弃 3 张手牌，将本卡回手（可跳过）', opt)
}

/* 【2026-10-08】17721 钢铁条约：意大利打出响应卡后，德国可打出 1 张状态卡。
 * 此处渲染提示框 + "放弃"按钮（放弃则控制权立即归还意大利）。 */
function update_it_delegate_box() {
	const d = (view && view.delegate && view.delegate.mode === 'chain') ? (view.it_delegate || view.delegate) : null
	if (!d) {
		/* 窗口消失：若当前 ask 是 it_delegate，关闭它 */
		if (ask_state && ask_state.kind === 'it_delegate') {
			ask_state = null
			render_ask_box(null, null, null)
		}
		return
	}
	const opt = [{
		label: '放弃状态卡打出（归还意大利）',
		cls: 'ghost',
		onClick: () => {
			ask_state = null
			render_ask_box(null, null, null)
			send_action('event_delegate_decline', {})
		},
	}]
	ask_state = { kind: 'it_delegate' }
	render_ask_box('钢铁条约（德国可打出状态卡）',
		'德国可额外打出 1 张状态卡；打出后控制权归还意大利。', opt)
}

/* 本帧已贴过的卡佩里尼卡面（card_id）；换牌或收起时重置，避免重复贴/漏贴 */
let italy_chain_shown_card = null

/* 【2026-10-08】17729 卡佩里尼：轴心依次链提示框。
 * 当前待处置国抽到一张牌，玩家选：打出(基本卡)/置牌堆顶/留弃牌堆。 */
function update_italy_chain_box() {
	const ch = (view && view.delegate && view.delegate.mode === 'order') ? (view.italy_chain || view.delegate) : null
	/*
	 * 【2026-10-22 修复·17729 "置于牌堆顶 / 留在弃牌堆"点了没反应】
	 * 有响应窗口在等表态时，服务端会拒绝一切非响应动作 —— 此时必须把 17729 的
	 * 选择框收起来（否则玩家连点、误以为卡死；日志里能连点 6 次全是空动作）。
	 * 响应结算完服务端会续跑链，选择框自动重开。
	 */
	if (view && (view.response_pending || (ch && ch.waiting_response))) {
		if (ask_state && (ask_state.kind === 'italy_chain' || ask_state.kind === 'italy_chain_sub')) {
			ask_state = null
			italy_chain_shown_card = null
			render_ask_box(null, null, null)
		}
		return
	}
	if (!ch || !ch.pickedCard) {
		/* 框收起 -> 清掉"已贴过"的标记，下次重新贴 */
		italy_chain_shown_card = null
		if (ask_state && ask_state.kind === 'italy_chain') {
			ask_state = null
			render_ask_box(null, null, null)
		}
		if (ask_state && ask_state.kind === 'italy_chain_sub') {
			ask_state = null
			render_ask_box(null, null, null)
		}
		return
	}
	const pc = ch.pickedCard
	if (ch.sub) {
		/*
		 * 【2026-10-22 修复·《空军力量》经 17729 打出没有生效】
		 * 旧实现只提示"点地图"，提交的只有 {space}；《空军力量》必需的三选一 mode
		 * 无处可选，服务端拿不到 mode -> 卡打出了但毫无效果（玩家反馈）。
		 * 改为复用【真实出牌】的 start_basic_card 流程：
		 *   · 《空军力量》-> 既有 show_mode_chooser（部署 / 夺取制空权 / 调度）
		 *   · 发起陆战/海战 -> 既有战斗两步流程（选发起单位）
		 * 最终提交由 submit_basic_card 路由到 resolve_italy_play（与租借法案同范式）。
		 */
		const cid = pc.card_id || pc.id
		/* 每帧重贴路由（提交后 cancel_basic_card 会清掉它，但链还没推进时仍应保持） */
		italy_chain_active = ch.pickedNation || pc.nation || null
		if (italy_chain_sub_started !== cid) {
			italy_chain_sub_started = cid
			start_basic_card({ id: cid, card_id: cid, name: pc.name, type: pc.type })
		}
		ask_state = { kind: 'italy_chain_sub' }
		render_ask_box('卡佩里尼：打出《' + pc.name + '》',
			pending_card
				? '请按提示选择模式/目标（与平时打出该基本卡完全一致）。'
				: '请在地图上点击一个合法位置来打出该基本卡。', [
				{ label: '放弃打出（留弃牌堆）', cls: 'ghost', onClick: () => {
					ask_state = null
					render_ask_box(null, null, null)
					cancel_basic_card()
					send_action('resolve_italy_chain', { choice: 'discard' })
				} },
			])
		return
	}
	/* 不在打出子状态：清掉链打牌的临时态，避免误路由后续普通出牌 */
	italy_chain_active = null
	italy_chain_sub_started = null
	const opt = [
		{ label: '置于牌堆顶', cls: 'primary', onClick: () => {
			ask_state = null; render_ask_box(null, null, null)
			send_action('resolve_italy_chain', { choice: 'decktop' })
		} },
		{ label: '留在弃牌堆', cls: 'ghost', onClick: () => {
			ask_state = null; render_ask_box(null, null, null)
			send_action('resolve_italy_chain', { choice: 'discard' })
		} },
	]
	if (pc.playable) {
		opt.unshift({ label: '打出（免费）', cls: 'primary', onClick: () => {
			ask_state = null; render_ask_box(null, null, null)
			send_action('resolve_italy_chain', { choice: 'play' })
		} })
	}
	ask_state = { kind: 'italy_chain' }
	render_ask_box('卡佩里尼 UIT 24：你抽到《' + pc.name + '》',
		'友方玩家依次检视抽到的牌。选择处置方式：' +
			(pc.playable ? '可打出（基本卡）/置顶/弃置。' : '该牌非基本卡，仅可置顶/弃置。'),
		opt)
	/*
	 * 【2026-10-27】显示【具体卡面】。
	 *
	 * render_box_into 的 title/text 走 textContent（纯文本，放不了图），
	 * 所以卡面单独作为一个 DOM 节点追加进 #ask_box：
	 *   · build_card_elt 是现成的（卡图优先 + 缺图回落文字 + 悬停放大）；
	 *   · render_box_into 重建时会 innerHTML="" 清空，下一帧自然会重新追加，
	 *     不会叠加（这里只在"本帧还没贴过这张牌"时贴一次，避免重复）。
	 */
	const _box = document.getElementById('ask_box')
	if (_box && italy_chain_shown_card !== pc.card_id) {
		italy_chain_shown_card = pc.card_id
		const raw = build_card_elt({
			id: pc.card_id, card_id: pc.card_id,
			name: pc.name, type: pc.type, img: pc.img, text: pc.text,
		})
		/*
		 * 克隆一份再用：build_card_elt 内部挂了 click -> on_click_hand_card，
		 * 那是【手牌】的打出入口。而这张牌来自【弃牌堆】，并不在手牌里，
		 * 直接复用会让人点一下卡面就误触发出牌流程。
		 * cloneNode(true) 会丢弃所有事件监听器（点击/悬停），这里只需要"看得见卡面"。
		 */
		const face = raw.cloneNode(true)
		face.className = 'card italy_chain_face'
		const wrap = document.createElement('div')
		wrap.className = 'italy_chain_card'
		wrap.appendChild(face)
		if (pc.text) {
			const tip = document.createElement('div')
			tip.className = 'card_text'
			tip.textContent = pc.text
			wrap.appendChild(tip)
		}
		_box.appendChild(wrap)
	}
}

/* 【2026-10-08】16703 罗马尼亚铁卫团：德国弃牌摸牌提示框。
 * 点一张德国手牌 = 弃置并摸1张；或放弃。 */
function update_italy_german_draw_box() {
	const d = (view && view.delegate && view.delegate.mode === 'german_draw') ? (view.italy_german_draw || view.delegate) : null
	if (!d) {
		if (ask_state && ask_state.kind === 'italy_german_draw') {
			ask_state = null
			render_ask_box(null, null, null)
		}
		return
	}
	const opt = [{
		label: '放弃（不弃牌）', cls: 'ghost',
		onClick: () => {
			ask_state = null
			render_ask_box(null, null, null)
			send_action('event_delegate_decline', {})
		},
	}]
	ask_state = { kind: 'italy_german_draw' }
	render_ask_box('罗马尼亚铁卫团：德国弃1张手牌摸1张',
		'点击下方一张【德国手牌】将其弃置并摸1张；或放弃。当前手牌 ' + (d.handCount || 0) + ' 张。', opt)
}

/* 翻转类委托统一刷新入口：依 view.delegate.mode 分派到各渲染函数。
 * 17721/16703/17729/17535 的控制状态已统一到 view.delegate（服务端 game.delegate），
 * 此处各自按自身 mode 判空后渲染，互不影响。 */
function update_delegate_box() {
	update_it_delegate_box()
	update_italy_chain_box()
	update_italy_german_draw_box()
	update_us_lend_lease()
}

/* 【2026-10-10】17553 抗日义勇军：让权日本弃牌提示框。
 * 与 16703 罗马尼亚铁卫团（update_italy_german_draw_box）完全同款：
 * 提示框 + 点手牌结算（日本点 1 张手牌 = 弃置该牌并损耗 1 张）。
 * 美国方看到"等待日本"提示（不设 ask_state，避免拦截其手牌点击）。 */
function update_us_japan_box() {
	const dg = view && view.us_japan_delegate
	if (!dg) {
		if (ask_state && ask_state.kind === 'us_japan_delegate') {
			ask_state = null
			render_ask_box(null, null, null)
		}
		return
	}
	if (dg.waiting_for) {
		render_ask_box('抗日义勇军：等待【' + dg.waiting_for + '】弃牌',
			'中国' + (dg.reason || '行动') + '后，日本需弃置 1 张手牌并损耗 1 张。', [])
		return
	}
	ask_state = { kind: 'us_japan_delegate' }
	render_ask_box('抗日义勇军：日本弃 1 张手牌',
		'点击下方一张【日本手牌】将其弃置，并损耗 1 张。当前手牌 ' + (dg.hand_count || 0) + ' 张。', [])
}

/* 【2026-10-10】16304 中国远征军：让权美国选相邻地区征召中国陆军。
 * 复用既有地图高亮 highlight_targets + on_click_space 点选（与 pending_armed
 * need:'space' 同款），不新造 UI：美国侧高亮候选并提示，其他方显示"等待美国"。 */
function update_us_china_box() {
	const dg = view && view.us_china_delegate
	if (!dg) return
	if (dg.waiting_for) {
		render_ask_box('中国远征军：等待【' + dg.waiting_for + '】选择',
			'<东南亚>的中国陆军被移除，美国需选择相邻地区之一征召中国陆军。', [])
		return
	}
	const cands = dg.candidates || []
	if (!cands.length) return
	/* 高亮候选地区（客户端不二次过滤，直接用服务端给的） */
	highlight_targets({ spaces: cands.map(c => ({ id: c.id, reason: '中国征召候选' })) })
	render_ask_box('中国远征军：选择征召地区',
		'<东南亚>的中国陆军被移除。点击地图上高亮的相邻地区之一，中国在该地区征召陆军。', [])
}

/* 【2026-10-10】17526 民主兵工厂：让权英国执行建设（多步，交互式点地图）。
 * 复用既有地图高亮 highlight_targets + on_click_space 点选（与 us_china_delegate 同款）。 */
function update_uk_build_box() {
	const dg = view && view.uk_build_delegate
	if (!dg) { window.__ukSelType = null; return }
	if (dg.waiting_for) {
		render_ask_box('民主兵工厂：等待【' + dg.waiting_for + '】建设',
			'美国打出《民主兵工厂》，让权【' + dg.waiting_for + '】按所选顺序建设1支海军与1支陆军。', [])
		return
	}
	/*
	 * 【2026-10-26 重做·参考 17532 战区移动】两阶段：
	 *   ① stage='order'  —— 先选建造顺序（先海军 / 先陆军）
	 *   ② stage='build'  —— 按所选顺序逐个建；当前这一支无处可建时给「放弃」按钮
	 * 不再让服务端按"建立时的盘面"静默删掉某个兵种（旧实现会导致玩家永久少建一支）。
	 */
	if (dg.stage === 'order') {
		if (typeof clear_target_highlight === 'function') clear_target_highlight()
		render_ask_box('民主兵工厂：选择建造顺序',
			'美国打出《民主兵工厂》，让权【英国】按任意顺序建设1支海军与1支陆军。' +
			'请先选择【先建哪一支】—— 之后会严格按你选的顺序依次建造（先建的兵种可能让另一支变得可建）。',
			[
				{ label: '先建海军', cls: 'primary', onClick: () => send_action('resolve_uk_build_delegate', { first: 'navy' }) },
				{ label: '先建陆军', cls: 'primary', onClick: () => send_action('resolve_uk_build_delegate', { first: 'army' }) },
			])
		return
	}
	const cur = dg.current
	if (!cur) return
	const zh = cur === 'navy' ? '海军' : '陆军'
	const cands = dg.candidates || []
	const orderText = (dg.order || []).map(t => (t === 'navy' ? '海军' : '陆军')).join(' → ')
	if (dg.can_skip || !cands.length) {
		render_ask_box('民主兵工厂：无处建设' + zh,
			'当前全图没有可建设' + zh + '的地区。放弃这一支后继续下一步' +
			'（已选顺序：' + orderText + '）。',
			[{
				label: '放弃建造' + zh, cls: 'primary',
				onClick: () => send_action('resolve_uk_build_delegate', { skip: true }),
			}])
		return
	}
	const step = (dg.idx || 0) + 1
	const total = dg.total || 2
	highlight_targets({ spaces: cands.map(c => ({ id: c.id, reason: '英国建设' + zh + '候选' })) })
	render_ask_box('民主兵工厂：英国建设' + zh + '（第 ' + step + '/' + total + ' 步）',
		'点击地图上高亮的地区，英国建设1支' + zh + '。已选顺序：' + orderText + '。', [])
}

/* 【2026-10-10】17529 摩尔曼斯克运输船队：让权苏联执行建设（多步，交互式点地图）。 */
function update_su_build_box() {
	const dg = view && view.su_build_delegate
	if (!dg) return
	if (dg.waiting_for) {
		render_ask_box('摩尔曼斯克运输船队：等待【' + dg.waiting_for + '】建设',
			'美国打出《摩尔曼斯克运输船队》，让权【' + dg.waiting_for + '】在<罗斯>征召1支陆军并建设1支陆军。', [])
		return
	}
	const cands = dg.candidates || []
	if (!cands.length) return
	const opName = dg.current_op === 'build' ? '建设' : '征召'
	const typeName = dg.current_type === 'navy' ? '海军' : '陆军'
	highlight_targets({ spaces: cands.map(c => ({ id: c.id, reason: '苏联' + opName + '候选' })) })
	render_ask_box('摩尔曼斯克运输船队：苏联执行（' + (dg.step + 1) + '/' + dg.total + '）',
		'点击地图上高亮的地区，苏联' + opName + '1支' + typeName + '。', [])
}

/* 【2026-10-10】17537 美国人民同情中国：美国帮中国在"大本营或相邻"征召（多步，交互式点地图）。
 * 美国直接操作（非挂起），高亮候选地区由服务端按 中国大本营或相邻 + can_recruit_at 过滤。 */
function update_us_china_build() {
	const dg = view && view.us_china_build
	if (!dg) return
	if (dg.waiting_for) {
		render_ask_box('美国人民同情中国：等待【' + dg.waiting_for + '】操作',
			'美国打出《美国人民同情中国》，由【' + dg.waiting_for + '】选择中国大本营或相邻地区征召1支中国陆军。', [])
		return
	}
	const cands = dg.candidates || []
	if (!cands.length) return
	const opName = dg.current_op === 'build' ? '建设' : '征召'
	const typeName = dg.current_type === 'navy' ? '海军' : '陆军'
	highlight_targets({ spaces: cands.map(c => ({ id: c.id, reason: '中国' + opName + '候选' })) })
	render_ask_box('美国人民同情中国：美国帮中国征召（' + (dg.step + 1) + '/' + dg.total + '）',
		'点击地图上高亮的地区，中国' + opName + '1支' + typeName + '。', [])
}

/* 【2026-10-10】17532 战区移动：美国移除己方棋子 + 建设（美国直接操作，非挂起）。
 * step0 移除：高亮美国陆军/海军棋子；step1/step2 建设：高亮候选地区。 */
function update_us_theater_box() {
	const dg = view && view.us_theater_delegate
	if (!dg) return
	if (dg.waiting_for) {
		render_ask_box('战区移动：等待【' + dg.waiting_for + '】操作',
			'美国打出《战区移动》，由【' + dg.waiting_for + '】移除己方部队并建设。', [])
		return
	}
	const st = dg.steps ? dg.steps[dg.step] : null
	if (st && st.op === 'remove') {
		const pcs = dg.remove_pieces || []
		highlight_pieces(pcs, 'theater')
		render_ask_box('战区移动：移除部队（' + (dg.step + 1) + '/' + dg.total + '）',
			'点击地图上高亮的美国陆军或海军，将其移除。', [])
		return
	}
	const cands = dg.candidates || []
	if (!cands.length) return
	const opName = dg.current_op === 'build' ? '建设' : '征召'
	const typeName = dg.current_type === 'navy' ? '海军' : '陆军'
	highlight_targets({ spaces: cands.map(c => ({ id: c.id, reason: '美国' + opName + '候选' })) })
	render_ask_box('战区移动：美国建设（' + (dg.step + 1) + '/' + dg.total + '）',
		'点击地图上高亮的地区，美国' + opName + '1支' + typeName + '。', [])
}

/* 【2026-10-17】17513 战时生产委员会：美国选 1 张桌面[状态卡]重置为"本回合未发动"。
 * 复用 us_political_modal 卡片网格范式；按"本回合已发动/未发动"分区，
 * 仅已发动的可重置（点选），未发动的灰置（本就还能发动，重置无意义）。
 * 确认 -> send_action('resolve_us_wartime')。 */
let us_wartime_sel = null
function update_us_wartime_box() {
	const modal = document.getElementById("us_wartime_modal")
	if (!modal) return
	const dg = view && view.us_wartime
	if (!dg || !dg.candidates) { modal.classList.add("hide"); us_wartime_sel = null; return }
	modal.classList.remove("hide")
	const box = modal.querySelector(".modal-box")
	box.innerHTML = ""

	const head = document.createElement("div")
	head.className = "modal-head"
	const title = document.createElement("span")
	title.className = "modal-title"
	title.textContent = "《战时生产委员会》"
	head.appendChild(title)
	const sub = document.createElement("span")
	sub.className = "modal-sub"
	sub.textContent = "选 1 张本回合已发动的[状态卡]，重置为未发动（损耗1张牌）"
	head.appendChild(sub)
	box.appendChild(head)

	const cands = dg.candidates || []
	const usedCands = cands.filter(c => c.used)
	const unusedCands = cands.filter(c => !c.used)

	const renderSection = (labelText, list, grey) => {
		const sec = document.createElement("div")
		sec.className = "modal-section"
		const label = document.createElement("div")
		label.className = "modal-label"
		label.textContent = labelText
		sec.appendChild(label)
		const grid = document.createElement("div")
		grid.className = "card-grid"
		if (!list.length) {
			const e = document.createElement("p")
			e.className = "empty-note"
			e.textContent = "（无）"
			grid.appendChild(e)
		} else {
			for (const c of list) {
				const el = card_elt(c, () => {
					if (grey) { toast('《' + (c.name || '') + '》本回合还未发动，无需重置'); return }
					us_wartime_sel = (us_wartime_sel === c.id) ? null : c.id
					update_us_wartime_box()
				})
				if (grey) el.classList.add("disabled")
				if (us_wartime_sel === c.id) el.classList.add("sel")
				grid.appendChild(el)
			}
		}
		sec.appendChild(grid)
		box.appendChild(sec)
	}
	renderSection("本回合已发动（可重置）", usedCands, false)
	renderSection("本回合未发动", unusedCands, true)

	const foot = document.createElement("div")
	foot.className = "modal-foot"
	const hint = document.createElement("span")
	hint.className = "modal-hint"
	hint.textContent = us_wartime_sel ? "已选 1 张，点确认重置" : "点选 1 张已发动的状态卡"
	foot.appendChild(hint)
	const ok = document.createElement("button")
	ok.className = "action primary"
	ok.textContent = "确认重置"
	ok.disabled = !us_wartime_sel
	ok.onclick = () => {
		if (!us_wartime_sel) return
		const chosen = us_wartime_sel
		us_wartime_sel = null
		send_action("resolve_us_wartime", { card: chosen })
	}
	foot.appendChild(ok)
	box.appendChild(foot)
}

/* 【2026-10-17】17528 广阔的资源：美国检视弃牌堆，选 1 张重打。
 * 改用居中卡片网格 modal（复用 us_political_modal 的 .modal + .card-grid + card_elt 范式），
 * 展示弃牌堆真实卡图，点选 1 张 -> 确认 -> send_action('resolve_us_replay')。
 * 原版是 render_ask_box 的文字按钮列，看不到卡图；且 view 曾用 Number(id) 打回实例 id 导致选不中。 */
let us_replay_sel = null
function update_us_replay() {
	const modal = document.getElementById("us_replay_modal")
	if (!modal) return
	const dg = view && view.us_replay
	/* 仅美国（有 candidates）弹框；其他阵营只收到 waiting_for，不弹框 */
	if (!dg || !dg.candidates) { modal.classList.add("hide"); us_replay_sel = null; return }
	modal.classList.remove("hide")
	const box = modal.querySelector(".modal-box")
	box.innerHTML = ""

	const head = document.createElement("div")
	head.className = "modal-head"
	const title = document.createElement("span")
	title.className = "modal-title"
	title.textContent = "《广阔的资源》"
	head.appendChild(title)
	const sub = document.createElement("span")
	sub.className = "modal-sub"
	sub.textContent = "美国检视弃牌堆，选 1 张重打（结算后仍留弃牌堆）"
	head.appendChild(sub)
	box.appendChild(head)

	const sec = document.createElement("div")
	sec.className = "modal-section"
	const label = document.createElement("div")
	label.className = "modal-label"
	label.textContent = "选择 1 张弃牌堆卡"
	const hint = document.createElement("span")
	hint.className = "modal-hint"
	hint.textContent = us_replay_sel ? "已选 1 / 1，点确认" : "点选 1 张卡牌"
	label.appendChild(hint)
	sec.appendChild(label)

	const cands = dg.candidates || []
	const grid = document.createElement("div")
	grid.className = "card-grid"
	if (!cands.length) {
		const e = document.createElement("p")
		e.className = "empty-note"
		e.textContent = "美国弃牌堆为空，无牌可重打"
		grid.appendChild(e)
	} else {
		for (const c of cands) {
			const el = card_elt(c, () => {
				/* 灰置牌不可选：点它只提示原因 */
				if (c.playable === false) {
					toast('《' + (c.name || '') + '》当前不能在出牌阶段打出' + (c.reason ? '：' + c.reason : ''))
					return
				}
				us_replay_sel = (us_replay_sel === c.id) ? null : c.id
				update_us_replay()
			})
			if (c.playable === false) el.classList.add("disabled")
			if (us_replay_sel === c.id) el.classList.add("sel")
			grid.appendChild(el)
		}
	}
	sec.appendChild(grid)
	box.appendChild(sec)

	const foot = document.createElement("div")
	foot.className = "modal-foot"
	const cancel = document.createElement("button")
	cancel.className = "action"
	cancel.textContent = "取消选择"
	cancel.onclick = () => { us_replay_sel = null; update_us_replay() }
	foot.appendChild(cancel)
	const ok = document.createElement("button")
	ok.className = "action primary"
	ok.textContent = "确认重打"
	ok.disabled = !us_replay_sel
	ok.onclick = () => {
		if (!us_replay_sel) return
		const chosen = us_replay_sel
		us_replay_sel = null
		send_action("resolve_us_replay", { card: chosen })
	}
	foot.appendChild(ok)
	box.appendChild(foot)
}

/*
 * 【2026-10-20】17528《广阔的资源》重打的【接手】。
 *
 * 服务端 resolve_us_replay 现在只做"把牌捡回手牌 + 授予一次性免费额外打出"，
 * 然后下发 view.us_replay_armed = { card, token }。这里收到【新 token】时，
 * 直接复用 on_click_hand_card —— 与玩家在手牌里点这张卡【完全同路】：
 *   · BASIC  -> start_basic_card（选目标地区 / 选发起单位，battle_flow）
 *   · EVENT  -> query('event_targets') 算候选 -> 高亮 -> 点地图提交
 *   · ECON   -> 按 econ_targets 选目标国 / 单目标自动带参
 * 拦截、时点、名额、国家技能钩子因此全部与真实出牌同源。
 *
 * 旧实现在服务端内部无参调 play_card，需要"先选目标"的卡（发起陆战/海战、
 * 多步事件）会直接失败或被"兜底"挪进弃牌堆并清掉额外打出权 ——
 * 表现就是"选了牌要重打，地图却点不动/毫无反应"。
 *
 * token 只增不减：同一 token 不重复触发；首次进房间只记基线。
 */
let us_replay_armed_seen = null
function update_us_replay_armed() {
	const dg = view && view.us_replay_armed
	if (!dg || !dg.card) { us_replay_armed_seen = null; return }
	if (us_replay_armed_seen === dg.token) return
	us_replay_armed_seen = dg.token
	/* 从手牌里取真实卡对象（含 econ_targets 等视图字段），取不到再兜底 */
	let c = null
	const n = view.my_nation
	const cards = (n && view.hands && view.hands[n] && view.hands[n].cards) || []
	c = cards.find(x => String(x.id) === String(dg.card)) || null
	if (!c) c = inst_card_client(dg.card)
	if (!c) return
	toast('《广阔的资源》：《' + (c.name || '?') +
		'》已回到手牌，请按正常流程打出（不占本回合成名配额）')
	on_click_hand_card(c, null)
}

/* 【2026-10-11】17531 现购自运政策：美国为友方英/苏/中/法征召部队（先选国、再点地图选地区、再选兵种） */
function update_us_merchant() {
	const dg = view && view.us_merchant
	if (!dg) {
		if (ask_state && ask_state.kind === 'us_merchant') { ask_state = null; render_ask_box(null, null, null) }
		return
	}
	if (!dg.nation) {
		const nat = dg.nation_candidates || []
		const opt = nat.map(n => ({
			label: '为【' + n + '】征召部队', cls: 'primary',
			onClick: () => { ask_state = null; render_ask_box(null, null, null); send_action('resolve_us_merchant_select', { nation: n }) }
		}))
		ask_state = { kind: 'us_merchant' }
		render_ask_box('现购自运政策：选择友方国家',
			'选择英/苏/中/法之一，美国在其本土或相邻地区征召1支合法部队（陆军/海军/空军，美国直接操作）。', opt)
		return
	}
	/*
	 * 【2026-10-25 玩家口径】顺序改为 国家 → 兵种 → 地区：
	 *   选完国家先给"此刻能合法征召的兵种"按钮（陆军/海军/空军，按服务端判定），
	 *   选定后再只高亮"该兵种合法"的地区。
	 * 老存档（已在某地区上选兵种）服务端仍下发 step='type'，文案会带地区名。
	 */
	if (dg.step === 'type') {
		const types = dg.types || []
		const where = dg.space != null ? ('在' + (dg.space_name || '') + ' ') : ''
		if (!types.length) {
			render_ask_box('现购自运政策：' + dg.nation + ' ' + where + '选择兵种',
				'该国此刻没有可合法征召的兵种（需本土或相邻地区、且有空位/载体）。', [])
			return
		}
		const opt = types.map(t => ({
			label: '征召' + t.zh, cls: 'primary',
			onClick: () => { ask_state = null; render_ask_box(null, null, null); send_action('resolve_us_merchant_type', { type: t.type }) }
		}))
		ask_state = { kind: 'us_merchant' }
		render_ask_box('现购自运政策：' + dg.nation + ' ' + where + '选择兵种',
			'只列出该国此刻能合法征召的兵种。', opt)
		return
	}
	/* 第三步：选地区（只高亮该兵种合法的地区） */
	{
		const tgs = dg.targets || []
		if (!tgs.length) {
			render_ask_box('现购自运政策：' + dg.nation,
				'该兵种当前没有可征召的地区（需本土或相邻、且有空位/载体）。', [])
			return
		}
		highlight_targets({
			spaces: tgs.map(t => ({ id: t.id, reason: dg.nation + ' ' + (dg.type_zh || '部队') + ' 征召候选' })),
		})
		render_ask_box('现购自运政策：' + dg.nation + ' 征召' + (dg.type_zh || '部队'),
			'点击地图上高亮的地区完成征召（只显示该兵种合法的地区）。', [])
	}
}

/* 【2026-10-13】17535 租借法案：委托苏/英打出 1 张手牌并摸 1 张。
 * 改用居中选牌 modal（复用 su_purge_modal / us_political_modal 的 .modal + .card-grid + card_elt 范式）：
 *   · step=nation（仅美国可见）：展示「委托苏联 / 委托英国」两个按钮；
 *   · step=play（仅被委托国可见）：card-grid 渲染其手牌（真实卡图），点击即打出；
 *   · 其余阵营（waiting_for）不弹框，仅等待。
 * 服务端 view.us_lend_lease.hand 已附带 type/img 供 card_elt 显示卡面。 */
function update_us_lend_lease() {
	const modal = document.getElementById('lend_lease_modal')
	if (!modal) return
	/* 【2026-10-19】17855《间谍机构》复用本 modal 显示某国手牌网格时礼让：
	 * 只要 armed_offer 处于 pending（need='card'/'status' 选牌步），本函数就不碰它，
	 * 交 update_armed_offer_box（~464，早于本函数 ~1104）全权管理，避免被 hide/清空。 */
	if (view && view.armed_offer && view.armed_offer.pending) return
	const dg = (view && view.delegate && view.delegate.mode === 'single') ? (view.us_lend_lease || view.delegate) : null
	/* 【2026-10-14】lend_lease_active 由 view 统一驱动：委托处于"打牌"阶段时记为被委托国，
	   使下方事件/状态卡的"选目标/选代价"后续提交经 lend_play_action 路由到
	   resolve_us_lend_lease_play（带 nation=被委托国）。其余情况清空。 */
	lend_lease_active = (dg && !dg.done && dg.step === 'play' && dg.nation) ? dg.nation : null
	/* 无挂起 / 已结束 / 仅等待方（无 step）一律隐藏。
	 * 注意：只能清 .modal-box 的内容，绝不能 modal.innerHTML='' —— 那会把
	 * .modal-box 容器本身删掉，下次有 step 时 querySelector('.modal-box')
	 * 返回 null，box.innerHTML 抛 TypeError 并中断整条 update 渲染管线
	 * （表现为"报错卡一下、刷新才正常、手牌不刷新像没打出"）。 */
	if (!dg || !dg.step) {
		modal.classList.add('hide')
		const b = modal.querySelector('.modal-box')
		if (b) b.innerHTML = ''
		return
	}
	modal.classList.remove('hide')
	const box = modal.querySelector('.modal-box')
	box.innerHTML = ''

	const head = document.createElement('div')
	head.className = 'modal-head'
	const title = document.createElement('span')
	title.className = 'modal-title'
	title.textContent = '《租借法案》'
	const sub = document.createElement('span')
	sub.className = 'modal-sub'
	sub.textContent = dg.step === 'play'
		? '委托【' + dg.nation + '】打出 1 张手牌并摸 1 张'
		: '选择委托国家（苏联或英国），由其打出 1 张手牌并摸 1 张'
	head.append(title, sub)
	box.appendChild(head)

	if (dg.step !== 'play') {
		/* ① 选国：两国按钮 */
		const sec = document.createElement('div')
		sec.className = 'modal-section'
		const label = document.createElement('div')
		label.className = 'modal-label'
		label.textContent = '① 选择委托国家'
		sec.appendChild(label)
		const grid = document.createElement('div')
		grid.className = 'card-grid'
		const empty = document.createElement('p')
		empty.className = 'empty-note'
		empty.textContent = '选择苏联或英国，由其打出 1 张手牌并摸 1 张（让权操作）。'
		grid.appendChild(empty)
		sec.appendChild(grid)
		box.appendChild(sec)

		const foot = document.createElement('div')
		foot.className = 'modal-foot'
		for (const n of (dg.nation_candidates || [])) {
			const b = document.createElement('button')
			b.className = 'action primary'
			b.textContent = '委托【' + n + '】'
			b.onclick = () => { modal.classList.add('hide'); send_action('resolve_us_lend_lease_select', { nation: n }) }
			foot.appendChild(b)
		}
		box.appendChild(foot)
		return
	}

	/* ② 打牌：被委托国手牌，点击即打出 */
	const sec = document.createElement('div')
	sec.className = 'modal-section'
	const label = document.createElement('div')
	label.className = 'modal-label'
	label.textContent = '② 选择 ' + dg.nation + ' 的 1 张手牌打出'
	sec.appendChild(label)

	const grid = document.createElement('div')
	grid.className = 'card-grid'
	const cards = dg.hand || []
	if (!cards.length) {
		const empty = document.createElement('p')
		empty.className = 'empty-note'
		empty.textContent = dg.nation + ' 手牌为空，无牌可打。'
		grid.appendChild(empty)
	} else {
		for (const c of cards) {
			let el
			if (c.type === 'BASIC') {
				/* 基本卡（建设/发起战斗）：进入既有"选目标"流程，
				   最终提交经 submit_basic_card 路由到 resolve_us_lend_lease_play */
				el = card_elt(c, () => {
					modal.classList.add('hide')
					lend_lease_active = dg.nation
					start_basic_card(c)
				})
			} else if (c.type === 'EVENT' || c.type === 'ECHO') {
				/* 事件/回声卡：走"查目标→高亮→点选"流程；最终提交经 lend_play_action
				   路由到 resolve_us_lend_lease_play（带 nation=被委托国） */
				el = card_elt(c, () => {
					modal.classList.add('hide')
					lend_lease_active = dg.nation
					query_event_targets(c.id)
				})
			} else {
				/* 增强/其它（无目标选择）：直接打出（带 card 即可） */
				el = card_elt(c, () => {
					modal.classList.add('hide')
					send_action('resolve_us_lend_lease_play', { card: c.id })
				})
			}
			grid.appendChild(el)
		}
	}
	sec.appendChild(grid)
	box.appendChild(sec)
	}

/* 【2026-10-12】17510 我们的政治哲学：英国从弃牌堆选 1 张[响应卡]打出（挂起给英国）。
 * 复用 script_modal 的"卡片网格 + 点选高亮(.sel) + 底部确认(.modal-foot)"范式，
 * 并用 classList 切换 .hide（而非 style.display）以保留 .modal 的 flex 居中。
 * 候选来自 view.us_political.candidates，点选 1 张 → 确认 → send_action。 */
let us_political_sel = null
function update_us_political_box() {
	const modal = document.getElementById("us_political_modal")
	if (!modal) return
	const dg = view && view.us_political
	/* 仅英国（有 candidates）弹框；其他阵营只收到 waiting_for，不弹框 */
	if (!dg || !dg.candidates) { modal.classList.add("hide"); us_political_sel = null; return }
	modal.classList.remove("hide")
	const box = modal.querySelector(".modal-box")
	box.innerHTML = ""

	const head = document.createElement("div")
	head.className = "modal-head"
	const title = document.createElement("span")
	title.className = "modal-title"
	title.textContent = "《我们的政治哲学》"
	head.appendChild(title)
	const sub = document.createElement("span")
	sub.className = "modal-sub"
	sub.textContent = "英国从弃牌堆选 1 张[响应卡]打出"
	head.appendChild(sub)
	box.appendChild(head)

	const sec = document.createElement("div")
	sec.className = "modal-section"
	const label = document.createElement("div")
	label.className = "modal-label"
	label.textContent = "选择 1 张[响应卡]"
	const hint = document.createElement("span")
	hint.className = "modal-hint"
	hint.textContent = us_political_sel ? "已选 1 / 1，点确认" : "点选 1 张卡牌"
	label.appendChild(hint)
	sec.appendChild(label)

	const cands = dg.candidates || []
	const grid = document.createElement("div")
	grid.className = "card-grid"
	if (!cands.length) {
		const e = document.createElement("p")
		e.className = "empty-note"
		e.textContent = "英国弃牌堆中没有[响应卡]"
		grid.appendChild(e)
	} else {
		for (const c of cands) {
			const el = card_elt(c, () => {
				us_political_sel = (us_political_sel === c.id) ? null : c.id
				update_us_political_box()
			})
			if (us_political_sel === c.id) el.classList.add("sel")
			grid.appendChild(el)
		}
	}
	sec.appendChild(grid)
	box.appendChild(sec)

	const foot = document.createElement("div")
	foot.className = "modal-foot"
	const cancel = document.createElement("button")
	cancel.className = "action"
	cancel.textContent = "取消"
	cancel.onclick = () => { us_political_sel = null; update_us_political_box() }
	foot.appendChild(cancel)
	const ok = document.createElement("button")
	ok.className = "action primary"
	ok.textContent = "确认选择"
	ok.disabled = !us_political_sel
	ok.onclick = () => {
		if (!us_political_sel) return
		const chosen = us_political_sel
		us_political_sel = null
		send_action("resolve_us_political_play", { card: chosen })
	}
	foot.appendChild(ok)
	box.appendChild(foot)
}

/* 【2026-10-10】17555 大萧条的余波：美国结束中立奖励按钮。
 * 与 17850 大清洗（su_purge_play 按钮）同款：点按钮弃此牌换计分标记。 */
function update_us_depression_box() {
	const on = view && view.actions && view.actions.us_depression_use
	if (!on) {
		if (ask_state && ask_state.kind === 'us_depression') {
			ask_state = null
			render_ask_box(null, null, null)
		}
		return
	}
	const opt = [{
		label: '弃置《大萧条的余波》→ <美国> +1 计分标记', cls: 'primary',
		onClick: () => {
			ask_state = null
			render_ask_box(null, null, null)
			send_action('us_depression_use', {})
		},
	}]
	ask_state = { kind: 'us_depression' }
	render_ask_box('大萧条的余波：美国结束中立奖励',
		'美国已结束中立。可弃置此牌，使 <美国> 增加 1 个计分标记。', opt)
}

/* 【2026-10-15】17555 大萧条的余波 ①：美国打出事件/状态卡后强制自选弃 1 张手牌。
 * 与 ②（结束中立+1 标记弹窗）同款 ask_box，但本框需玩家先点手牌选 1 张再确认。 */
function update_us_depression_discard_box() {
	const on = view && view.us_depression_discard
	if (!on) {
		if (pending_depression_discard) {
			pending_depression_discard = null
			update_hand_panel()
		}
		if (ask_state && ask_state.kind === 'us_depression_discard') {
			ask_state = null
			render_ask_box(null, null, null)
		}
		return
	}
	if (!pending_depression_discard) pending_depression_discard = { drop: [] }
	const drop = pending_depression_discard.drop
	const opt = [{
		label: drop.length === 1 ? '确认弃置（1 张）' : '请选择 1 张手牌',
		cls: 'primary',
		onClick: () => {
			if (drop.length !== 1) {
				toast('请先点选 1 张手牌弃置')
				return
			}
			const card = drop[0]
			pending_depression_discard = null
			send_action('us_depression_discard', { card })
		},
	}]
	ask_state = { kind: 'us_depression_discard' }
	render_ask_box('大萧条的余波：出牌前须弃置 1 张手牌',
		'美国打出[事件/状态]卡，须先自选弃置 1 张手牌（点手牌选择，再点下方确认）。' +
		'弃完后该卡自动结算 —— 代价已付，不会重复询问。', opt)
}

/* 【2026-10-08】17732 德国军事顾问：借用德国状态卡。
 * pending：列出桌上德国状态卡供选择；否则展示已借用的卡并可激活。 */
/* 【2026-10-28 #9②】已为哪张借来的卡弹过提示（避免每帧重复 toast） */
let italy_borrow_toasted = null

function update_italy_borrow_box() {
	const ib = view && view.italy_borrow
	if (!ib) {
		italy_borrow_toasted = null
		if (ask_state && ask_state.kind === 'italy_borrow') {
			ask_state = null
			render_ask_box(null, null, null)
		}
		return
	}
	/*
	 * 【2026-10-23 修复】让位守卫：响应卡决策 / 响应效果选目标 是【阻塞式】询问，
	 * 优先级高于本框（本框只是"本回合可激活"的常驻提示）。
	 *
	 * 本函数在 update_pending_trigger_box 之后调用，若无条件 render_ask_box，
	 * 会把「是否发动《破译恩尼格码》」的发动/不发动按钮直接盖掉 ——
	 * 顶部横幅要求决定、界面上却无处可点，对局卡死。
	 * 服务端已按阵营裁剪 view.italy_borrow，这里再兜一层同阵营并发的情况。
	 */
	if (view.pending_trigger || view.response_choice) return
	if (ib.pending) {
		italy_borrow_toasted = null
		const opt = (ib.options || []).map(o => ({
			label: '借用《' + o.name + '》', cls: 'primary',
			onClick: () => {
				ask_state = null
				render_ask_box(null, null, null)
				send_action('resolve_italy_borrow', { face: o.card_id })
			},
		}))
		ask_state = { kind: 'italy_borrow' }
		render_ask_box('德国军事顾问：选择借用的德国状态卡',
			'点击下方一张【德国状态卡】借用（本回合内可激活其效果）：', opt)
		return
	}
	/*
	 * 【2026-10-28 #9② 修复】「已借用」不再用 ask_box 常驻占用。
	 *
	 * 旧实现：只要 view.italy_borrow 存在（整条意大利回合都有效）就每帧
	 * render_ask_box —— 于是玩家每进入一个新阶段（摸牌/补给/建设/出牌/计分…）
	 * 都会重新弹一次「德国军事顾问：已借用《X》」，把该阶段应有的操作框盖掉。
	 * 玩家原话：「每个阶段都弹『已借用』」。
	 *
	 * 这个框其实是【冗余】的：借用生效期间，那张德国卡在 view.table_status 里的
	 * ready 已按借用方计算 —— 服务端 status_window_ready 有 borrowed 分支放行
	 * （rules.js:7282），客户端桌面状态区会把它渲染成「可触发」并高亮，
	 * on_click_table_status 的点击入口本来就有，且借用卡的类型路由
	 * （battle / sbuild / discard）也在那边处理。
	 *
	 * 所以这里改成：只在【刚借用成功那一刻】toast 一次，之后不占 ask_box。
	 */
	if (ask_state && ask_state.kind === 'italy_borrow') {
		ask_state = null
		render_ask_box(null, null, null)
	}
	if (italy_borrow_toasted !== ib.card_face) {
		italy_borrow_toasted = ib.card_face
		toast('已借用《' + ib.name + '》：点击桌面状态区的它即可激活（不占名额）')
	}
}

function update_armed_offer_box() {
	const ao = view && view.armed_offer
	const statusModal = document.getElementById('lend_lease_modal')
	/* 复用 #lend_lease_modal（17535 租借法案的"屏幕中央卡片网格、真实卡图、点选"范式）：
	 * 与 17855 need='card'（揭示某国手牌、苏联选 1 张弃置）同构。
	 * 该 modal 由 update_us_lend_lease 在渲染周期早期（~1104，早于本函数 ~464）管理，
	 * 故 17855 每帧最后写入不会被覆盖；且仅在 ao.pending 时接管，避免罕见同屏误关 17535 弹框。
	 * 显隐统一用 .hide 类（与 update_us_lend_lease 一致），勿用 inline style.display。 */
	if (statusModal && ao && ao.pending) statusModal.classList.add('hide')
	if (!ao || !ao.cards || !ao.cards.length) {
		/* 窗口消失：清掉多步选择态与高亮 */
		if (pending_armed) {
			pending_armed = null
			armed_resolving_card = null
			clear_target_highlight()
			clear_piece_highlight('armed')
		}
		if (ask_state && ask_state.kind === 'armed_offer') {
			ask_state = null
			render_ask_box(null, null, null)
		}
		return
	}
	/* 已被更高优先级的框占用 -> 本框让位（下一帧再看） */
	if (ask_state && ask_state.kind !== 'armed_offer') return

	/*
	 * 【2026-10-07 修复】多步交互：run 要求进一步选择（need）。
	 * 此时高亮候选（部队/地区），点图选择即回传 use_armed_offer 推进下一步。
	 */
	if (ao.pending) {
		if (!armed_resolving_card && ao.cards.length)
			armed_resolving_card = ao.cards[0].card
		const card = armed_resolving_card || (ao.cards[0] && ao.cards[0].card)
		pending_armed = {
			card: card,
			need: ao.pending.need,
			/*
			 * 【2026-10-31 修复】候选统一归一成【id】。
			 *
			 * 服务端 need:'piece' 有两种下发形态：
			 *   · 纯 id 数组（15406 等）；
			 *   · `{id, name}` 对象数组（15355「消灭1支相邻英国空军的敌方空军」需要带
			 *     国家名区分"德国空军@德国 / 意大利空军@意大利"）。
			 * 而点击判定写的是 `String(c) === String(id)` —— 面对对象会得到
			 * "[object Object]"，于是【点了敌方空军没反应】、提示"不在候选内"，
			 * 卡就永远发动不了（玩家实测反馈）。
			 * 这里在入口处把对象归一成 id，高亮与点击判定就都对得上；
			 * 卡面名称仍由服务端下发（不影响文案）。
			 */
			candidates: (ao.pending.candidates || []).map(c =>
				(c && typeof c === 'object') ? c.id : c),
			pick: ao.pending.pick || 1,
			pickMin: ao.pending.pickMin || 1,
			/* 【2026-10-17】need:'piece' 时可附带的空白合法地块（空打目标，15406） */
			spaceCandidates: ao.pending.spaceCandidates || [],
		}
		const isPiece = ao.pending.need === 'piece'
		const isSpace = ao.pending.need === 'space'
		if (ao.pending.need === 'status') {
			if (statusModal) statusModal.classList.remove('hide')
			const box = statusModal.querySelector('.modal-box')
			box.innerHTML = ''
			const h = document.createElement('h3')
			h.textContent = '选择一张德国[状态卡]'
			box.appendChild(h)
			const cands = ao.pending.candidates || []
			const grid = document.createElement('div')
			grid.className = 'card-grid'
			if (!cands.length) {
				const e = document.createElement('p')
				e.textContent = '没有可选择的德国状态卡'
				box.appendChild(e)
			} else {
				for (const c of cands) {
					const el = card_elt(c, () => {
						send_action('use_armed_offer', { card: (ao.cards[0] && ao.cards[0].card), status: c.id })
					})
					grid.appendChild(el)
				}
				box.appendChild(grid)
				}
				return
				}
				/* 【2026-10-17】多步增强卡（如 15406《南云忠一指挥航空队》）的 need:'choice' 分支：
				* 服务端 run 先返回 need:'choice' + choiceOptions（如 陆战/海战），
				* 客户端此前无此分支，会落到"做出选择"兜底且无选项，导致多步链在第一步就断掉、
				* 永远到不了高亮目标的 need:'space' 步。这里把 choiceOptions 渲染成按钮，
				* 点选回传 use_armed_offer 带 choice（与 on_click_space 的 space 选择同源）。 */
				if (ao.pending.need === 'choice') {
				const opts = (ao.pending.choiceOptions || []).map(o => ({
				label: o.name || o.id,
				cls: 'primary',
				onClick: () => {
					clear_target_highlight()
					clear_piece_highlight('armed')
					ask_state = null
					render_ask_box(null, null, null)
					send_action('use_armed_offer', { card: pending_armed.card, choice: o.id })
					toast('已选择：' + (o.name || o.id))
				},
				}))
				ask_state = { kind: 'armed_offer' }
				render_ask_box(
				'请选择（' + (ao.cards[0] ? ao.cards[0].name : '') + '）',
				'选择要发动的战斗类型以继续《' + (ao.cards[0] ? ao.cards[0].name : '') + '》',
				opts.concat([{
					label: '放弃发动',
					onClick: () => {
						pending_armed = null
						armed_resolving_card = null
						clear_target_highlight()
						clear_piece_highlight('armed')
						ask_state = null
						render_ask_box(null, null, null)
						send_action('skip_armed_offer', {})
					},
				}]))
				return
				}
				/* 【2026-10-18】17855《间谍机构》：need='card' = 揭示目标国手牌、苏联选 1 张弃置。
				 * 复用 #lend_lease_modal（17535 的"屏幕中央真实卡图网格"）渲染候选，与 need='status' 同款。 */
				if (ao.pending.need === 'card') {
					const reveal = ao.pending.revealNation || ''
					if (statusModal) statusModal.classList.remove('hide')
					const box = statusModal ? statusModal.querySelector('.modal-box') : null
					if (box) {
						box.innerHTML = ''
						const h = document.createElement('h3')
						h.textContent = '选择并弃置 1 张（' + (reveal ? reveal + ' 的手牌' : '手牌') + '）'
						box.appendChild(h)
						const cands = ao.pending.candidates || []
						const grid = document.createElement('div')
						grid.className = 'card-grid'
						if (!cands.length) {
							const e = document.createElement('p')
							e.textContent = '没有可选择的牌'
							box.appendChild(e)
						} else {
							for (const c of cands) {
								const el = card_elt(c, () => {
									if (statusModal) statusModal.classList.add('hide')
									clear_target_highlight()
									clear_piece_highlight('armed')
									ask_state = null
									render_ask_box(null, null, null)
									send_action('use_armed_offer', { card: pending_armed.card, pick: c.id })
								})
								grid.appendChild(el)
							}
							box.appendChild(grid)
						}
					}
					return
				}
				if (isPiece) {
					/* 用归一后的 id 列表高亮（服务端可能下发 {id,name} 对象，见 pending_armed 注释） */
					highlight_pieces(pending_armed.candidates, 'armed')
					/*
					 * 【2026-10-17】同时高亮可空打的空白合法地块（15406）：
					 * 敌方单位(算子) + 空白地块(地区)一起作为目标，点单位打单位、点空白地块空打。
					 */
					const spaceCands = ao.pending.spaceCandidates || []
					if (spaceCands.length) {
						highlight_targets({ spaces: spaceCands.map(id => ({ id: id })) })
						toast('点击高亮的敌方单位发起战斗，或点高亮空白地块空打（' + (ao.cards[0] ? ao.cards[0].name : '') + '）')
					} else {
						/*
						 * 【2026-10-31】候选若带名字（多国空军等），文案里列出来，
						 * 玩家不点也知道有哪些可选项。
						 */
						const names = (ao.pending.candidates || [])
							.filter(c => c && typeof c === 'object' && c.name)
							.map(c => c.name)
						toast('请点击一支高亮的部队（' + (ao.cards[0] ? ao.cards[0].name : '') + '）' +
							(names.length ? '：' + names.join(' / ') : ''))
					}
				} else if (isSpace) {
			highlight_targets({ spaces: (ao.pending.candidates || []).map(id => ({ id: id })) })
			toast('请点击一个高亮的地区（' + (ao.cards[0] ? ao.cards[0].name : '') + '）')
		}
		ask_state = { kind: 'armed_offer' }
		render_ask_box(
			'请选择（高亮处）',
			(isPiece ? '选择一支部队' : isSpace ? '选择一个地区' : '做出选择') +
				'以发动《' + (ao.cards[0] ? ao.cards[0].name : '') + '》',
			[{
				label: '放弃发动',
				onClick: () => {
					pending_armed = null
					armed_resolving_card = null
					clear_target_highlight()
					clear_piece_highlight('armed')
					ask_state = null
					render_ask_box(null, null, null)
					send_action('skip_armed_offer', {})
				},
			}])
		return
	}

	/* 非多步：常规"打出 / 不打出"选择框 */
	/* 弃牌选牌中（armed 代价），保持 echo modal，不再重绘 armed offer */
	if (pending_echo_discard && pending_echo_discard.armed) return
	ask_state = { kind: 'armed_offer' }
	const opts = ao.cards.map(c => {
		const att = (c.cost && c.cost.attrition) || 0
		const dis = (c.cost && c.cost.discard) || 0
		const costLabel = att ? '（损耗 ' + att + '）' : (dis ? '（弃 ' + dis + ' 张）' : '')
		return {
			/*
			 * 【2026-10-31】拦截窗口来源区分：via='trigger' = 敌方机会卡【触发】，
			 * via='play' = 敌方【打出】。文案区分，避免玩家以为对方是主动出牌。
			 */
			label: (ao.via === 'trigger' ? '拦截《' : '打出《') + c.name + '》' +
				(ao.via === 'trigger' ? '（敌方触发）' : '') + costLabel,
			cls: 'primary',
			onClick: () => {
				armed_resolving_card = c.card   /* 记住正在结算的卡，供多步第一步回传 */
				if (dis) {
					/* 弃牌代价：复用 echo_discard_modal 选牌（与 ECHO 卡代价同款） */
					pending_echo_discard = { card: { id: c.card }, need_targets: null, drop: [], limit: dis, filter: (c.cost && c.cost.filter) || null, armed: true, armed_card: c.card }
					render_ask_box(null, null, null)
					ask_state = null
					update_echo_discard_box()
					toast('请选择 ' + dis + ' 张手牌弃置')
				} else {
					ask_state = null
					render_ask_box(null, null, null)
					send_action('use_armed_offer', { card: c.card })
					toast('打出《' + c.name + '》')
				}
			},
		}
	})
	opts.push({
		label: '不打出',
		onClick: () => {
			armed_resolving_card = null
			ask_state = null
			render_ask_box(null, null, null)
			send_action('skip_armed_offer', {})
		},
	})
	/*
	 * 【2026-10-31 玩家口径】拦截询问先亮出"被拦截的卡"：
	 * 标题写「【德国】打出《黄色方案》—— 是否拦截？」，描述里带上该卡卡面文本，
	 * 拦截方不用猜自己在拦什么（14500 / 触发型增强卡 / 状态卡都走这条）。
	 */
	const tgt = ao.target || null
	const tgtLine = tgt
		? ('【' + (tgt.nation || '敌方') + '】' +
			(tgt.via === 'trigger' ? '触发' : '打出') + '《' + tgt.name + '》')
		: ''
	const tgtText = tgt && tgt.text ? String(tgt.text).replace(/\s+/g, ' ').slice(0, 90) : ''
	render_ask_box(
		tgtLine ? (tgtLine + ' —— 是否拦截？') : '打出增强卡？',
		(tgtText ? ('被拦截：' + tgtText + '\n') : '') +
			(ao.cards[0].desc || '') + '\n（不打出则错过本次时机）',
		opts)
}

/* ============================================================
 * 【2026-09-30】国家技能的机会窗口（德国先实现）
 *
 * ★卡【打出并效果结算完毕后】，服务端给出 national_skill 窗口：
 *   使用 -> 损耗 1 张牌 -> 授予 extra_play(filter='status')
 *           -> 玩家接着点手牌里的一张状态卡（不占出牌名额）
 *   不使用 -> 直接清掉；之后又打出一张★卡会再给一次机会（本回合只能用 1 次）
 *
 * 这是【可选】窗口而不是挂起：做别的操作会让它自动失效
 * （服务端在 action 入口统一清 —— 见 rules.js exports.action 开头）。
 * ============================================================ */
function update_national_skill_box() {
	const ns = view && view.national_skill
	/*
	 * 【2026-10-16 重构】国家技能独立画到 #national_skill_box（位置比 #ask_box 靠上），
	 * 不再占用共享的 #ask_box / ask_state，因此与借用框、经济战框等互不覆盖。
	 * 所有国家技能（德/意/日/英/苏…）都走这里，未来新增国家技能无需改渲染。
	 * 窗口消失（ns 不存在或不可用）即收起本框。
	 */
	if (!ns || !ns.usable) {
		render_national_skill_box(null, null, null)
		return
	}
	/*
	 * 【2026-10-01】代价有两类，交互不同：
	 *   · 损耗(attrition) —— 服务端自动磨牌库顶，点了直接生效（德国）
	 *   · 弃置(discard)   —— 玩家要【自己挑 N 张手牌】丢弃，
	 *     先弹"选牌弹框"收集 drop，再提交（英国）
	 */
	const needDiscard = (ns.cost && ns.cost.discard) || 0
	render_national_skill_box(
		'国家技能（一回合一次）',
		'《' + ns.source_name + '》结算完毕：' + (ns.desc || ''),
		[
			{
				label: '使用（' + (ns.desc || '') + '）', cls: 'primary',
				onClick: () => {
					/* 把 cost 一起传进去：日本要按牌类型过滤候选 */
					if (needDiscard > 0) start_skill_discard(ns, needDiscard, ns.cost)
					else send_action('use_national_skill', {})
				},
			},
			{
				label: '不使用',
				onClick: () => send_action('skip_national_skill', {}),
			},
		])
}

/* ============================================================
 * 【2026-10-01】国家技能"弃牌代价"弹框（英国国家技能用）
 *
 * 交互与【资源再分配】完全同款：
 *   · 弹框里点卡 = 选 / 取消；
 *   · 手牌区也能点（见 on_click_hand_card）；
 *   · 选中卡显示"代价 N"序号 badge；选满才亮【确认使用】。
 *
 * 只负责【收集 drop】，真正的代价结算在服务端 use_national_skill() 里做
 * （服务端会再校验一遍 drop 的数量与归属，防止伪造）。
 * ============================================================ */

/*
 * 【2026-10-06】一步式选牌弹窗的【统一入口】。
 *
 * 两类来源共用同一个弹窗（skill_discard_modal）与同一套提交逻辑：
 *   · 国家技能（日本 one_step：弃 1 张响应 + 暗置打出 1 张响应）
 *   · 增强卡 15412《御前会议》（玩家口径：复用日本国家技能的机制）
 *
 * 差别只在【提交到哪个 action】：
 *   submit_action: 'use_national_skill' -> send_action('use_national_skill', {drop, play})
 *   submit_card:   <卡实例 id>          -> send_action('play_card', {card, cards, play})
 *
 * opt 字段全部由【服务端下发】（ns.desc / ns.one_step / ns.grant.filter /
 * tg.cost.filter / tg.play.filter），客户端不写死任何国家与卡。
 */
function start_one_step_picker(opt) {
	pending_skill_discard = {
		drop: [],
		need: opt.need,
		min: (opt.min != null ? opt.min : opt.need),
		source_name: opt.source_name || '国家技能',
		filter: opt.filter || null,
		desc: opt.desc || '',
		/*
		 * 【2026-10-05】一步模式（日本）：同一弹窗里还要再选 1 张【要打出的牌】。
		 *   one_step  -> 需要同时选 drop + play，一次提交完成
		 *   两步模式  -> 只选 drop，提交后拿到额外打出权再点手牌
		 * one_step 由服务端下发，避免客户端写死国家。
		 */
		one_step: !!opt.one_step,
		play: null,
		play_filter: opt.play_filter || null,
		/* 【2026-10-06】提交方式（国家技能 vs 增强卡） */
		submit_action: opt.submit_action || 'use_national_skill',
		submit_card: opt.submit_card || null,
	}
	/* 让出 ask_box，避免两个弹框叠在一起 */
	ask_state = null
	render_ask_box(null, null, null)
	update_skill_discard_box()
	update_hand_panel()
}

/*
 * 【2026-10-05 适配日本】英国是"弃任意 3 张"，日本是"弃 1 张【响应牌】"
 * —— 代价可能限定牌类型(cost.filter)，弹框必须按类型过滤候选，
 *   否则玩家能选到非响应牌（服务端会拒，但 UI 不该给这个选项）。
 */
function start_skill_discard(ns, need, cost) {
	start_one_step_picker({
		need: need,
		source_name: ns.source_name || '国家技能',
		filter: (cost && cost.filter) || null,
		desc: ns.desc || '',
		one_step: !!ns.one_step,
		play_filter: (ns.grant && ns.grant.filter) || null,
		submit_action: 'use_national_skill',
	})
}

function cancel_skill_discard() {
	pending_skill_discard = null
	update_skill_discard_box()
	update_hand_panel()
	update_panels()
}

function update_skill_discard_box() {
	const modal = document.getElementById("skill_discard_modal")
	if (!modal) return
	const pd = pending_skill_discard
	if (!pd) {
		modal.classList.add("hide")
		return
	}
	modal.classList.remove("hide")

	/*
	 * 副标题用【服务端下发】的 desc（含牌类型与效果），
	 * 不要硬编码"张手牌 → 打出 1 张事件牌或状态卡"
	 * （那是英国口径，日本是"弃 1 张响应牌 → 暗置 1 张响应牌"）。
	 */
	const sub = document.getElementById("skill_discard_sub")
	if (sub)
		sub.textContent = '「' + pd.source_name + '」' +
			(pd.desc || ('弃 ' + pd.need + ' 张手牌'))

	const costBox = document.getElementById("skill_cost")
	costBox.innerHTML = ""
	const allHand = (view.hands[view.my_nation] && view.hands[view.my_nation].cards) || []
	/* 代价限定类型时按类型过滤候选（日本：只让选响应牌；苏联：只让选建造陆军） */
	const matchesFilter = (c) => {
		if (!pd.filter) return true
		if (pd.filter === 'build')
			return String(c.type || '').toUpperCase() === 'BASIC' && c.name === '建设陆军'
		return String(c.type || '').toUpperCase() ===
			String(pd.filter === 'response' ? 'RESPONSE' : pd.filter).toUpperCase()
	}
	const hand = allHand.filter(c => matchesFilter(c) && c.id !== pd.submit_card)   /* 本卡不能作自己的代价 */
	for (const c of hand) {
		const d = card_elt(c, () => {
			const i = pd.drop.indexOf(c.id)
			if (i >= 0)
				pd.drop.splice(i, 1)
			else if (pd.drop.length < pd.need)
				pd.drop.push(c.id)
			else
				toast("代价只需 " + pd.need + " 张，请先取消一张")
			update_skill_discard_box()
			update_hand_panel()
		})
		const picked = pd.drop.indexOf(c.id) >= 0
		if (picked) {
			d.classList.add("sel")
			const b = document.createElement("span")
			b.className = "badge"
			b.textContent = "代价 " + (pd.drop.indexOf(c.id) + 1)
			d.appendChild(b)
		}
		costBox.appendChild(d)
	}
	if (!hand.length) {
		const p = document.createElement("div")
		p.className = "empty-note"
		p.textContent = pd.filter
			? ("手牌中没有可作为代价的" +
				(pd.filter === 'response' ? '响应牌' : pd.filter))
			: "手牌为空，无法支付代价"
		costBox.appendChild(p)
	}

	const costNote = document.getElementById("skill_cost_note")
	if (costNote) costNote.textContent = pd.drop.length + "/" + pd.need

	/*
	 * 【2026-10-05】一步模式：再渲染"要打出的牌"候选区。
	 * 候选 = 手牌中符合 grant.filter 的牌，且【排除已选作代价的牌】。
	 */
	const playSec = document.getElementById("skill_play_section")
	const playBox = document.getElementById("skill_play")
	const playNote = document.getElementById("skill_play_note")
	if (pd.one_step && playSec && playBox) {
		playSec.style.display = ""
		playBox.innerHTML = ""
		/*
		 * 【2026-10-11】play_filter 可能跨多类型（英国 event_status = EVENT 或 STATUS），
		 * 不能简单按单类型字符串比对，否则英国一步式弹窗里"要打出的牌"候选为空。
		 * 与服务端 filter_matches_card 同源：单一类型按大写比对，复合类型枚举。
		 */
		const playCands = allHand.filter(c => {
			const t = String(c.type || '').toUpperCase()
			let okType = true
			if (pd.play_filter === 'event_status')
				okType = (t === 'EVENT' || t === 'STATUS')
			else if (pd.play_filter === 'status_econ')
				okType = (t === 'STATUS' || t === 'ECON')
			else if (pd.play_filter === 'response')
				okType = (t === 'RESPONSE')
			else if (pd.play_filter === 'status_response')
				okType = (t === 'STATUS' || t === 'RESPONSE')
			else if (pd.play_filter)
				okType = (t === String(pd.play_filter).toUpperCase())
			return okType &&
				pd.drop.indexOf(c.id) < 0 &&     /* 已选作代价的不能再选为打出 */
				c.id !== pd.submit_card          /* 本卡（增强卡复用时）不能打自己 */
		})
		for (const c of playCands) {
			const d = card_elt(c, () => {
				/* 点击切换选中；再点一次取消 */
				pd.play = (pd.play === c.id) ? null : c.id
				update_skill_discard_box()
				update_hand_panel()
			})
			if (pd.play === c.id) {
				d.classList.add("sel")
				const b = document.createElement("span")
				b.className = "badge"
				b.textContent = "打出"
				d.appendChild(b)
			}
			playBox.appendChild(d)
		}
		if (!playCands.length) {
			const p = document.createElement("div")
			p.className = "empty-note"
			const pf = pd.play_filter
			p.textContent = "没有可打出的" +
				(pf === 'response' ? '响应牌'
					: pf === 'event_status' ? '事件牌或状态牌'
					: pf === 'status_response' ? '状态卡或响应牌'
					: pf === 'status_econ' ? '状态卡或经济战卡'
					: (pf || '牌'))
			playBox.appendChild(p)
		}
		if (playNote) playNote.textContent = (pd.play ? 1 : 0) + "/1"
	} else if (playSec) {
		playSec.style.display = "none"
	}

	/* 确认按钮：两步只要求 drop 够；一步还要求 play 已选 */
	const ok = document.getElementById("skill_confirm")
	if (ok) {
		const ready = pd.one_step
			? (pd.drop.length === pd.need && !!pd.play)
			: (pd.drop.length === pd.need)
		ok.disabled = !ready
	}
}

function submit_skill_discard() {
	const pd = pending_skill_discard
	if (!pd) return
	if (pd.drop.length < pd.min || pd.drop.length > pd.need) {
		toast("请选择 " + pd.min + "~" + pd.need + " 张（还需 " +
			Math.max(0, pd.min - pd.drop.length) + " 张）")
		return
	}
	const playName = (pd.play_filter === 'response' ? '响应牌' : (pd.play_filter || '牌'))
	if (pd.one_step && !pd.play) {
		toast("还需要选 1 张要打出的" + playName)
		return
	}
	/*
	 * 一步模式：drop = 要弃的，play = 要打出的，【一次提交完成】。
	 * 两步模式：只发 drop，服务端授予额外打出权，之后玩家再点手牌打出。
	 */
	const arg = pd.one_step
		? { drop: pd.drop.slice(), play: pd.play }
		: { drop: pd.drop.slice() }
	/*
	 * 【2026-10-06】增强卡（15412 御前会议）复用本弹窗时，
	 * 提交的是 play_card：卡本身 + 代价 + 要打出的牌。
	 */
	if (pd.submit_card)
		send_action('play_card', {
			card: pd.submit_card, cards: pd.drop.slice(), play: pd.play,
		})
	else
		send_action(pd.submit_action || 'use_national_skill', arg)
	pending_skill_discard = null
	update_skill_discard_box()
	update_hand_panel()
}

/*
 * 这张卡能否在【当前阶段】打出。返回 { ok, reason }
 * 口径与 rules.js 的 check_phase_for_card 一一对应。
 */
function check_phase_for_card(c) {
	const ph = view.turn_phase

	/*
	 * 【2026-09-28 玩家口径 · 阶段限制总纲】（与 rules.js 同源）
	 *
	 *   ① 卡面声明了打出时机的卡（"计分阶段开始时：…"）
	 *      -> 只能在声明的阶段打出，其他阶段【含出牌阶段】都不行。
	 *   ② 没有声明的卡（事件/状态/响应/基本/经济战卡…）
	 *      -> 只能在【出牌阶段】打出。
	 *
	 * 放在最前面，确保出牌阶段也会拦掉"声明了别的阶段"的卡。
	 */
	const decl = declared_phase_of(c)
	if (decl && ph !== decl) {
		/*
		 * 【2026-10-11 重构】英国国家技能已改为「一步式 mode:'play'」，
		 * 不再走额外打出通道，故此处不再为额外打出开 decl 早放行。
		 * 德/意/美走额外打出时，其牌均为出牌阶段声明、且出牌阶段打出，
		 * decl===ph 不触发本分支，放行交给下方统一的 extra_play 块。
		 */
		return {
			ok: false,
			reason: "《" + c.name + "》卡面说明只能在" +
				(PHASE_ZH[decl] || decl) + "打出（当前是" + (PHASE_ZH[ph] || ph) + "）",
		}
	}

	/*
	 * 【2026-09-30 · 2026-10-11 修订】额外打出：手里还有一次
	 * "因《XX》的额外打出"且这张牌在允许范围内 -> 放行。
	 * 原本写死 `ph === "play"`，对【摸牌阶段】触发的英国技能无效（永远不进此分支）；
	 * 改为"额外打出权的 phase 与当前阶段一致即放行"，覆盖任何阶段
	 * （出牌阶段 / 摸牌阶段 …），与服务端 check_phase_for_card 同源。
	 */
	if (view && view.extra_play && view.extra_play.phase === ph &&
		extra_play_allows_card(c))
		return { ok: true }

	/*
	 * 【2026-10-09 16701 意大利万岁】本回合出牌阶段行动 2 次，
	 * 但只能打出[基本卡]（玩家口径 = 基本卡 BASIC）。
	 *
	 * ⚠ 必须镜像服务端 rules.js:check_play_phase 的同名判定（通用教训 3：
	 *   服务端与客户端判定同源），否则会出现"服务端拒绝、客户端却可点"。
	 * 数据来源是服务端下发的 view.it_viva —— 客户端不自己猜（教训 R26）。
	 */
	/* view.it_viva 服务端已按【当前行动国】算好，客户端不再二次判断国别 */
	/*
	 * 【2026-10-31 修复】与服务端 check_phase_for_card 同源：
	 * 增强卡(EFFECT)/响应卡(RESPONSE) 属"按时机打出、不占名额"，不算出牌阶段行动，
	 * 不受《意大利万岁》的"只能打基本卡"限制（服务端在 it_viva 判定之前就 return 了）。
	 * 旧版这里写 `c.type !== "BASIC"` 一律置灰 -> 增强卡点不动，与服务端不一致。
	 */
	if (ph === "play" && view && view.it_viva && c.type !== "BASIC" &&
		c.type !== "EFFECT" && c.type !== "RESPONSE")
		return {
			ok: false,
			reason: "《意大利万岁》生效中：本回合出牌阶段只能打出[基本卡]",
		}

	/*
	 * ① 有【时点声明】的卡（增强卡 ECHO）：按声明的时点判定。
	 *
	 * 【2026-09-25 变更】旧逻辑是"增强卡随时可打"，
	 * 但服务端已改为按时点打出（玩家明确"涉及阶段的时机都是自己回合"）。
	 * 若客户端仍放行，就会出现"点了却被服务端拒绝"。
	 *
	 * 所以这里【镜像服务端的 trigger_ready()】，
	 * 数据来源是服务端给的 view.card_triggers / view.current_faction
	 * —— 不自己维护一份，避免两边漂移（pitfalls R3）。
	 */
	/*
	 * 【2026-09-25 bug 修复】
	 * 手牌里的 c 是 inst_pub() 返回的实例对象：
	 *   c.id       = 实例 id（如 "15310#5"）
	 *   c.card_id  = 卡面 id（如 "15310"）
	 *
	 * CARD_TRIGGERS 表的键是【卡面 id】，不是实例 id，
	 * 所以必须用 c.card_id 查，不能直接用 c.id
	 * （否则 view.card_triggers["15310#5"] 永远 undefined，
	 *  所有增强卡都被判定为"无时点声明"→全部置灰/无反应）。
	 */
	const card_id = c.card_id || c.id
	/*
	 * 【2026-09-25 bug 修复】响应卡（RESPONSE）走特殊路径：
	 * 不查 trigger_ready（响应卡声明 kind='any' 是为了 fire_trigger 用，
	 * 不是用于主动打出判定）。
	 * 规则书：响应卡像普通牌一样在【出牌阶段】从手牌打出（占名额），
	 * 然后等时机触发——所以这里直接判出牌阶段，不走 tr.kind 分支。
	 */
	if (c.type === "RESPONSE") {
		if (ph !== "play")
			return { ok: false, reason: "响应卡只能在出牌阶段打出（之后任意时机触发）" }
		if (view.my_play_done)
			return { ok: false, reason: "本回合已打出过 1 张牌（名额已用）" }
		return { ok: true }
	}
	const tr = view.card_triggers && view.card_triggers[String(card_id)]
	if (tr) {
		if (tr.kind === "anytime")
			return { ok: true }
		if (tr.kind === "any")
			return { ok: false, reason: "响应卡由触发事件驱动，不能主动打出" }
		/*
		 * 【2026-10-01】"打出XX后…"型（B 组，如 15212 G7e 鱼雷）：
		 * 留在手牌、事件发生时由服务端弹框询问，【不能主动打出】。
		 * 服务端 trigger_ready 的 load 分支已如此判定，这里同源。
		 */
		if (tr.kind === "load")
			return {
				ok: false,
				reason: "《" + c.name + "》不能主动打出 —— 仅在对应事件发生后被询问是否打出",
			}
		if (tr.kind === "self") {
			if (ph !== tr.phase)
				return {
					ok: false,
					reason: "只能在本方的" + (PHASE_ZH[tr.phase] || tr.phase) +
						"打出（当前是" + (PHASE_ZH[ph] || ph) + "）",
				}
			/* 必须是自己回合 */
			if (view.current_faction && view.my_faction &&
				view.current_faction !== view.my_faction)
				return { ok: false, reason: "只能在本方回合打出" }
			return { ok: true }
		}
		/*
		 * 【2026-10-17】条件型时点（conditional）：本方回合【任意阶段】可打，
		 * 但需满足附加前置 cond。镜像服务端 trigger_ready 的 conditional 分支。
		 * 17513 战时生产委员会（cond:'has_used_status'）：须本方(美国)桌面有
		 * 【本回合已发动】的[状态卡]。数据来源：view.table_status 只下发本方阵营、
		 * 每条带 nation + used_this_turn（服务端已按 freq_key 算好）。
		 */
		if (tr.kind === "conditional") {
			/* 必须是自己回合 */
			if (view.current_faction && view.my_faction &&
				view.current_faction !== view.my_faction)
				return { ok: false, reason: "只能在本方回合打出" }
			if (tr.cond === "has_used_status") {
				const owner = tr.nation
				const used = (view.table_status || []).some(s =>
					(!owner || s.nation === owner) && s.used_this_turn)
				if (!used)
					return {
						ok: false,
						reason: "《" + c.name + "》需要本方桌面有【本回合已发动】的[状态卡]才能打出",
					}
			}
			return { ok: true }
		}
	}

	/* 兜底：没有时点声明的增强卡仍随时可打（旧行为） */
	if (is_enhance_card(c))
		return { ok: true }

	const zh = PHASE_ZH[ph] || ph

	/* ② 出牌阶段：打 1 张（《空军力量》另有说明，不算在内） */
	if (ph === "play") {
		if (is_airforce_only(c))
			return { ok: false, reason: "《空军力量》的说明限定其只能在空军阶段打出" }
		if (view.my_play_done)
			return { ok: false, reason: "本回合出牌阶段已打出 1 张牌（每回合 1 张）" }
		return { ok: true }
	}

	/* ③ 空军阶段：空军力量（部署/夺取制空权）或 卡面写明"空军阶段" */
	if (ph === "airforce") {
		if (is_airforce_only(c)) {
			if (view.my_air_done)
				return { ok: false, reason: "本回合空军阶段已行动（二选一）" }
			return { ok: true }
		}
		if (has_phase_note(c, "空军阶段"))
			return { ok: true }
		return {
			ok: false,
			reason: "空军阶段只能打出《空军力量》、卡面说明允许在空军阶段打出的牌，或增强卡",
		}
	}

	/*
	 * ④ 其余阶段：只收"卡面【针对当前阶段】有特殊说明"的卡。
	 *
	 * 【2026-09-28 修正】原先是 has_phase_note(c)【不传阶段】，
	 * 只要卡面出现任意阶段名就放行 —— 15345 塞内加尔步兵团
	 * （"跳过【出牌阶段】行动：…"，这句是【触发代价】的描述）
	 * 于是在资源再分配等任何阶段都被判为可打出、显示为彩色可点。
	 * 现在必须卡面确实提到【当前阶段】才放行。
	 * 与 rules.js 的 check_phase_for_card ④ 同源。
	 */
	/*
	 * 判据收紧为 declared_phase_of（必须是"XX阶段开始时/结束时"的打出时机声明），
	 * 与 rules.js ④ 同源：卡面仅【被动结算】地提到本阶段
	 * （如 15340「计分阶段：…获得1分」）不算"可在此阶段打出"。
	 */
	if (decl && decl === ph)
		return { ok: true }
	return { ok: false, reason: "《" + (c.name || "该卡") + "》只能在出牌阶段打出" +
		"（当前是" + zh + "，且卡面未声明可在此阶段打出）" }
}

/*
 * 兼容旧接口：某张卡能否在空军阶段打出（布尔，供 basic_targets 等复用）。
 */
function can_play_in_airforce(c) {
	if (!c)
		return false
	if (is_airforce_only(c))
		return true
	return is_enhance_card(c) || has_phase_note(c, "空军阶段")
}

/*
 * EVENT / ECHO 卡的目标选择状态（2026-09-25）。
 *
 * pending_event_card   = 正在选目标的卡对象
 * pending_event_targets = event_targets 查询返回的目标信息
 * pending_event_choice = 已选的 choice 索引（二选一/四选一时）
 */
let pending_event_card = null
let pending_event_targets = null
let pending_event_choice = null
/*
 * 【2026-09-25 新增】多选地区（pick>1）的累积数组。
 * 单选时为 null/不使用；多选时玩家点地区累积到这里，
 * 达到 pick 数量后才 send_action({card, picks})。
 */
let pending_event_picks = null
/*
 * 【2026-09-25 新增】ECHO/EVENT 卡的"先选 N 张弃牌"流程。
 *
 * 当 query('event_targets') 返回的 tg.cost.discard > 0 时启用：
 *   pending_echo_discard = {
 *     card: 卡对象（pending_event_card）,
 *     need_targets: tg,           // 等会儿玩家选完弃牌后用来高亮地区
 *     drop: [],                   // 玩家选中的弃牌 id 数组
 *     limit: N,                   // 需要选几张
 *   }
 *
 * 玩家选满 N 张并确认后，pending_echo_discard 清空，
 * 进入 pending_event_targets + highlight_event_targets 流程。
 * 点地区提交时 send_action 带 cards: drop.slice()。
 */
/*
 * 【2026-09-29 新增】多步卡（steps.length > 1）的【逐步累积选择】。
 *
 * 为什么需要：15325 莱茵河与多瑙河 = [建设陆军, 用它发起陆战]。
 * 玩家选完第 1 步（建设位置）就 send_action 的话，服务端发现第 2 步
 * （战斗目标）还没选 -> 返回 pending -> 【整张卡不执行、不弃牌】
 * -> 客户端此时已清空选择状态 -> 玩家看到"点了没反应"。
 *
 * 正确流程：玩家每选一步 -> 累积到 pending_event_spaces[step]
 * -> 带完整 spaces 重新 query -> need 为 null 时才 send_action。
 */
let pending_event_spaces = null
/*
 * 【2026-10-21 战区移动转标准管线】多步卡里【选部队】步骤的累积。
 * 与 pending_event_spaces 完全同款：玩家每选一步 -> 累积到 pending_event_pieces[step]
 * -> 带完整 pieces 重新 query -> need 为 null 时才 send_action。
 * 不累积的话，后面选建设地区那次提交会丢掉 piece，服务端 remove 步读不到参数而失败。
 */
let pending_event_pieces = null

let pending_echo_discard = null
/*
 * 已选好的弃牌（pending_echo_discard 清空后保留，供最终 send_action 用）
 */
let pending_echo_cards = null

/* 查询某张卡当前需要什么目标（走 send_query，结果在 on_reply 里处理） */
function query_event_targets(card_id) {
	/*
	 * send_query 是异步的，结果通过 on_reply('event_targets') 回调。
	 * 这里返回 null 表示"已发起查询，等回调"，
	 * 调用方（on_click_hand_card）据此不直接打出，而是等回调。
	 */
	console.log("[QUERY] query_event_targets called, card_id=", card_id)
	pending_event_card = inst_card_client(card_id)
	pending_event_targets = null
	pending_event_choice = null
	pending_event_spaces = null /* 新一轮选择，清空累积 */
	pending_event_pieces = null /* 同上：清空选部队累积 */
	/* 【2026-10-14】委托打牌时带上 nation=被委托国，服务端据此计算该国的事件目标 */
	send_query("event_targets", { card: card_id, nation: lend_lease_active || undefined })
	console.log("[QUERY] send_query returned")
	return null
}

/* 客户端取卡对象（从 view.hands 或 CARDS 里找） */
function inst_card_client(card_id) {
	/*
	 * 【2026-10-23 修复"卡名显示 ？"】
	 *
	 * 原实现只查 view.hand_cards / view.all_cards —— 而服务端【两个都不下发】
	 * （view 里只有 hands[nation].cards 与 table_cards[nation]），
	 * 于是永远走兜底 { name:"?", type:"?" }，
	 * 造成：《广阔的资源》委托卡名、事件卡打牌提示、17546 第 2 步"已选第 1 张"
	 * 全部显示"？"。
	 *
	 * 现改为按【服务端实际下发的字段】依次查找：
	 *   ① 本国手牌 -> ② 其它国手牌（委托/揭示）-> ③ 桌面卡 -> ④ 老字段（兼容）
	 * 匹配同时兼容实例 id（'15253#50'）与卡面 id（15253）。
	 */
	const id = String(card_id)
	const hit = (x) => x && (String(x.id) === id || String(x.card_id) === id)

	const hands = view.hands || {}
	const mine = (hands[view.my_nation] || {}).cards || []
	let c = mine.find(hit)
	if (c) return c

	for (const n of Object.keys(hands)) {
		if (n === view.my_nation) continue
		c = ((hands[n] || {}).cards || []).find(hit)
		if (c) return c
	}

	const tc = view.table_cards || {}
	for (const n of Object.keys(tc)) {
		c = (tc[n] || []).find(hit)
		if (c) return c
	}

	/* 兼容旧字段（若将来服务端补下发） */
	const hc = (view.hand_cards || []).find(hit)
	if (hc) return hc
	const ac = (view.all_cards || []).find(hit)
	if (ac) return ac

	return { id: card_id, name: "?", type: "?" }
}

/* 高亮可选地区，等玩家点地图 */
function highlight_event_targets(tg) {
	/*
	 * 【格式对齐】highlight_targets 期望 spaces 是 [{ id, reason }]，
	 * 不能传裸 id 数组（否则 s.id 为 undefined，地区不会被高亮）。
	 */
	const cands = (tg.candidates || []).map(c => ({
		id: c.id,
		reason: c.name || "",
	}))
	const card = pending_event_card
	if (!cands.length) {
		toast("《" + (card ? card.name : "?") + "》当前没有合法目标")
		cancel_event_card()
		return
	}
	highlight_targets({ spaces: cands, pieces: [] })
	/*
	 * 【2026-09-25 多选】已选的地区再加 .sel 边框，
	 * 让玩家能看出哪几个已选过、还差几个。
	 */
	if (tg.pick > 1 && pending_event_picks && pending_event_picks.length) {
		for (const id of pending_event_picks) {
			const el = space_elt(id)
			if (el) el.classList.add("sel")
		}
	}
	toast("《" + (card ? card.name : "?") + "》：请点击一个高亮地区" +
		(tg.pick > 1 ? "（选 " + tg.pick + " 个）" : ""))
	/* 多选时显示 Done 按钮 */
	update_event_done_button()
}

/*
 * 【2026-10-06】高亮可选【部队】（need:'piece'，15411 夜间运输）。
 *
 * 与 highlight_event_targets 的区别：候选是算子 id 不是地区 id，
 * 所以走 highlight_pieces（加 .pickable 类）而不是 highlight_targets。
 * 候选为空时统一走"当前没有合法目标 -> 取消"，与地区版保持一致。
 */
function highlight_event_pieces(tg) {
	const card = pending_event_card
	/*
	 * 【2026-10-22】update_map 每帧会按 pending_event_targets 重贴高亮；
	 * 多步卡（17825 铁托游击队）走完 need:null 收尾时 pending_event_card 已清空，
	 * 若 pending_event_targets 还留着 need:'piece'，这里会读 null.name 崩溃。
	 * 已不在选部队上下文时直接返回，收尾由 cancel_event_card 统一清靶。
	 */
	if (!card) return
	const cands = (tg.candidates || []).map(c => c.id)
	if (!cands.length) {
		toast("《" + (card ? card.name : "?") + "》当前没有合法目标")
		cancel_event_card()
		return
	}
	highlight_pieces(cands, "event_piece")
	toast("《" + card.name + "》：请点击一支高亮的部队")
}

/* 玩家点中了候选部队 -> 带上代价一起提交 play_card */
function submit_event_piece(pieceId) {
	const card = pending_event_card
	if (!card) return
	/*
	 * 【2026-10-21 战区移动转标准管线】多步卡（total>1）必须【累积后重查】，
	 * 不能像单步卡那样立刻提交 —— 否则这次提交里没有后续建设步骤的 spaces，
	 * 服务端会把它们判成"没有可建设的地区"而整卡失败；且后续选地区那次提交
	 * 又会丢掉这里的 piece，导致 remove 步读不到参数。
	 * 口径与选地区完全同款（见 on_click_space 里 total>1 的分支）。
	 */
	const total = (pending_event_targets && pending_event_targets.total) || 1
	if (total > 1) {
		const step = pending_event_targets.step != null ? pending_event_targets.step : 0
		if (!pending_event_pieces) pending_event_pieces = []
		pending_event_pieces[step] = pieceId
		send_query("event_targets", {
			card: card.id,
			pieces: pending_event_pieces.slice(),
			...(pending_event_spaces && pending_event_spaces.length
				? { spaces: pending_event_spaces.slice() } : {}),
			...(pending_event_choice != null ? { choice: pending_event_choice } : {}),
			nation: lend_lease_active || undefined,
		})
		toast("已选部队（第 " + (step + 1) + "/" + total + " 步）")
		clear_piece_highlight("event_piece")
		return
	}
	const arg = { card: card.id, piece: pieceId }
	/* 代价（弃牌）在 cancel_event_card 之前取出，否则会被清掉 */
	if (pending_echo_cards && pending_echo_cards.length)
		arg.cards = pending_echo_cards.slice()
	const nm = card.name
	lend_play_action(arg)
	toast("《" + nm + "》：对该部队生效")
	clear_piece_highlight("event_piece")
	cancel_event_card()
	update_hand_panel()
}

/*
 * 【2026-09-25 多选 Done 按钮】参考 pog 的右上角 Done 按钮。
 *
 * 显示/隐藏规则：
 *   · 进入 pending_event_targets 且 pick > 1 时显示
 *   · 选满 pick 个 -> 按钮变亮可点
 *   · 未选满 -> 按钮置灰
 *   · 离开 pending_event_targets -> 隐藏
 *
 * 点击 Done -> send_action("play_card", {card, picks})，与之前自动提交同。
 */
function update_event_done_button() {
	const btn = document.getElementById("btn_event_done")
	if (!btn)
		return
	const active = pending_event_card && pending_event_targets &&
		(pending_event_targets.pick || 1) > 1
	if (!active) {
		btn.classList.add("hide")
		return
	}
	btn.classList.remove("hide")
	/*
	 * 【2026-09-30】pickMin：卡面写"1 或 2 次""选择…的 3 支"时是【区间】，
	 * 选够 pickMin 就能点 Done（不必选满 pick）。
	 * 例：《进攻美国》pick=2/pickMin=1、《巴巴罗萨》pick=3/pickMin=1。
	 */
	const pickInfo = event_pick_range()
	const pick = pickInfo.max
	const pickMin = pickInfo.min
	const count = (pending_event_picks || []).length
	btn.textContent = count < pickMin
		? "Done（还差 " + (pickMin - count) + " 个）"
		: "Done (" + count + "/" + pick + (pickMin < pick ? "，至少 " + pickMin : "") + ")"
	btn.disabled = (count < pickMin || count > pick)
}

/* 当前多选 step 的"至少/最多"区间（未进入多选流程时给 1/1） */
function event_pick_range() {
	const tg = pending_event_targets
	if (!tg) return { min: 1, max: 1 }
	const max = tg.pick || 1
	const min = tg.pickMin || max
	return { min: min, max: max }
}

/*
 * 玩家点 Done -> 真正提交 picks。
 * 也作为单选可选的"二次确认"入口（暂不启用，单选直接点地区就提交）。
 */
function confirm_event_done() {
	if (!pending_event_card || !pending_event_targets)
		return
	const pickInfo = event_pick_range()
	const pick = pickInfo.max
	const pickMin = pickInfo.min
	/* 单选时 pending_event_picks 不存在 -> 不该走到这里 */
	if (pick <= 1) return
	const cnt = (pending_event_picks || []).length
	if (cnt < pickMin) {
		toast("还需选 " + (pickMin - cnt) + " 个地区（最多可选 " + pick + " 个）")
		return
	}
	if (cnt > pick) {
		toast("最多只能选 " + pick + " 个地区，请先取消一个")
		return
	}
	const arg = { card: pending_event_card.id, picks: pending_event_picks.slice() }
	/*
	 * 【2026-09-25 bug 修复】多选提交也按 pending step 发送 spaces 数组，
	 * 让多步卡（total>1）的服务端能正确拿到本步选的地区。
	 */
	if (pending_event_targets && pending_event_targets.step != null) {
		const sp = []
		sp[pending_event_targets.step] = pending_event_picks.slice()
		arg.spaces = sp
	}
	if (pending_event_choice != null)
		arg.choice = pending_event_choice
	if (pending_echo_cards && pending_echo_cards.length)
		arg.cards = pending_echo_cards.slice()
	lend_play_action(arg)
	toast("打出《" + pending_event_card.name + "》到 " +
		pending_event_picks.map(p => ((view.spaces[p] || {}).name || "?")).join("、"))
	cancel_event_card()
}

/* 二选一/四选一：在侧栏显示选项按钮 */
function show_event_choice(tg) {
	const box = document.getElementById("mode_chooser")
	if (!box) return

	/*
	 * 【2026-10-06 选项 A】若本步带弃牌代价（15408 山本五十六：弃 1 张响应牌），
	 * 先弹"选 N 张弃牌"框；确认后再回到本函数（由 confirm_echo_discard 以
	 * cost=null 的同 tg 重新调用），此时下面会正常渲染部署/调度选项。
	 */
	if (tg.cost && tg.cost.discard > 0) {
		pending_echo_discard = {
			card: pending_event_card,
			need_targets: tg,          // 弃牌确认后据此回到 show_event_choice
			drop: [],
			limit: tg.cost.discard,
			filter: (tg.cost && tg.cost.filter) || null,
			needBuild: (tg.cost && tg.cost.needBuild) || 0,
		}
		update_echo_discard_box()
		return
	}

	box.innerHTML = ""
	box.classList.remove("hide")

	const card = pending_event_card
	const opts = tg.options || []
	for (const opt of opts) {
		const b = document.createElement("button")
		b.className = "action"
		/*
		 * 【2026-10-23】字段兼容：服务端 options 存在三种写法
		 *   {index,label,disabled}（event_card_needs，本通道正确写法）
		 *   {id,label,enabled}    （红色管弦乐队等旧写法）
		 *   字符串数组             （pending_uranus，客户端不读）
		 * 这里统一读 index/id、disabled/enabled、label/name，
		 * 避免落到"选项 undefined"或提交 choice:undefined。
		 */
		const idx = (opt.index != null) ? opt.index : opt.id
		const isDisabled = !!opt.disabled || opt.enabled === false
		b.textContent = opt.label || opt.name || ("选项 " + (Number(idx) + 1))
		if (isDisabled) {
			/* 不合法选项：暗置（可见但不可点） */
			b.disabled = true
			b.classList.add("disabled")
			if (opt.reason) b.title = opt.reason
		} else {
			b.onclick = () => {
				pending_event_choice = idx
				box.classList.add("hide")
				/*
				 * 【2026-10-22 修复·17825 铁托游击队"没弹英国/苏联选择"】
				 * choice 之前可能已经选过【部队】（消灭敌方陆军）或地区；重查必须把
				 * 已累积的 pieces/spaces 一起带上，否则服务端读不到前序选择、
				 * 又退回 need:'piece'（选择框一闪就没 / 永远停在选部队）。
				 */
				const q = { card: card.id, choice: opt.index, nation: lend_lease_active || undefined }
				if (pending_event_pieces && pending_event_pieces.length) q.pieces = pending_event_pieces.slice()
				if (pending_event_spaces && pending_event_spaces.length) q.spaces = pending_event_spaces.slice()
				send_query("event_targets", q)
				/* 这次查询的 result 会带 need='space' 或 need=null */
			}
		}
		box.appendChild(b)
	}

	const cancel = document.createElement("button")
	cancel.className = "action"
	cancel.textContent = "取消"
	cancel.onclick = () => { box.classList.add("hide"); cancel_event_card() }
	box.appendChild(cancel)
}

/* 取消选目标 */
function cancel_event_card() {
	pending_event_card = null
	pending_event_targets = null
	pending_event_choice = null
	pending_event_picks = null
	pending_event_spaces = null
	pending_event_pieces = null
	pending_echo_discard = null
	pending_echo_cards = null
	clear_target_highlight()
	/* 【2026-10-06】选部队（need:'piece'）的高亮也要一并清掉 */
	clear_piece_highlight("event_piece")
	/* 隐藏 Done 按钮（参考 pog） */
	const btn = document.getElementById("btn_event_done")
	if (btn) btn.classList.add("hide")
}

function on_click_hand_card(c, d) {
	/*
	 * 有待决事项时手牌不可点：此时只能回答挂起的那一个问题
	 * （服务端也会拦下其它动作，这里提前挡掉，免得"点了没反应"）。
	 */
	if (view.pending_battle || view.pending_trigger || view.pending_econ ||
		view.pending_uranus || view.pending_status_play || view.pending_autobahn || view.pending_script || view.pending_armed_delegate ||
		view.uk_build_delegate || view.su_build_delegate ||
		view.us_china_build ||
		view.us_theater_delegate || view.us_replay ||
		view.us_merchant || (view.delegate && view.delegate.mode === 'single') || view.us_political) {
		toast("请先完成当前的让权建设事项（点击地图上高亮的地区，由英国/苏联建设；或美国帮中国征召/战区移动）")
		return
	}
	/*
	 * 【2026-10-21 方案 B】事件卡停在步骤边界时，手牌不可点（该卡已离手，
	 * 这里挡的是"想去打别的牌"——必须先处理窗口并点「下一步」把当前卡走完）。
	 * 服务端 build_actions 同步不放行 play_card，两端同源。
	 */
	if (view.pending_event_step) {
		toast("请先完成《" + (view.pending_event_step.card_name || "当前") +
			"》的剩余步骤（点侧栏「下一步」）")
		return
	}
	/* 初始阶段：点手牌 = 选/取消一张弃牌（最多 3 张） */
	if (view.opening) {
		if (!is_my_turn()) {
			toast("初始阶段：等待【" + view.opening.current_nation + "】弃 3 张，本方暂不可操作")
			return
		}
		const i = discard_pick.indexOf(c.id)
		if (i >= 0)
			discard_pick.splice(i, 1)
		else if (discard_pick.length < 3)
			discard_pick.push(c.id)
		else
			toast("初始阶段：只需弃 3 张，请先取消一张")
		update_hand_panel()
		update_phase_buttons()
		toast(discard_pick.length
			? "已选 " + discard_pick.length + "/3 张，点【确认弃 3 张】提交"
			: "已取消选择")
		return
	}
	/* 16703 罗马尼亚铁卫团：德国弃牌摸牌 —— 点手牌=弃置该牌并摸1张 */
	if (ask_state && ask_state.kind === 'italy_german_draw') {
		send_action('italy_german_draw', { card_id: c.id })
		return
	}
	/* 17553 抗日义勇军：让权日本 —— 点手牌=弃置该牌并损耗1张 */
	if (ask_state && ask_state.kind === 'us_japan_delegate') {
		send_action('resolve_japan_delegate', { card: c.id })
		return
	}

	/* 状态卡弃牌代价选择：点手牌 = 选/取消一张弃牌 */
	if (status_discard_sel) {
		on_status_discard_pick(c.id)
		return
	}
	/* ① 资源再分配：选 / 取消 一张弃牌代价 */
	if (pending_resource) {
		const i = pending_resource.drop.indexOf(c.id)
		if (i >= 0)
			pending_resource.drop.splice(i, 1)
		else if (pending_resource.drop.length < 3)
			pending_resource.drop.push(c.id)
		else
			toast("代价只需 3 张，请先取消一张")
		update_resource_box()
		update_hand_panel()
		return
	}
	/* ①b 一步式选牌（国家技能 / 增强卡 15412）：点手牌 = 选 / 取消一张 */
	if (pending_skill_discard) {
		const pd = pending_skill_discard
		/*
		 * 【2026-10-06】增强卡复用本弹窗时，本卡（正在打出的那张）
		 * 既不能作代价、也不能作"要打出的牌"。
		 */
		if (pd.submit_card && c.id === pd.submit_card) {
			toast("本卡不能作为自己的代价，也不能作为要打出的牌")
			return
		}
		/*
		 * 【2026-10-05】代价限定类型时（日本：只弃响应牌），
		 * 点非该类型的牌应明确拒绝，而不是静默无反应。
		 */
		if (pd.filter) {
			const want = String(pd.filter === 'response' ? 'RESPONSE' : pd.filter).toUpperCase()
			if (String(c.type || '').toUpperCase() !== want) {
				toast("代价必须是" + (pd.filter === 'response' ? '响应牌' : pd.filter) +
					"，这张是" + (c.type || '?'))
				return
			}
		}
		/*
		 * 【2026-10-05】一步模式（日本）：先选代价，再选要打出的牌。
		 *   drop 未满 -> 点牌 = 选作代价
		 *   drop 已满 -> 点牌 = 选作【打出】（不能是已选作代价的那张）
		 * 两步模式仍只选代价。
		 */
		const i = pd.drop.indexOf(c.id)
		if (pd.one_step && pd.drop.length >= pd.need) {
			if (i >= 0) {
				toast("这张已选作代价，不能同时打出 —— 请先取消它")
				return
			}
			pd.play = (pd.play === c.id) ? null : c.id
			update_skill_discard_box()
			update_hand_panel()
			return
		}
		if (i >= 0)
			pd.drop.splice(i, 1)
		else if (pd.drop.length < pd.need)
			pd.drop.push(c.id)
		else
			toast("代价只需 " + pd.need + " 张，请先取消一张")
		update_skill_discard_box()
		update_hand_panel()
		return
	}

	/* 17555 大萧条的余波 ①：点手牌 = 选 / 取消一张弃牌（最多 1 张） */
	if (pending_depression_discard) {
		const i = pending_depression_discard.drop.indexOf(c.id)
		if (i >= 0)
			pending_depression_discard.drop.splice(i, 1)
		else if (pending_depression_discard.drop.length < 1)
			pending_depression_discard.drop.push(c.id)
		else {
			toast("只需弃 1 张，请先取消一张")
			return
		}
		update_us_depression_discard_box()
		update_hand_panel()
		return
	}

	/*
	 * ①'. ECHO/EVENT 卡选弃牌代价（2026-09-25 新增）
	 *
	 * 流程与"资源再分配选 3 张"同构，但张数由卡牌配置（limit）。
	 * 不允许选自己（本卡）—— 本卡打出后会进弃牌堆，不算代价。
	 */
	if (pending_echo_discard) {
		if (c.id === pending_echo_discard.card.id) {
			toast("本卡不能作为自己的代价")
			return
		}
		const i = pending_echo_discard.drop.indexOf(c.id)
		if (i >= 0)
			pending_echo_discard.drop.splice(i, 1)
		else if (pending_echo_discard.drop.length < pending_echo_discard.limit)
			pending_echo_discard.drop.push(c.id)
		else
			toast("代价只需 " + pending_echo_discard.limit + " 张，请先取消一张")
		update_echo_discard_box()
		update_hand_panel()
		return
	}

	/* ② 空军调度：选 1 张手牌作为弃牌代价 */
	if (air_move) {
		air_move.card = (air_move.card === c.id) ? null : c.id
		update_air_box()
		update_hand_panel()
		return
	}

	/* ③ 资源阶段但还没打开面板 -> 提示先点按钮 */
	if (view.turn_phase === "resource") {
		toast("资源再分配：请先点【资源再分配…】按钮")
		return
	}

	/*
	 * ④ 出牌阶段②：弃牌模式（点了【弃 1 张手牌】按钮）——
	 * 这是"弃牌"动作，不是"打牌"，所以先于阶段限制判定。
	 */
	if (discard_mode && view.turn_phase === "play") {
		send_action("discard_one", { card: c.id })
		toast("弃置《" + c.name + "》")
		discard_mode = false
		return
	}

	/*
	 * ⑤ 弃牌阶段：点手牌分两种模式。
	 *   · 打牌模式（btn_discard_playmode 切换）：
	 *       点【可打出】的时点卡 -> 落到下方 ⑥/⑦ 打牌流程；
	 *       不可打出的牌提示后忽略（退出打牌模式后可框选弃置）。
	 *   · 弃牌模式（默认）：点手牌 = 【框住选中】（可多选），
	 *       再用侧栏的【确认弃牌】按钮一次性提交。
	 */
	if (view.turn_phase === "discard") {
		if (discard_playmode) {
			const _hr5 = view.hand_ready && view.hand_ready[c.id]
			if (_hr5 && _hr5.ok) {
				/* 可打出：落到下方 ⑥ 阶段判定 / ⑦ 打牌流程，不在此 return */
			} else {
				toast("《" + c.name + "》本阶段不可打出，退出打牌模式后可框选弃置")
				return
			}
		} else {
			const i = discard_pick.indexOf(c.id)
			if (i >= 0)
				discard_pick.splice(i, 1)
			else
				discard_pick.push(c.id)
			update_hand_panel()
			update_phase_buttons()
			toast(discard_pick.length
				? "已选中 " + discard_pick.length + " 张，点【确认弃牌】提交"
				: "已取消选择")
			return
		}
	}

	/*
	 * ⑥ 阶段限制统一判定（与 rules.js 的 check_phase_for_card 一致）。
	 *
	 * 【2026-09-25 修正】旧注释写"增强卡不受阶段限制，永远放行"是过时的。
	 * 增强卡现在按【时点】打出（CARD_TRIGGERS），时机不对会被拒。
	 * check_phase_for_card 内部已镜像服务端的 trigger_ready()。
	 */
	/*
	 * 【2026-10-01】与置灰【同源】：优先用服务端下发的 view.hand_ready。
	 * 否则会出现"彩色可点、点了被服务端拒绝"（增强卡尤甚，见上方置灰处注释）。
	 */
	const _hr = view.hand_ready && view.hand_ready[c.id]
	const chk = _hr ? { ok: _hr.ok, reason: _hr.reason } : check_phase_for_card(c)
	if (!chk.ok) {
		toast("无法打出《" + c.name + "》：" + (chk.reason || "时机不对"))
		return
	}

	/* ⑦ 基本卡：进入选目标流程 */
	if (c.type === "BASIC") {
		start_basic_card(c)
		return
	}

	/*
	 * ⑦' ECON 经济战卡（2026-09-26）
	 *
	 * · 15313 轰炸机军团：需要【打出方】先选目标国（德国/意大利）。
	 *   损耗张数 = 2 + 2×英国空军数，服务端算，客户端不重复推算
	 *   （view.pieces 是按代表国过滤的、键也不是 id，见 docs/pitfalls.md）。
	 * · 15314 马耳他潜艇群：无需参数，直接打出，服务端建立链式挂起，
	 *   由受击方（德国、意大利）依次在自己的界面答复。
	 */
	if (c.type === "ECON") {
		/*
		 * 【2026-09-30 A 方案通用化】ECON 卡目标国由服务端在 view 手牌对象里
		 * 下发到 econ_targets 字段，取代原先只硬编码 15313 一个 if 的写法：
		 *   · 多目标（length>1）-> 弹选国框让玩家选 1 个；
		 *   · 单目标（length===1）-> 自动带该 target 打出，无需弹窗；
		 *   · 无 targets（如 15314 用 chain 链式挂起）-> 直接打出，
		 *     由受击方在自己界面经 pending_econ 答复。
		 */
		const tg = c.econ_targets
		if (tg && tg.length > 1) {
			render_ask_box(
				"《" + c.name + "》选择目标国",
				"让哪个国家损耗牌？（张数与具体效果由服务端按卡面计算）",
				tg.map(n => ({
					label: n, cls: "primary",
					onClick: () => {
						render_ask_box(null)
						ask_state = null
						lend_play_action({ card: c.id, target: n })
						toast("《" + c.name + "》—— 目标：" + n)
					},
				})))
			return
		}
		if (tg && tg.length === 1) {
			/* 单目标自动带参打出，无需弹窗 */
			lend_play_action({ card: c.id, target: tg[0] })
			toast("打出《" + c.name + "》—— 目标：" + tg[0])
			return
		}
		/* 无 targets：直接打出（如 15314 链式卡） */
		lend_play_action({ card: c.id })
		toast("打出《" + c.name + "》")
		return
	}

	/*
	 * ⑧ EVENT / ECHO 卡：先查可选目标，等 on_reply 回调后高亮地区。
	 *
	 * 【2026-09-25 修正】之前简化成"直接 send_action 不查目标"，
	 * 但服务端返回 pending 状态后，客户端拿不到 candidates —— 也就是
	 * 既不显示选区高亮，也不弹任何 UI，看起来就是"点了没反应"。
	 *
	 * ECHO 卡与 EVENT 卡走同一个流程：
	 *   1) send_query('event_targets', {card}) 让服务端跑 resolve_event_card
	 *      （只查询，不真正执行），返回 candidates + need
	 *   2) on_reply('event_targets') 设 pending_event_targets
	 *   3) update_event_targets() 高亮可选地区
	 *   4) 玩家点地区 -> send_action("play_card", {card, space})
	 *
	 * 服务端 query('event_targets') 已用 card_effect_of（不区分 EVENT/ECHO），
	 * 因此 ECHO 卡走这条路天然可用。
	 */
	/*
	 * 【2026-09-30 德国增强】德国"出牌阶段开始时"增强卡不走 query 流程，
	 * 直接 send_action 让服务端驱动 event_budget / pending_echo / peek 三种挂起。
	 * 修饰类卡（15213/15216）无候选地区，query 会卡死，必须直发。
	 */
	if (is_de_play_start_effect(c.id)) {
		send_action("play_card", { card: c.id })
		console.log("[ECHO-DE] 直接打出", c.id, c.name)
		toast("打出《" + c.name + "》")
		return
	}
	query_event_targets(c.id)
	console.log("[ECHO] clicked", c.id, c.name, "phase=", view.turn_phase,
		"trig=", view.card_triggers && view.card_triggers[String(c.card_id || c.id)])
	toast("《" + c.name + "》：选择目标地区")
}

/*
 * 【2026-09-30 德国增强】德国"出牌阶段开始时"增强卡直接 send_action，
 * 由服务端驱动三种挂起状态：
 *   - 14500/15209 战斗 -> event_budget（客户端已有面板）
 *   - 15214 战术革新  -> pending_echo（自定义两步选牌）
 *   - 15215 卓越规划  -> view.peek（topBottom 检视）
 *   - 15213/15216 修饰 -> 直接结算
 * 不走 query_event_targets（修饰类卡无候选地区会卡死）。
 */
const DE_PLAY_START_EFFECT = {
	'14500': 1, '15209': 1, '15213': 1, '15214': 1, '15215': 1, '15216': 1,
}
function is_de_play_start_effect(cardId) {
	return !!DE_PLAY_START_EFFECT[String(cardId || '').split('#')[0]]
}

/* 悬停放大（PoG 的 on_focus_card_tip 同构） */
function on_focus_card(c) {
	const tip = document.getElementById("tooltip")
	if (!tip)
		return
	tip.innerHTML = ""
	tip.className = ""
	const big = build_card_elt(c)
	big.style.pointerEvents = "none"
	tip.appendChild(big)
	tip.hidden = false
}

function on_blur_card() {
	const tip = document.getElementById("tooltip")
	if (tip)
		tip.hidden = true
}

/*
 * 【2026-10-28 性能】手牌区增量刷新状态。
 *
 *   hand_mode : "mine" | "opp" —— 上一次渲染的是本方手牌还是对手牌背，
 *               分支切换时必须整体清空（两套 DOM 不通用）
 *   hand_sig  : 上一次渲染的"状态签名"。签名不变 = 外观输出必然完全相同，
 *               直接 return，连一次 DOM 写都不做。
 */
let hand_mode = null
let hand_sig = null

/* 选中类集合 -> 参与签名的短字符串（顺序敏感：弃牌序号会显示在角标上） */
function hand_pick_sig(arr) {
	return arr && arr.length ? arr.join(",") : ""
}

function update_hand_panel() {
	const n = view.my_nation

	/*
	 * 【2026-09-28】先清掉悬停大图（#tooltip）。
	 *
	 * 为什么必须在这里清：tooltip 的隐藏依赖卡元素的 mouseleave 事件，
	 * 但手牌区重绘是【直接替换 DOM】(innerHTML/重建)，旧元素被移除时
	 * 【不会】触发 mouseleave —— 于是打出卡后，那张卡的大图会一直挂在屏幕上。
	 * 任何"重建手牌 DOM"的入口都要跟着清一次，这里是最集中的那个。
	 *
	 * 仅在真的显示着时才清，避免每次重绘都无谓地改 DOM。
	 */
	{
		const tip = document.getElementById("tooltip")
		if (tip && !tip.hidden) {
			tip.hidden = true
			tip.innerHTML = ""
		}
	}

	/*
	 * 阶段标志统一在函数【开头】声明。
	 * 踩过的坑：这几个 const 原本散落在下面，而上面的状态文字分支
	 * 先用到了 isDiscardPhase，触发 TDZ 报错
	 * "Cannot access 'isDiscardPhase' before initialization"。
	 */
	const isResource = view.turn_phase === "resource"
	const isPlay = view.turn_phase === "play"
	const isAir = view.turn_phase === "airforce"
	const isDiscardPhase = view.turn_phase === "discard"

	/*
	 * 初始阶段：是否轮到【本方】弃牌。
	 * view.opening 只在"处于初始阶段"时为真，但 6 国依次弃牌，
	 * 只有当前弃牌国所属阵营的客户端才能真正操作（game.active 已切到该国阵营）。
	 * 非本方回合应进入"等待对方弃牌"状态，手牌不可选、确认按钮不显示。
	 */
	const openingMine = !!(view.opening && is_my_turn())

	/* 【2026-10-24】原 "XX 的手牌" 一行已删（与下方 Hand 面板标题重复） */
	set_text("hand_ap", n
		? (view.extra_play && view.extra_play.phase === view.turn_phase
			/* 【2026-10-11】额外打出权提示覆盖【任何生效阶段】（出牌/摸牌…），
			 * 不再写死只在 play 阶段显示 —— 英国国家技能在摸牌阶段触发时也需要提示。
			 * 注意：set_text 用 textContent，这里【不能】esc()，否则会显示转义字符 */
			? ("因《" + view.extra_play.source_name + "》" +
				extra_play_hint() + "（不用就直接推进阶段）")
			: (view.turn_phase === "play"
				? (view.my_play_done
					? (view.extra_play
						? "出牌阶段：因《" + view.extra_play.source_name + "》" +
							extra_play_hint() + "（不用就直接推进阶段）"
						: "出牌阶段：已行动")
					: "出牌阶段：打出 / 弃置 / 减 1 分")
				: (view.turn_phase === "airforce"
					? (view.my_air_done
						? "空军阶段：已行动"
						: "空军阶段：打出《空军力量》 / 弃 1 张牌调度（二选一）")
					: (view.turn_phase === "resource"
						? (view.my_swap_count
							? "资源再分配：本回合已用完"
							: (pending_resource
								? "资源再分配：已选 " + pending_resource.drop.length + "/3 张代价"
								: "资源再分配：可弃 3 张换 1 张基本卡（每回合一次）"))
						: (isDiscardPhase
							? ("弃牌阶段：点手牌框住选择，再点【确认弃牌】" +
								"（已选 " + discard_pick.length + " 张，本阶段已弃 " +
								view.my_discard_count + " 张）")
							: (discard_mode ? "弃牌模式" : ""))))))
		: "")

	/*
	 * 【2026-10-24】原 "牌堆 N · 弃牌 N" 一行已删：
	 * "各国牌库"浮层里已有六国的牌堆/弃牌/后备数据，这里纯重复。
	 */

	/* 【2026-09-29】各国牌库面板：服务端已在 view.deck_counts / discard_counts
	 * 里给出【全部六国】数据（以前只显示本国），这里展开显示。 */
	update_deck_panel()
	/* 【2026-10-18】各国后备面板：服务端已在 view.reserve_info 给出各国陆/海/空剩余可建容量与总数 */
	update_reserve_panel()

	const box = document.getElementById("hand_cards")
	const note = document.getElementById("hand_limit_note")
	if (!box)
		return

	/* 非本方回合：只显示对手手牌张数（牌背） */
	if (!n) {
		const hands = view.hands || {}
		if (note)
			note.textContent = ""

		/*
		 * 【2026-10-28 性能】对手牌背同样走签名比对：
		 * 张数没变就整块跳过（原来每帧清空 + 重建）。
		 */
		let osig = "opp"
		for (const k of Object.keys(hands))
			osig += "|" + k + "×" + (hands[k].count || 0)
		if (hand_mode === "opp" && osig === hand_sig)
			return
		hand_mode = "opp"
		hand_sig = osig
		box.innerHTML = ""
		ui.hand_el = {}

		let any = false
		for (const k of Object.keys(hands)) {
			if (!hands[k].count)
				continue
			any = true
			const d = document.createElement("div")
			d.className = "hand_back"
			d.textContent = k + " ×" + hands[k].count
			box.appendChild(d)
		}
		if (!any)
			box.innerHTML = '<div class="hand_empty">（对手无手牌）</div>'
		return
	}

	const cards = (view.hands[n] && view.hands[n].cards) || []
	const handLen = (view.hands[n] && view.hands[n].count) || 0
	/*
	 * 本阶段配额是否已用完 —— 【按阶段】判断，不能跨阶段误伤。
	 * （曾经写成 playDone || (airforce && my_air_done)，导致出牌阶段
	 *   用掉配额后，空军阶段打《空军力量》也被置灰。）
	 */
	const quotaUsed =
		(isPlay && view.my_play_done) || (isAir && view.my_air_done)

	/* 手牌上限提示 */
	if (note) {
		if (handLen > HAND_LIMIT) {
			if (openingMine) {
				note.textContent = "（初始布阵：手牌 " + handLen + " 张，选 3 张弃掉留 7）"
				note.className = ""
			} else if (view.opening) {
				note.textContent = "（初始布阵：等待【" + view.opening.current_nation + "】弃 3 张，本方暂不可操作）"
				note.className = ""
			} else {
				/* 【2026-10-23】弃牌阶段超限改为玩家自选：提示要选几张，而不是"将自动弃到 7" */
				const _hl2 = view.pending_hand_limit
				note.textContent = (_hl2 && _hl2.nation === view.my_nation && _hl2.need > 0)
					? ("（" + handLen + "/" + HAND_LIMIT + " 超出 " + _hl2.need +
						" 张：点手牌框选，再点【确认弃 " + _hl2.need + " 张】）")
					: ("（" + handLen + "/" + HAND_LIMIT +
						" 超出 " + (handLen - HAND_LIMIT) + " 张，弃牌阶段将弃到 " + HAND_LIMIT + "）")
				note.className = "over"
			}
		} else {
			note.textContent = "（" + handLen + "/" + HAND_LIMIT + "）"
			note.className = ""
		}
	}

	/*
	 * 【2026-10-28 性能】先算"状态签名"，签名不变就直接返回。
	 *
	 * 签名只包含【本函数会读到的所有输入】（阶段、配额、各选择集、
	 * 服务端 hand_ready 判定、armed_offer、额外打出权…）。
	 * 输入完全相同 -> 输出必然完全相同 -> 一个 DOM 都不用碰。
	 *
	 * 注：只要有任意一张牌缺 hand_ready（此时会兜底走本地
	 * check_phase_for_card()，而它读的 view 字段未全部纳入签名），
	 * 就放弃跳过（sig=null），宁可多绘一次也不能画出旧状态。
	 */
	let sig = null
	{
		const parts = [n, handLen, view.turn_phase,
			quotaUsed ? 1 : 0,
			discard_mode ? 1 : 0, discard_playmode ? 1 : 0,
			openingMine ? 1 : 0,
			view.opening ? (view.opening.current_nation || "") : "",
			pending_card ? pending_card.id : "",
			/*
			 * 注意：这里是"有没有"而不是"选了什么"。
			 * 基本卡角标的分支条件是 `!pending_resource && !air_move`，
			 * 所以 pending_resource 由 null 变成 {drop:[]} 也要算变化
			 * （否则角标摘不掉，出现"画面和状态不一致"）。
			 */
			pending_resource ? 1 : 0,
			air_move ? 1 : 0,
			hand_pick_sig(pending_resource && pending_resource.drop),
			hand_pick_sig(pending_skill_discard && pending_skill_discard.drop),
			air_move ? air_move.card : "",
			hand_pick_sig(discard_pick),
			hand_pick_sig(pending_echo_discard && pending_echo_discard.drop),
			hand_pick_sig(status_discard_sel && status_discard_sel.picked),
			hand_pick_sig(pending_depression_discard && pending_depression_discard.drop),
			((view.armed_offer && view.armed_offer.cards) || []).map(x => x.card).join(","),
			view.extra_play
				? (view.extra_play.phase + "/" + view.extra_play.source_name + "/" +
					(view.extra_play.filter || "") + "/" +
					(view.extra_play.cards || []).join(","))
				: ""]
		let allHr = true
		for (const c of cards) {
			const hr = view.hand_ready && view.hand_ready[c.id]
			if (!hr)
				allHr = false
			parts.push(c.id + ":" + c.type + ":" + c.name + ":" +
				(hr ? ((hr.ok ? "1" : "0") + (hr.reason || "")) : "") + ":" +
				(extra_play_allows_card(c) ? 1 : 0) +
				(is_airforce_only(c) ? 1 : 0) +
				(is_timing_card(c) ? 1 : 0))
		}
		sig = allHr ? parts.join("|") : null
	}

	if (hand_mode !== "mine") {
		/* 从"对手牌背"切回本方手牌：两套 DOM 不通用，整体清空 */
		box.innerHTML = ""
		ui.hand_el = {}
		hand_mode = "mine"
	}
	if (sig && sig === hand_sig)
		return
	hand_sig = sig

	if (!cards.length) {
		box.innerHTML = '<div class="hand_empty">（无手牌）</div>'
		ui.hand_el = {}
		return
	}
	/* 上一帧留下的"（无手牌）"占位，本帧已经有牌了，先摘掉 */
	{
		const empty = box.querySelector(".hand_empty")
		if (empty)
			empty.remove()
	}

	/*
	 * 这里【只负责外观】，点击行为一律由 on_click_hand_card() 在点击时
	 * 现算（原因见 build_card_elt 的注释：渲染时机与异步 query 会错开）。
	 */
	for (const c of cards) {
		/*
		 * 【2026-10-28 性能】元素复用：同一张牌沿用上一帧的 DOM，
		 * 只有本帧新出现的牌才 build_card_elt()。
		 * 原来每帧 box.innerHTML = "" 后重建全部卡元素 —— 卡图 probe、
		 * 事件绑定、背景图样式全部重做，点一次牌就是一次全量销毁重建，
		 * 这是"点牌延迟"的主要来源之一。
		 *
		 * 元素复用后必须【显式复位】那些以前靠"重建"天然复位的状态：
		 * 置灰 reason 写进 title、disabled/pending_card 类、角标 span。
		 */
		let d = ui.hand_el[c.id]
		if (d) {
			d.__card = c
			d.card = c
			for (const b of Array.prototype.slice.call(d.querySelectorAll(".badge")))
				b.remove()
			d.classList.remove("disabled")
			d.title = d.__base_title || ""
		} else {
			d = build_card_elt(c)
			ui.hand_el[c.id] = d
		}

		/*
		 * 选中的牌高亮（共用 .sel 边框）：
		 *   · 资源再分配的代价
		 *   · 【2026-10-01】国家技能的弃牌代价（英国国家技能）
		 *   · 空军调度的弃牌代价
		 *   · 弃牌阶段被框住的牌
		 */
		const isCostSelected =
			(pending_resource && pending_resource.drop.indexOf(c.id) >= 0) ||
			(pending_skill_discard && pending_skill_discard.drop.indexOf(c.id) >= 0) ||
			(air_move && air_move.card === c.id) ||
			(isDiscardPhase && discard_pick.indexOf(c.id) >= 0) ||
			(openingMine && discard_pick.indexOf(c.id) >= 0) ||
			(pending_echo_discard && pending_echo_discard.drop.indexOf(c.id) >= 0) ||
			(status_discard_sel && status_discard_sel.picked.indexOf(c.id) >= 0) ||
			(pending_depression_discard && pending_depression_discard.drop.indexOf(c.id) >= 0)
		d.classList.toggle("sel", !!isCostSelected)

		/*
		 * 置灰条件：直接用与点击判定同一套逻辑（check_phase_for_card），
		 * 保证"看起来能点"和"点了能成功"永远一致。
		 *   · 弃牌阶段：任何手牌都能弃 -> 不置灰
		 *   · 其他阶段：不可打出的牌置灰
		 *
		 * 【2026-09-25 修正】旧逻辑加了 `!is_enhance_card(c) &&` 前缀，
		 * 意思是"增强卡永远不灰"——这是过时语义（增强卡现在按时点打出）。
		 * 去掉这个前缀后，增强卡在错阶段也会置灰（与 check_phase_for_card 一致）。
		 */
		/*
		 * 【2026-10-01】优先用服务端下发的【同源】判定 view.hand_ready。
		 *
		 * 旧逻辑里有一句兜底 `if (is_enhance_card(c)) return { ok: true }`
		 * ——"增强卡永远可打"。但服务端早已改成按时点判定（trigger_ready），
		 * 于是增强卡（15213 云雾 / 15212 G7e 鱼雷…）在客户端【永远不置灰】，
		 * 点了却被服务端拒绝：典型的"看得见可点、点了被拒"（pitfalls R3）。
		 *
		 * 现在服务端把每张手牌的判定结果直接下发，客户端照抄即可，不再自己猜。
		 */
		const hr = view.hand_ready && view.hand_ready[c.id]
		/*
		 * 【2026-10-18 修复】armed 增强卡（事件触发型：15351/15352/15353/15355/17854/17855…）
		 * 只能在 view.armed_offer 窗口内打出，平时不可主动打出（check_phase_for_card 判为 load）。
		 * 此前这类卡在窗口内仍被 .disabled 置灰，与"此刻实际可打出"不一致。
		 * 现以服务端下发的 armed_offer 为准：窗口内的手牌卡【不置灰并加"可打出"高亮】，
		 * 使手牌高亮与实际是否允许打出严格一致（不影响其它卡牌类型/旧批次增强卡）。
		 */
		const armedCards = (view.armed_offer && view.armed_offer.cards) || []
		const inArmedOffer = armedCards.some(x => x.card === c.id)
		if (inArmedOffer) {
			d.classList.remove("disabled")
		} else if (view.turn_phase !== "discard" && !openingMine &&
			(hr ? !hr.ok : !check_phase_for_card(c).ok)) {
			d.classList.add("disabled")
		}
		if (hr && !hr.ok && hr.reason)
			d.title = hr.reason
		if (inArmedOffer) {
			const b = document.createElement("span")
			b.className = "badge play"
			b.textContent = "可打出"
			d.appendChild(b)
		}

		if (discard_playmode && hr && hr.ok) {
			/* 弃牌阶段·打牌模式：可打出的时点卡标"打" */
			const b = document.createElement("span")
			b.className = "badge play"
			b.textContent = "打"
			d.appendChild(b)
		} else if (isDiscardPhase || openingMine) {
			/* 弃牌阶段 / 初始阶段：被框住的牌标序号，方便核对 */
			if (isCostSelected) {
				const b = document.createElement("span")
				b.className = "badge"
				b.textContent = "弃 " + (discard_pick.indexOf(c.id) + 1)
				d.appendChild(b)
			}
		} else if (discard_mode) {
			const b = document.createElement("span")
			b.className = "badge"
			b.textContent = "弃"
			d.appendChild(b)
		} else if (status_discard_sel && status_discard_sel.picked.indexOf(c.id) >= 0) {
			const b = document.createElement("span")
			b.className = "badge"
			b.textContent = "弃置 " + (status_discard_sel.picked.indexOf(c.id) + 1)
			d.appendChild(b)
		} else if (pending_depression_discard && pending_depression_discard.drop.indexOf(c.id) >= 0) {
			const b = document.createElement("span")
			b.className = "badge"
			b.textContent = "弃"
			d.appendChild(b)
		} else if (view.extra_play && extra_play_allows_card(c)) {
			/*
			 * 【2026-09-30】额外打出：《战略规划》等卡结算后，
			 * 只有【可额外打出的那几张】亮着（其余已被上面的 .disabled 置灰），
			 * 这里再挂个角标，让"为什么这张能点/那张不能点"一目了然。
			 */
			const b = document.createElement("span")
			b.className = "badge"
			b.textContent = "额外打出"
			d.appendChild(b)
			d.classList.remove("disabled")
		} else if (c.type === "BASIC" && !isResource && !quotaUsed &&
			!pending_resource && !air_move) {
			/*
			 * 可打出的基本卡标"选目标"。
			 * 空军阶段只有《空军力量》能打，其余基本卡（建设/战斗）
			 * 标"需出牌阶段"，避免玩家误以为此刻可用。
			 */
			const b = document.createElement("span")
			b.className = "badge"
			if (isAir && c.name !== "空军力量")
				b.textContent = "需出牌阶段"
			else if (!isAir && is_airforce_only(c))
				b.textContent = "需空军阶段"
			else
				b.textContent = "选目标"
			d.appendChild(b)
		} else if (isAir && is_timing_card(c)) {
			/* 时机卡在空军阶段仍可打出，给个提示 */
			const b = document.createElement("span")
			b.className = "badge"
			b.textContent = "时机"
			d.appendChild(b)
		}

		/* 正在等待选目标的卡加高亮描边（元素复用 -> 必须 toggle，否则上一帧的高亮摘不掉） */
		d.classList.toggle("pending_card", !!(pending_card && pending_card.id === c.id))

		/* appendChild 对已在父节点下的元素是"移动"，顺手完成重排，不重建 */
		box.appendChild(d)
	}

	/* 已不在手牌里的元素（打出了 / 被弃了）要销毁，否则会残留 */
	const alive = {}
	for (const c of cards)
		alive[c.id] = true
	for (const id of Object.keys(ui.hand_el)) {
		if (!alive[id]) {
			ui.hand_el[id].remove()
			delete ui.hand_el[id]
		}
	}
}

/* ============================================================
 * 资源再分配（easy_rule 二.1）
 *
 * 弃 3 张手牌 -> 从牌堆挑 1 张基本卡置入手牌 -> 洗混牌堆。
 * 交互：点【资源再分配】按钮 -> 查牌堆基本卡 -> 先选要的基本卡，
 *       再点手牌选 3 张代价 -> 点【确认】提交。
 * ============================================================ */

let pending_resource = null    /* { basics:[...], take: id|null, drop: [ids] } */

/* 【2026-10-01】国家技能"弃牌代价"的临时选择状态（英国国家技能用）
 * { drop: [ids], need: N, source_name } —— 只存在于客户端，负责收集 drop */
let pending_skill_discard = null
/* 17555 大萧条的余波 ①：客户端收集"强制自选弃 1 张手牌"的临时状态（仅存在于客户端） */
let pending_depression_discard = null

/* ============================================================
 * 空军阶段②：弃 1 张手牌，调度 1 支空军
 *
 * 流程：点【调度空军…】-> 查 air_options 拿到本国空军与合法目标
 *       -> 选 1 张要弃的手牌（面板里点）-> 选空军 -> 选目标地区
 *       -> send_action('air_support', {air, target, card})
 * ============================================================ */

let air_move = null   /* { airs:[], targets:[], air:null, card:null } */

function start_air_move() {
	if (air_move) {
		cancel_air_move()
		return
	}
	air_move = { airs: [], targets: [], air: null, card: null }
	send_query("air_options", null)
}

function cancel_air_move() {
	air_move = null
	update_air_box()
	update_hand_panel()
}

/*
 * 空军调度提示：用 #ask_box（不再与资源弹框抢容器）。
 * 调度仍走地图：先点 1 支空军算子，再点目标地区。
 */
function update_air_box() {
	if (!air_move) {
		if (ask_state && ask_state.kind === "airmove") {
			ask_state = null
			render_ask_box(null)
		}
		return
	}
	ask_state = { kind: "airmove" }
	render_ask_box(
		"调度空军（弃 1 张手牌）",
		"① 点下方手牌选代价：" + (air_move.card ? "已选" : "未选") +
		"　② 点地图上的本国空军：" + (air_move.air || "未选") +
		"　③ 点目标地区：" + (air_move.target
			? ((view.spaces[air_move.target] || {}).name || "?") : "未选") +
		"　（可选空军 " + air_move.airs.length + " 支）",
		[{ label: "取消调度", onClick: cancel_air_move }]
	)
}

function start_resource_swap() {
	/* 已经打开就重查一次（牌堆可能变了，可选基本卡要刷新） */
	if (pending_resource) {
		pending_resource.drop = []
		pending_resource.take = null
		pending_resource.take_discard = null
	}
	/*
	 * 打开弹框（先显示"加载中"），再查牌堆里实际可挑的基本卡。
	 * query 的回复由 on_reply('deck_basics') 填进 pending_resource.basics。
	 * 17551 战时国债：再查弃牌堆可搜寻的基本卡。
	 */
	pending_resource = pending_resource || { basics: [], discardBasics: [], take: null, take_discard: null, drop: [] }
	update_resource_box()
	send_query("deck_basics", null)
	if (view.rs_can_discard_take)
		send_query("discard_basics", null)
}

function cancel_resource_swap() {
	if (!pending_resource)
		return
	pending_resource = null
	update_resource_box()
	update_hand_panel()
}

function submit_resource_swap() {
	if (!pending_resource)
		return
	if (!pending_resource.take && !pending_resource.take_discard) { toast("请先选 1 张要的基本卡（或来自弃牌堆）"); return }
	const rsMin = view.rs_min_drop || 3
	if (pending_resource.drop.length !== rsMin) {
		toast("还需要选 " + (rsMin - pending_resource.drop.length) + " 张手牌作为代价")
		return
	}
	const payload = { discard: pending_resource.drop.slice() }
	if (pending_resource.take) payload.take = pending_resource.take
	else if (pending_resource.take_discard) payload.take_discard = pending_resource.take_discard
	send_action("resource_swap", payload)
	/*
	 * 每回合只能一次：提交后收起弹框。
	 * 服务端换取后会自动洗混牌堆，下次打开弹框时 deck_basics
	 * 返回的就是洗牌后的新结果。
	 */
	pending_resource = null
	update_resource_box()
	update_hand_panel()
	toast("已换取 1 张基本卡，牌堆已洗混（本回合资源再分配已用完）")
}

/*
 * 渲染资源再分配弹框：两块卡牌网格
 *   ① 牌堆中实际可选的基本卡（来自 query('deck_basics')）
 *   ② 手牌中选 3 张作为代价
 */
function update_resource_box() {
	const modal = document.getElementById("resource_modal")
	if (!modal)
		return

	if (!pending_resource) {
		modal.classList.add("hide")
		return
	}
	modal.classList.remove("hide")

	/* ---- ① 牌堆中的基本卡 ---- */
	const basicsBox = document.getElementById("res_basics")
	basicsBox.innerHTML = ""
	if (!pending_resource.basics.length) {
		const p = document.createElement("div")
		p.className = "empty-note"
		p.textContent = "牌堆中没有基本卡可挑（或尚未加载完成…）"
		basicsBox.appendChild(p)
	}
	for (const c of pending_resource.basics) {
		const d = card_elt(c, () => {
			pending_resource.take = (pending_resource.take === c.id) ? null : c.id
			pending_resource.take_discard = null
			update_resource_box()
		})
		d.classList.toggle("sel", pending_resource.take === c.id)
		basicsBox.appendChild(d)
	}
	/* 17551 战时国债：也可从弃牌堆搜寻基本卡 */
	if (pending_resource.discardBasics && pending_resource.discardBasics.length) {
		const sep = document.createElement("div")
		sep.className = "empty-note"
		sep.textContent = "—— 或来自弃牌堆（战时国债）——"
		basicsBox.appendChild(sep)
		for (const c of pending_resource.discardBasics) {
			const d = card_elt(c, () => {
				pending_resource.take_discard = (pending_resource.take_discard === c.id) ? null : c.id
				pending_resource.take = null
				update_resource_box()
			})
			d.classList.toggle("sel", pending_resource.take_discard === c.id)
			basicsBox.appendChild(d)
		}
	}

	/* ---- ② 手牌代价（选 3 张） ---- */
	const costBox = document.getElementById("res_cost")
	costBox.innerHTML = ""
	const hand = (view.hands[view.my_nation] && view.hands[view.my_nation].cards) || []
	for (const c of hand) {
		const picked = pending_resource.drop.indexOf(c.id) >= 0
		const d = card_elt(c, () => {
			const i = pending_resource.drop.indexOf(c.id)
			if (i >= 0)
				pending_resource.drop.splice(i, 1)
			else if (pending_resource.drop.length < 3)
				pending_resource.drop.push(c.id)
			else
				toast("代价只需 3 张，请先取消一张")
			update_resource_box()
		})
		if (picked) {
			d.classList.add("sel")
			const b = document.createElement("span")
			b.className = "badge"
			b.textContent = "代价 " + (pending_resource.drop.indexOf(c.id) + 1)
			d.appendChild(b)
		}
		costBox.appendChild(d)
	}
	if (!hand.length) {
		const p = document.createElement("div")
		p.className = "empty-note"
		p.textContent = "手牌为空，无法支付代价"
		costBox.appendChild(p)
	}

	/* ---- 提示与按钮状态 ---- */
	const rsMin = view.rs_min_drop || 3
	const note = document.getElementById("res_pick_note")
	if (note) {
		note.textContent = "（牌堆中 " + pending_resource.basics.length + " 张可选"
		if (pending_resource.discardBasics && pending_resource.discardBasics.length)
			note.textContent += "，弃牌堆另有 " + pending_resource.discardBasics.length + " 张"
		note.textContent += "）"
	}
	const costNote = document.getElementById("res_cost_note")
	if (costNote)
		costNote.textContent = pending_resource.drop.length + "/" + rsMin
	const ok = document.getElementById("res_confirm")
	if (ok)
		ok.disabled = !((pending_resource.take || pending_resource.take_discard) && pending_resource.drop.length === rsMin)
}

/* ============================================================
 * 【双十字系统】观看对手手牌并重排到其牌堆顶（2026-09-25 补 UI）
 *
 * 交互格式与"资源再分配"一致：modal + card-grid + 序号 badge + 确认按钮。
 *
 * 流程：
 *   ① 玩家在自己【摸牌阶段】打出《双十字系统》
 *   ② 服务端随机挑 2 张德国手牌，写入 game.peek，view.peek 非空
 *   ③ 客户端弹出本弹框，展示这 2 张牌
 *   ④ 玩家【依次点击】决定顺序 -> 先点的在最上面（牌堆顶）
 *   ⑤ 点【确认顺序】-> 提交 play_card { card, order }
 *   ⑥ 服务端按 order 压到德国牌堆顶，清除 game.peek，弹框自动关闭
 *
 * 卡在 pending 期间【不弃牌不结算】，所以取消是安全的（卡还在手里）。
 * ============================================================ */

/* 玩家点击累积的顺序（存卡 id，先点的在前） */
let peek_order = []
/*
 * 【2026-10-12 新增】15215 卓越规划专用：卡 id -> 'top' | 'bottom'。
 * 只影响 topBottom 模式（检视自己牌堆顶后置顶/置底）；
 * 15305 双十字系统（置对手牌堆顶）不使用，全部按 'top' 处理。
 * 与 peek_order 分开存，点「重排」只清顺序、保留顶/底选择（重新选择的一部分）。
 */
let peek_where = {}
/*
 * 【2026-09-25 新增】本地 peek 状态（query 路径用，不依赖 view.peek）。
 *   pending_peek_for_card —— 当前 pending 的卡对象，submit_peek 用它的 id
 *   peek_cards            —— query 返回的对手手牌 id 数组
 *   peek_target           —— 对手国家名（如"德国"）
 */
let pending_peek_for_card = null
let peek_cards = null
let peek_target = null

/* ============================================================
 * 【2026-10-20】卡牌"部分成功"的失败提示（服务端下发 -> 客户端 toast）
 *
 * 场景：《自由法国同盟》pick:2 选中 2 个地区征召法国陆军，
 * 第 2 个地区被拒（"法国 的陆军已达上限（N）" = 玩家说的"后备兵力不足"）——
 * 玩家只看到"牌打出去了却只出现 1 支部队"，需要明确告知原因与哪些步骤没做成。
 *
 * 判定与文案【全部由服务端算好】（view.last_card_fail = { token, name, fails[] }），
 * 客户端不二次判断、也不自己猜 —— 与 view.hand_ready 同款"判定同源"口径。
 *
 * token 用于识别"这是一条新提示"，避免每次 view 刷新重复弹窗；
 * 首次进入房间只记录【基线】不弹窗，否则加载时会把历史失败重弹一遍。
 * ============================================================ */
let card_fail_token_seen = null
function update_card_fail_toast() {
	const f = view && view.last_card_fail
	if (!f)
		return
	if (card_fail_token_seen === null) {
		card_fail_token_seen = f.token
		return
	}
	if (f.token === card_fail_token_seen)
		return
	card_fail_token_seen = f.token
	const detail = (f.fails || []).join('；')
	if (!detail)
		return
	toast((f.name ? '《' + f.name + '》部分效果未生效：' : '部分效果未生效：') + detail)
}

/* ============================================================
 * ECHO/EVENT 卡的"选 N 张弃牌代价"弹框（2026-09-25）
 *
 * 流程：
 *   ① 玩家点击 ECHO 卡 -> query('event_targets') 返回带 cost.discard
 *   ② on_reply 检测到 cost.discard > 0 -> 弹本框
 *   ③ 玩家点手牌切换选中（on_click_hand_card ①'. 分支）
 *   ④ 选满 N 张 -> 点【确认弃牌】-> 关本框，进入 highlight_event_targets
 *   ⑤ 玩家点地区 -> send_action("play_card", {card, space, cards})
 * ============================================================ */

/* 渲染/隐藏弹框。由 update_map() 统一调用（与 update_resource_box 一样） */
function update_echo_discard_box() {
	const modal = document.getElementById("echo_discard_modal")
	if (!modal)
		return

	/*
	 * 【2026-09-28】本弹框被【状态卡弃牌】共用（status_discard_sel）。
	 * 本函数由 update_view 每次刷新都调用，而它原本只认 pending_echo_discard
	 * —— 若状态卡的框开着，这里会因为 pending_echo_discard 为空而
	 * 立刻 add("hide")，把状态卡的弹框关掉（表现为"弹框一闪就没"）。
	 * 所以有状态卡弃牌时，交给它自己渲染并直接返回。
	 */
	if (status_discard_sel) {
		render_status_discard_box()
		return
	}
	/* 【2026-10-06】保护卡（15410 武士道）的弃牌代价，共用同一个 modal */
	if (pending_guard_sel) {
		render_guard_discard_box()
		return
	}

	if (!pending_echo_discard) {
		modal.classList.add("hide")
		return
	}
	modal.classList.remove("hide")

	/*
	 * 【2026-10-06】代价限定牌类型：日本增强卡「弃置 1 张【响应卡】」。
	 * filter 由服务端下发（tg.cost.filter），客户端据此过滤候选：
	 *   只显示符合类型的手牌，其它牌根本不出现（不给玩家错误选项）。
	 */
	const pd = pending_echo_discard
	/* 【2026-10-18 修复】'build' 代价 = 弃 1 张【建设陆军】（BASIC 且 name=建设陆军），
	 * 不是字面 type 'BUILD'。原先 String('build').toUpperCase()==='BUILD'，
	 * 而建设陆军 type 实为 'BASIC'，导致候选被全过滤、玩家"找不到手牌中的建设陆军"。
	 * 与服务端 resolve_event_card 的 'build' 口径（L14563-14566）同源。 */
	const wantBuild = pd.filter === 'build'
	const wantType = pd.filter
		? String(pd.filter === 'response' ? 'RESPONSE' : (wantBuild ? 'BASIC' : pd.filter)).toUpperCase()
		: null
	const typeName = pd.filter === 'response' ? '响应牌' : (wantBuild ? '建设陆军' : (wantType || '手牌'))

	/* 标题 */
	const title = document.getElementById("echo_discard_title")
	if (title) {
		let t = "《" + pd.card.name + "》：选 " + pd.limit + " 张" + typeName + "作为代价"
		if (pd.needBuild > 0)
			t += "（其中需含 " + pd.needBuild + " 张[建设陆军]）"
		title.textContent = t
	}

	/* 手牌区 */
	const grid = document.getElementById("echo_discard_grid")
	if (!grid)
		return
	grid.innerHTML = ""
	const allHand = (view.hands[view.my_nation] && view.hands[view.my_nation].cards) || []
	const hand = allHand.filter(c => {
		if (wantBuild)
			return String(c.type || '').toUpperCase() === 'BASIC' && c.name === '建设陆军'
		if (wantType)
			return String(c.type || '').toUpperCase() === wantType
		return true
	})
	for (const c of hand) {
		/* 本卡不可选（不能弃自己当代价） */
		const isSelf = (c.id === pd.card.id)
		const picked = pd.drop.indexOf(c.id) >= 0
		const d = card_elt(c, () => {
			if (isSelf) {
				toast("本卡不能作为自己的代价")
				return
			}
			const i = pd.drop.indexOf(c.id)
			if (i >= 0)
				pd.drop.splice(i, 1)
			else if (pd.drop.length < pd.limit)
				pd.drop.push(c.id)
			else
				toast("代价只需 " + pd.limit + " 张，请先取消一张")
			update_echo_discard_box()
			update_hand_panel()
		})
		if (isSelf) {
			d.classList.add("disabled")
		} else if (picked) {
			d.classList.add("sel")
			const b = document.createElement("span")
			b.className = "badge"
			b.textContent = "代价 " + (pd.drop.indexOf(c.id) + 1)
			d.appendChild(b)
		}
		grid.appendChild(d)
	}
	if (!hand.length) {
		const p = document.createElement("div")
		p.className = "empty-note"
		p.textContent = wantType
			? ("手牌中没有可作为代价的" + typeName)
			: "手牌为空，无法支付代价"
		grid.appendChild(p)
	}

	/* 计数与按钮状态 */
	const note = document.getElementById("echo_discard_note")
	if (note)
		note.textContent = pending_echo_discard.drop.length + "/" + pending_echo_discard.limit
	const ok = document.getElementById("echo_discard_confirm")
	if (ok)
		ok.disabled = (pending_echo_discard.drop.length !== pending_echo_discard.limit)
}

/* 取消：清空所有 pending 状态（包括卡片本身） */
function cancel_echo_discard() {
	/* 同上：状态卡弃牌走状态卡自己的取消（清 status_discard_sel 等） */
	if (status_discard_sel) {
		cancel_status_act()
		return
	}
	/* 【2026-10-06】保护卡的弃牌框：取消 = 回到"是否打出保护卡"的询问 */
	if (pending_guard_sel) {
		cancel_guard_discard()
		return
	}
	cancel_event_card()
	update_echo_discard_box()
	update_hand_panel()
}

/*
 * 确认弃牌：本弹框关闭，进入高亮地区流程。
 * 所选弃牌 ids 暂存到 pending_echo_cards，供最终 send_action 用。
 */
function confirm_echo_discard() {
	/*
	 * 【2026-09-28】本弹框现在【共用】于两种流程，确认时要先分流：
	 *   ① 状态卡弃牌代价（status_discard_sel）
	 *   ② ECHO/EVENT 卡弃牌代价（pending_echo_discard，原逻辑）
	 * 否则状态卡点"确认弃牌"会因为 pending_echo_discard 为 null 而直接 return（无反应）。
	 */
	if (status_discard_sel) {
		finish_status_discard()
		return
	}
	/* 【2026-10-06】保护卡的弃牌框：确认 = resolve_battle{guard, drop} */
	if (pending_guard_sel) {
		confirm_guard_discard()
		return
	}
	/* 【2026-10-14】增强卡 armed 弃牌代价（15311 马奇诺防线）：确认 = use_armed_offer{drop} */
	if (pending_echo_discard && pending_echo_discard.armed) {
		if (pending_echo_discard.drop.length !== pending_echo_discard.limit) {
			toast('还需选 ' + (pending_echo_discard.limit - pending_echo_discard.drop.length) + ' 张')
			return
		}
		const drop = pending_echo_discard.drop.slice()
		const card = pending_echo_discard.armed_card
		pending_echo_discard = null
		const m = document.getElementById('echo_discard_modal')
		if (m) m.classList.add('hide')
		update_hand_panel()
		send_action('use_armed_offer', { card: card, drop: drop })
		toast('打出增强卡')
		return
	}
	if (!pending_echo_discard) {
		/*
		 * 【2026-10-16 修复】自愈：状态已被消费但共用 modal 还开着
		 * （任何本地转移漏关框的残留），直接关掉，别让玩家点确认毫无反应。
		 */
		const m = document.getElementById('echo_discard_modal')
		if (m) m.classList.add('hide')
		return
	}
	if (pending_echo_discard.drop.length !== pending_echo_discard.limit) {
		toast("还需选 " + (pending_echo_discard.limit - pending_echo_discard.drop.length) + " 张")
		return
	}
	/* 暂存弃牌 */
	pending_echo_cards = pending_echo_discard.drop.slice()
	const tg = pending_echo_discard.need_targets
	/* 卡对象回到 pending_event_card（on_reply 流程已设过，但保险起见） */
	if (!pending_event_card)
		pending_event_card = pending_echo_discard.card
	/* 清空本弹框状态（先清，避免下面 submit 时又走进弃牌框分支） */
	pending_echo_discard = null

	/*
	 * 【2026-09-28】分支：
	 *   · need_targets 存在 -> 还要选地区，进高亮流程（原逻辑）
	 *   · need_targets 为 null -> 【单候选卡，不需要选地区】，直接提交。
	 *     若这里还去 highlight_event_targets(null)，地图不会高亮，
	 *     玩家点到死也没有提交入口 —— 流程会卡住。
	 */
	if (tg) {
		/* 【2026-10-06 选项 A】弃牌代价挂在 choice 步：弃完牌后回到部署/调度选项 */
		if (tg.need === 'choice') {
			const tg2 = Object.assign({}, tg)
			tg2.cost = null   // 代价已付，避免再次弹弃牌框
			if (!pending_event_card)
				pending_event_card = pending_echo_discard.card
			show_event_choice(tg2)
			update_echo_discard_box()
			update_hand_panel()
			return
		}
		pending_event_targets = tg
		highlight_event_targets(tg)
		update_echo_discard_box()
		update_hand_panel()
		toast("已选弃牌，请点击地图上的目标地区")
		return
	}

	/* 无需选地区：直接打出，并把玩家选的弃牌一起提交 */
	const arg = { card: pending_event_card.id, cards: pending_echo_cards.slice() }
	const nm = pending_event_card.name
	lend_play_action(arg)
	toast("打出《" + nm + "》")
	cancel_event_card()
	update_echo_discard_box()
	update_hand_panel()
}

/* ============================================================
 * 【2026-10-06】保护卡的弃牌代价（15410 武士道：弃 1 张响应牌）
 *
 * 复用 echo_discard_modal（与 ECHO 卡代价同款 modal + card-grid），
 * 差别只在提交目标：resolve_battle{guard, drop} 而不是 play_card。
 * ============================================================ */
let pending_guard_sel = null   /* { card_id, name, cost, cost_filter, drop:[], submit_target } */

/*
 * 【战斗内"选 N 张牌作代价"的唯一入口】（复用 echo_discard_modal，不另建 UI）
 *
 * 三种提交目标由 g.submit_target 区分：
 *   缺省 / null  -> resolve_battle{ guard, drop }            15410 武士道等保护卡
 *   'step_back'  -> resolve_battle{ step_back:true, drop }   17853 一步也不许后退!
 *   'kv2'        -> resolve_battle{ kv2:'discard', drop }    17837 KV-2 重型坦克
 */
function start_guard_discard(g) {
	const target = g.submit_target || null
	if (!g.cost) {
		/* 无代价（或手牌为 0 张）：直接提交，按目标区分 action */
		if (target === 'kv2') send_action("resolve_battle", { kv2: 'discard', drop: [] })
		else if (target === 'step_back') send_action("resolve_battle", { step_back: true, drop: [] })
		else send_action("resolve_battle", { guard: g.card_id })
		return
	}
	pending_guard_sel = {
		card_id: g.card_id, name: g.name,
		cost: g.cost, cost_filter: g.cost_filter || null,
		drop: [],
		submit_target: target,
		/*
		 * 【2026-10-25】这一栏代价由【谁】付：
		 *   · KV-2（17837）由攻击发起国付 —— 服务端 view.pending_battle.cost_nation 已算好；
		 *   · 17853 / 保护卡由调用方显式传入。
		 * 绝不能再用 view.my_nation（那只是"此刻该谁操作"，日本攻击时可能是德国）。
		 */
		discard_nation: g.discard_nation ||
			(view.pending_battle && view.pending_battle.cost_nation) || view.my_nation,
	}
	/* 让出 ask_box，避免两个弹框叠在一起 */
	ask_state = null
	render_ask_box(null, null, null)
	update_echo_discard_box()
	update_hand_panel()
}

/* 【2026-10-18】苏联 17853《一步也不许后退!》：薄封装，走上面同一个入口 */
function start_step_back_discard(pb) {
	start_guard_discard({
		card_id: pb.su_card,
		name: '一步也不许后退!',
		cost: 4,
		submit_target: 'step_back',
	})
}

function render_guard_discard_box() {
	const modal = document.getElementById("echo_discard_modal")
	if (!modal) return
	modal.classList.remove("hide")
	const gs = pending_guard_sel
	const wantType = gs.cost_filter
		? String(gs.cost_filter === 'response' ? 'RESPONSE' : gs.cost_filter).toUpperCase()
		: null
	const typeName = gs.cost_filter === 'response' ? '响应牌' : (wantType || '手牌')

	/* 【2026-10-25】按"付代价的国家"取手牌（KV-2 = 攻击国），标题同时标出国名 */
	const dn = gs.discard_nation || view.my_nation
	set_text("echo_discard_title",
		"《" + gs.name + "》：请【" + dn + "】选 " + gs.cost + " 张" + typeName + "作为代价")

	const grid = document.getElementById("echo_discard_grid")
	if (!grid) return
	grid.innerHTML = ""
	const allHand = (view.hands[dn] && view.hands[dn].cards) || []
	const hand = (wantType
		? allHand.filter(c => String(c.type || '').toUpperCase() === wantType)
		: allHand).filter(c => c.id !== gs.card_id)   /* 本卡不能作自己的代价 */
	for (const c of hand) {
		const picked = gs.drop.indexOf(c.id) >= 0
		const d = card_elt(c, () => {
			const i = gs.drop.indexOf(c.id)
			if (i >= 0)
				gs.drop.splice(i, 1)
			else if (gs.drop.length < gs.cost)
				gs.drop.push(c.id)
			else
				toast("代价只需 " + gs.cost + " 张，请先取消一张")
			update_echo_discard_box()
			update_hand_panel()
		})
		if (picked) {
			d.classList.add("sel")
			const b = document.createElement("span")
			b.className = "badge"
			b.textContent = "代价 " + (gs.drop.indexOf(c.id) + 1)
			d.appendChild(b)
		}
		grid.appendChild(d)
	}
	if (!hand.length) {
		const p = document.createElement("div")
		p.className = "empty-note"
		p.textContent = "手牌中没有可作为代价的" + typeName
		grid.appendChild(p)
	}
	set_text("echo_discard_note", gs.drop.length + "/" + gs.cost)
	const ok = document.getElementById("echo_discard_confirm")
	if (ok) ok.disabled = (gs.drop.length !== gs.cost)
}

function confirm_guard_discard() {
	const gs = pending_guard_sel
	if (!gs) return
	if (gs.drop.length !== gs.cost) {
		toast("还需选 " + (gs.cost - gs.drop.length) + " 张")
		return
	}
	const drop = gs.drop.slice()
	const cardId = gs.card_id
	pending_guard_sel = null
	/* 【2026-10-18】17853《一步也不许后退!》复用本弹框选 4 张手牌，提交目标改为 step_back */
	/* 【2026-10-23】17837《KV-2 重型坦克》攻击方弃牌同样复用，提交 kv2:'discard' + drop */
	if (gs.submit_target === 'step_back') {
		send_action("resolve_battle", { step_back: true, drop: drop })
	} else if (gs.submit_target === 'kv2') {
		send_action("resolve_battle", { kv2: 'discard', drop: drop })
	} else {
		send_action("resolve_battle", { guard: cardId, drop: drop })
	}
	update_echo_discard_box()
	update_hand_panel()
}

function cancel_guard_discard() {
	pending_guard_sel = null
	/* ask_box 会在下一次 update_pending_battle_box 时重新渲染（重新给机会选） */
	update_echo_discard_box()
	update_hand_panel()
}

/* 渲染/隐藏弹框。由 update_map() 统一调用（与 update_resource_box 一样） */
function update_peek_box() {
	const modal = document.getElementById("peek_modal")
	if (!modal)
		return

	/*
	 * 【2026-09-25 bug 修复】支持两种来源的 peek 数据：
	 *   (A) view.peek  —— 旧路径（直接打 15305 不走 query），
	 *       由服务端 resolve_event_card 内部 set game.peek，
	 *       view 反映状态后弹框。
	 *   (B) pending_peek_for_card —— 新路径（走 query('event_targets')），
	 *       query 是只读 RPC 不能写 state，所以 view.peek 不会更新。
	 *       客户端自己用 peek_cards + peek_target 渲染。
	 *
	 * 当前 (A) 路径已废弃（query 路径会先于 send_action 调用，
	 * game.peek 由 query 触发写入但 view 不广播）；
	 * 只保留 (B) 路径。
	 */
	/*
	 * 【2026-10-12 统一】两种模式共用本弹框：
	 *   (A) 15305 双十字系统（topBottom=false，本地 query 路径）：
	 *       观看对手手牌 -> 排序置于【对手牌堆顶】（提交 order）
	 *   (B) 15215 卓越规划（topBottom=true，view.peek 路径）：
	 *       检视自己牌堆顶 -> 每张选【置顶/置底】+ 排序（提交 placement）
	 * 两模式差异仅在于：是否渲染置顶/置底按钮、文案、以及提交参数。
	 */
	let pk = null
	if (pending_peek_for_card && peek_cards && peek_cards.length) {
		/* (A) 本地路径：peek_cards 已是卡对象数组（服务端 query 出口转好的） */
		pk = {
			cards: peek_cards,
			nation: peek_target || "?",
			card: pending_peek_for_card.id,
			topBottom: false,
		}
	} else if (view.peek && view.peek.cards && view.peek.cards.length) {
		/* (B) 服务端路径：15215 卓越规划（topBottom）等 */
		pk = view.peek
	} else {
		modal.classList.add("hide")
		return
	}

	modal.classList.remove("hide")

	/*
	 * 【2026-10-01 玩家口径】peek 弹框【不可取消】—— 关闭 × 与取消按钮
	 * 已直接从 play.html 移除（不是隐藏）：牌一旦摊给玩家看，信息就已拿到
	 * （看对手手牌 = 知道对手秘密；看自己牌堆顶 = 知道接下来摸什么），
	 * 取消等于免费偷看。必须排完序点【确认顺序】。
	 * 这里只保留【重排】与【确认顺序】两个操作。
	 */
	const isTB = !!pk.topBottom

	/* 换了一批牌 -> 本地顺序与顶/底选择要重置 */
	if (peek_order.length > pk.cards.length)
		peek_order = []

	const ids = pk.cards.map(c => c.id)
	peek_order = peek_order.filter(id => ids.indexOf(id) >= 0)
	for (const k in peek_where)
		if (ids.indexOf(k) < 0) delete peek_where[k]

	/* ---- 标题 / 副标题 / 步骤文案按模式切换 ---- */
	const setTxt = (elId, txt) => {
		const el = document.getElementById(elId)
		if (el) el.textContent = txt
	}
	setTxt("peek_title", isTB ? "卓越规划" : "双十字系统")
	setTxt("peek_subtitle", isTB
		? "检视自己牌堆顶 " + pk.cards.length + " 张 → 每张选置顶/置底并排顺序"
		: "观看对手手牌 → 按你点击的顺序置于其牌堆顶")
	setTxt("peek_step1_label", isTB ? "① 检视的牌" : "① 观看的手牌")
	setTxt("peek_step2_label", isTB
		? "② 依次点击，决定组内顺序（先点的排最前）"
		: "② 依次点击，决定牌堆顶的顺序")

	/* ---- ① 卡牌（topBottom 模式额外渲染置顶/置底按钮） ---- */
	const box = document.getElementById("peek_cards")
	box.innerHTML = ""
	for (const c of pk.cards) {
		const idx = peek_order.indexOf(c.id)
		const cell = document.createElement("div")
		cell.className = "deck-cell"
		const d = card_elt(c, () => toggle_peek_order(c.id))
		if (idx >= 0) {
			d.classList.add("sel")
			const b = document.createElement("span")
			b.className = "badge"
			/* 15305 恒为牌堆顶，显示"顶N"；15215 可能是置底组，只显示序号 */
			b.textContent = isTB ? String(idx + 1) : "顶" + (idx + 1)
			d.appendChild(b)
		}
		if (isTB) {
			/*
			 * 重新选择：置顶/置底随时可切换（点击后整体重渲染，状态即生效）。
			 * 卡面左下角挂「顶 / 底」角标，点击后立刻可见，避免"点了没反应"。
			 */
			const where = peek_where[c.id] || "top"
			const tag = document.createElement("span")
			tag.className = "where-badge " + (where === "bottom" ? "bot" : "top")
			tag.textContent = where === "bottom" ? "底" : "顶"
			d.appendChild(tag)
		}
		cell.appendChild(d)
		if (isTB) {
			const where = peek_where[c.id] || "top"
			const btnTop = document.createElement("button")
			btnTop.textContent = "置顶"
			btnTop.className = "action" + (where === "top" ? " primary" : "")
			btnTop.onclick = () => { peek_where[c.id] = "top"; update_peek_box() }
			const btnBot = document.createElement("button")
			btnBot.textContent = "置底"
			btnBot.className = "action" + (where === "bottom" ? " primary" : "")
			btnBot.onclick = () => { peek_where[c.id] = "bottom"; update_peek_box() }
			cell.appendChild(btnTop)
			cell.appendChild(btnBot)
		}
		box.appendChild(cell)
	}

	/* ---- ② 提示与按钮状态 ---- */
	const targetNote = document.getElementById("peek_target_note")
	if (targetNote)
		targetNote.textContent = isTB
			? "（" + pk.nation + " 牌堆顶 " + pk.cards.length + " 张）"
			: "（" + pk.nation + " 的 " + pk.cards.length + " 张手牌）"

	const orderNote = document.getElementById("peek_order_note")
	if (orderNote)
		orderNote.textContent = peek_order.length + "/" + pk.cards.length

	const desc = document.getElementById("peek_order_desc")
	if (desc) {
		const names = peek_order.map(id => {
			const c = pk.cards.find(x => x.id === id)
			return c ? c.name : id
		})
		if (!peek_order.length) {
			desc.textContent = "依次点击卡牌决定顺序：先点的排在最上面。" +
				"（已排的牌会标上序号，再点一次可取消）"
		} else {
			desc.textContent = "当前顺序：" + names.join(" → ")
		}
		if (isTB) {
			/* 顶/底分组统计，方便玩家确认"哪些置顶、哪些置底" */
			let nTop = 0, nBot = 0
			for (const c of pk.cards) {
				if ((peek_where[c.id] || "top") === "top") nTop++
				else nBot++
			}
			desc.textContent += "　【置顶 " + nTop + " 张 / 置底 " + nBot + " 张】"
		}
	}

	const okBtn = document.getElementById("peek_confirm")
	if (okBtn) {
		okBtn.disabled = (peek_order.length !== pk.cards.length)
		okBtn.textContent = isTB ? "确认排列" : "确认顺序"
	}
}

/* 点一张牌：已排则取消，未排则追加到末尾 */
function toggle_peek_order(id) {
	const i = peek_order.indexOf(id)
	if (i >= 0)
		peek_order.splice(i, 1)
	else
		peek_order.push(id)
	update_peek_box()
}

/* 重排：清空已选顺序（【保留】15215 的置顶/置底选择，只重排顺序） */
function reset_peek_order() {
	peek_order = []
	update_peek_box()
}

/* 提交：把 order 交给服务端 */
function submit_peek() {
	/*
	 * 兼容两种路径：本地 peek_cards 模式 + view.peek 旧模式。
	 * cards.length 都用于校验 peek_order 是否排满。
	 */
	const localMode = !!(pending_peek_for_card && peek_cards && peek_cards.length)
	let cardCount = 0
	let nation = "?"
	let cardId = null
	let isTB = false
	if (localMode) {
		cardCount = peek_cards.length
		nation = peek_target || "?"
		cardId = pending_peek_for_card.id
	} else if (view.peek) {
		cardCount = (view.peek.cards || []).length
		nation = view.peek.nation
		cardId = view.peek.card
		isTB = !!view.peek.topBottom
	} else {
		toast("当前没有等待排序的牌")
		return
	}
	if (peek_order.length !== cardCount) {
		toast("还需要排 " + (cardCount - peek_order.length) + " 张")
		return
	}
	/*
	 * 【2026-10-12 统一】按模式提交不同参数：
	 *   (B) topBottom（15215 卓越规划）：placement = [{id, where:'top'|'bottom', order}]
	 *       order 用全局点击序号，服务端在各组内再按 order 升序排：
	 *         置顶组 order 小者更靠近牌堆顶；置底组 order 小者更靠近牌堆底。
	 *   (A) 15305 双十字系统：order + peek_cards（置对手牌堆顶）。
	 */
	const payload = isTB
		? {
			card: cardId,
			placement: peek_order.map((id, i) => ({
				id: id,
				where: peek_where[id] || "top",
				order: i,
			})),
		}
		: {
			card: cardId,
			order: peek_order.slice(),
			/*
			 * 【2026-09-25 bug 修复】把 query 阶段挑出的 cards 一起提交，
			 * 服务端据此校验 order 一致性（避免服务端重新挑导致不一致）。
			 * peek_cards 是卡对象数组，提取 id 字段。
			 */
			peek_cards: localMode
				? peek_cards.map(c => c.id)
				: (view.peek ? (view.peek.cards || []).map(c => c.id) : []),
		}
	/*
	 * 【2026-10-22 修复·假成功】send_action 在动作不在 view.actions 白名单时
	 * 【静默 return false】（不发包、无日志）。旧实现不检查返回值，照常清空
	 * 本地状态并弹"已按指定方式重组牌堆" —— 于是出现"提示成功，但服务端
	 * 根本没收到、弹框不消失"的假象，排查极费时。
	 * 这里改为：没发出去就如实提示【并保留已排的顺序】，不谎报成功。
	 */
	if (!send_action("play_card", payload)) {
		toast("提交失败：当前不接受出牌" +
			(view.block_reason ? "（" + view.block_reason + "）" : "") +
			"，已保留排序，请稍后再试")
		return
	}
	peek_order = []
	peek_where = {}
	peek_cards = null
	peek_target = null
	pending_peek_for_card = null
	pending_event_card = null
	toast(isTB ? "已按指定方式重组 " + nation + " 牌堆" : "已按指定顺序置于 " + nation + " 牌堆顶")
}

/* 取消：本地模式直接清状态；旧模式通知服务端 clear_peek */
function cancel_peek() {
	/*
	 * 【2026-10-01 玩家口径】**任何 peek 弹窗都【不允许取消】**
	 * （看对手手牌 = 看到对手秘密；看自己牌堆顶 = 知道接下来摸什么）。
	 * 取消都等于免费偷看，故一律拒绝，必须排完序点【确认顺序】。
	 *
	 * 服务端 clear_peek 已同样拒绝（防直接发 action 绕过），
	 * 这里只是让 UI 给出明确提示，而不是静默无反应。
	 */
	toast("已观看卡牌，不能取消 —— 请完成排序后确认")
}

/*
 * 弹框里用的卡牌元素（复用 build_card_elt 的卡图渲染，
 * 但点击行为由调用方通过 onClick 直接给定 —— 弹框是模态的，
 * 不存在"渲染与状态错开"的问题）。
 */
/*
 * 【2026-09-30 德国增强·战术革新】15214 两步选牌弹框
 *   step 'discard'：选择德国场上的 1 张[状态卡]弃置
 *   step 'play'   ：选择手牌中的 1 张[状态卡]免费打出（不占出牌名额）
 */
/*
 * 【2026-10-31】增强卡"多步 need"的补参重发通道（17514 飞虎队 / 17815 Z 计划 等）。
 *
 * 服务端在 play_card 遇到 r.need 时会把 {kind:'echo_need', step, options, cands, choice}
 * 写进 pending_echo；客户端这里：
 *   · step='choice' -> 渲染选项按钮，点选后重发 play_card {card, choice}
 *   · step='space'  -> 高亮 cands 里的地区，玩家点地图后重发 play_card {card, choice, space}
 * 这与 15214 的 pending_echo（kind 未设置）/ 苏联 kind='su' 分支互不干扰。
 */
let echo_need_pick = null   /* { card, choice, cands } —— 等待玩家点地图 */

function clear_echo_need_pick() {
	if (!echo_need_pick) return
	echo_need_pick = null
	highlight_targets(null)
}

function update_pending_echo_box() {
	const modal = document.getElementById("pending_echo_modal")
	if (!modal) return
	const pe = view.pending_echo
	if (!pe) { modal.style.display = "none"; clear_echo_need_pick(); return }
	if (pe.kind !== 'echo_need') clear_echo_need_pick()
	if (pe.kind === 'echo_need') {
		modal.style.display = "block"
		const box = modal.querySelector(".modal-box")
		box.innerHTML = ""
		const h = document.createElement("h3")
		h.textContent = pe.title || ("《" + (pe.name || "增强卡") + "》：请继续选择")
		box.appendChild(h)

		/* ① 选项阶段：每个 option 一个按钮 */
		if (pe.step === 'choice' && Array.isArray(pe.options) && pe.options.length) {
			pe.options.forEach(o => {
				const b = document.createElement("button")
				b.className = "btn"
				b.textContent = o.label || ("选项 " + (o.index + 1))
				if (o.disabled) {
					b.disabled = true
					if (o.reason) b.title = o.reason
				}
				b.onclick = () => {
					send_action("play_card", { card: pe.card, choice: o.index })
				}
				box.appendChild(b)
			})
		}

		/* ② 选地区阶段：高亮候选，等玩家点地图 */
		if (pe.step === 'space' && Array.isArray(pe.cands) && pe.cands.length) {
			const p = document.createElement("p")
			p.textContent = "请点击地图上的高亮地区（共 " + pe.cands.length + " 个候选）"
			box.appendChild(p)
			echo_need_pick = { card: pe.card, choice: (pe.choice != null ? pe.choice : null), cands: pe.cands.slice() }
			highlight_targets(pe.cands)
		}

		/* ③ 允许放弃（卡未消耗，清掉挂起即可） */
		const cancel = document.createElement("button")
		cancel.className = "btn"
		cancel.textContent = "不发动"
		cancel.onclick = () => {
			clear_echo_need_pick()
			send_action("play_card", { card: pe.card, __cancel_need: true })
		}
		box.appendChild(cancel)
		return
	}
	/*
	 * 【2026-10-07 苏联增强】kind:'su' = 通用多步选牌框（17812/17813）。
	 * pe 自带 title / candidates（卡对象数组，每项有 id），
	 * 点选即发 resolve_effect { pick: c.id }，由服务端 ECHO_EFFECTS.run 继续推进。
	 * 与 15214 战术革新（kind 未设置）的硬编码分支互不干扰。
	 */
	if (pe.kind === 'su') {
		/* 【2026-10-07 苏联增强】通用多步选牌框（17812/17813）：沿用原实现，渲染与交互保持不变 */
		modal.style.display = "block"
		const box = modal.querySelector(".modal-box")
		box.innerHTML = ""
		const h = document.createElement("h3")
		h.textContent = pe.title || "选择"
		box.appendChild(h)
		const cands = pe.candidates || []
		const grid = document.createElement("div")
		grid.className = "card-grid"
		if (!cands.length && !pe.allowDone) {
			const e = document.createElement("p")
			e.textContent = "没有可选择的卡"
			box.appendChild(e)
		} else {
			for (const c of cands) {
				const el = card_elt(c, () => {
					send_action("resolve_effect", { pick: c.id })
				})
				grid.appendChild(el)
			}
			box.appendChild(grid)
		}
		if (pe.allowDone) {
			const db = document.createElement("button")
			db.className = "btn"
			db.textContent = (pe.step === 'second') ? "只放这 1 张" : "完成"
			db.onclick = () => send_action("resolve_effect", { done: true })
			box.appendChild(db)
		}
		return
	}
	/*
	 * 【2026-10-12 重构】kind:'status'（17546 铆钉女工）复用成熟选牌弹框结构：
	 * .modal-head(标题) → .modal-section(.modal-label + .modal-hint 进度
	 * + 已选第 1 张展示 + .card-grid) → .modal-foot(.action.primary 完成按钮)。
	 * 与 echo_discard_modal / resource_modal / skill_discard_modal 等选牌 UI
	 * 视觉一致；服务端协议（resolve_effect {pick}/{done}）不变，仅改善展示与文案。
	 */
	if (pe.kind === 'status') {
		modal.style.display = "block"
		const box = modal.querySelector(".modal-box")
		box.innerHTML = ""
		const isStep2 = pe.step === 'second'

		const head = document.createElement("div")
		head.className = "modal-head"
		const title = document.createElement("span")
		title.className = "modal-title"
		title.textContent = pe.title || "状态效果"
		head.appendChild(title)
		box.appendChild(head)

		const sec = document.createElement("div")
		sec.className = "modal-section"
		const label = document.createElement("div")
		label.className = "modal-label"
		label.textContent = isStep2
			? "第 2 步：再选 1 张手牌"
			: "第 1 步：选择第 1 张手牌（最多 2 张）"
		const hint = document.createElement("span")
		hint.className = "modal-hint"
		hint.textContent = isStep2 ? "已选 1 / 2" : "第 1 / 2 张"
		label.appendChild(hint)
		sec.appendChild(label)

		/* 已选第 1 张展示（step2 由服务端下发 pe.first） */
		if (isStep2 && pe.first) {
			const picked = inst_card_client(pe.first)
			const valid = picked && picked.name && picked.name !== "?"
			const tag = document.createElement("div")
			tag.className = "modal-sub"
			tag.style.margin = "4px 0 8px"
			tag.textContent = "已选第 1 张：" + (valid ? picked.name : pe.first)
			sec.appendChild(tag)
			if (valid) {
				const pc = card_elt(picked, () => {})
				pc.classList.add("sel")
				pc.style.cursor = "default"
				sec.appendChild(pc)
			}
		}

		const cands = pe.candidates || []
		const grid = document.createElement("div")
		grid.className = "card-grid"
		if (!cands.length) {
			const e = document.createElement("p")
			e.className = "empty-note"
			e.textContent = "没有可选择的牌"
			grid.appendChild(e)
		} else {
			for (const c of cands) {
				const el = card_elt(c, () => {
					send_action("resolve_effect", { pick: c.id })
				})
				grid.appendChild(el)
			}
		}
		sec.appendChild(grid)
		box.appendChild(sec)

		/*
		 * 底部操作区：仅第 2 步需要确认/重置（第 1 步必须先选第 1 张，不显示完成按钮）。
		 *  - 「重新选择」：清掉已选第 1 张、回到第 1 步（服务端 resolve_effect {back:true} 处理）；
		 *  - 「只放这 1 张」：只放已选的第 1 张并结束（resolve_effect {done:true}）。
		 */
		if (isStep2) {
			const foot = document.createElement("div")
			foot.className = "modal-foot"
			const back = document.createElement("button")
			back.className = "action"
			back.textContent = "重新选择"
			back.onclick = () => send_action("resolve_effect", { back: true })
			foot.appendChild(back)
			const db = document.createElement("button")
			db.className = "action primary"
			db.textContent = "只放这 1 张"
			db.onclick = () => send_action("resolve_effect", { done: true })
			foot.appendChild(db)
			box.appendChild(foot)
		}
		return
	}
	modal.style.display = "block"
	const box = modal.querySelector(".modal-box")
	box.innerHTML = ""
	const h = document.createElement("h3")
	h.textContent = "《战术革新》"
	box.appendChild(h)
	const info = document.createElement("p")
	info.textContent = pe.step === "discard"
		? "第 1 步：选择要弃置的德国场上状态卡"
		: "第 2 步：选择要免费打出的状态卡（不占出牌名额）"
	box.appendChild(info)
	const cands = pe.candidates || []
	const grid = document.createElement("div")
	grid.className = "card-grid"
	if (!cands.length) {
		const e = document.createElement("p")
		e.textContent = pe.step === "discard"
			? "德国场上没有可弃置的状态卡"
			: "手牌没有可打出的状态卡"
		box.appendChild(e)
	} else {
		for (const c of cands) {
			const el = card_elt(c, () => {
				if (pe.step === "discard")
					send_action("resolve_effect", { discard_status: c.id })
				else
					send_action("resolve_effect", { play_status: c.id })
			})
			grid.appendChild(el)
		}
		box.appendChild(grid)
	}
}

/*
 * 【2026-10-19 重构】17805 红色管弦乐队：德国二选一（delegate），复用通用 render_ask_box。
 * 苏联"是否使用"= armed_offer 的打出/不打出窗口（update_armed_offer_box 通用 UI）；
 * 苏联"选德国状态卡"= armed_offer 的 need:'status' 选牌 UI（update_armed_offer_box 通用 UI）。
 * 仅德国二选一在此渲染：决策方（德国）看到两个按钮，其它方看到等待提示。
 * 内容来自 view.pending_red（服务端按阵营区分是否带 options）。
 */
function update_su_red_delegate_box() {
	const pr = view && view.pending_red
	if (!pr) {
		/*
		 * 只清理本框占用的 #ask_box（kind === 'red'），避免误清空其它框
		 * （pending_trigger / national_skill 等），与全工程其它 update_*_box 一致。
		 */
		if (ask_state && ask_state.kind === 'red') {
			ask_state = null
			render_ask_box(null, null, null)
		}
		return
	}
	/* 其它更高优先级框占用 #ask_box 时让位（与 update_armed_offer_box 等一致） */
	if (ask_state && ask_state.kind !== 'red') return
	ask_state = { kind: 'red' }
	const isDecider = Array.isArray(pr.options) && pr.options.length > 0
	const opts = isDecider
		? pr.options.map(o => ({
				label: o.label,
				onClick: () => {
					ask_state = null
					render_ask_box(null, null, null)
					send_action('resolve_red', { choice: o.id })
				},
		  }))
		: []
	render_ask_box(
		isDecider
			? '《' + (pr.card_name || '红色管弦乐队') + '》：' + (pr.target_name || '?')
			: '红色管弦乐队：等待【' + (pr.waiting_for || '德国') + '】选择',
		isDecider
			? '请选择：本回合内无效 / 损耗 2 张牌。'
			: '德国需选择：本回合内该状态卡无效 / 损耗 2 张牌。',
		opts
	)
}

function card_elt(c, onClick) {
	const d = document.createElement("div")
	d.className = "card " + (c.type ? "t-" + c.type : "")
	d.title = c.name + (c.text ? "\n" + c.text : "")

	const url = card_image_url(c)
	if (url) {
		const img = document.createElement("img")
		img.src = url
		img.alt = c.name
		d.appendChild(img)
	} else {
		const n = document.createElement("div")
		n.className = "card-name"
		n.textContent = c.name
		d.appendChild(n)
	}

	d.addEventListener("click", ev => {
		ev.stopPropagation()
		onClick()
	})
	d.addEventListener("mouseenter", () => on_focus_card(c))
	d.addEventListener("mouseleave", on_blur_card)
	return d
}

/* ============================================================
 * 通用询问面板 #ask_box
 *
 * 用于：友方回合开始是否收回部队（默认跳过）、
 *       防守方是否用空军代受 / 发起方是否抵消。
 * ============================================================ */

let ask_state = null   /* { kind, ctx } */

/* 【2026-10-07】armed 增强卡多步交互：pending 期间记录正在结算的卡与待收集信息 */
let pending_armed = null     /* { card, need, candidates, pick, pickMin } */
let pending_status = null    /* 状态卡多步选位：{ card_id, need, candidates, pick, pickMin } */
let armed_resolving_card = null

/* 通用面板渲染：把 title/text/options 画进指定 id 的容器。
 * 抽出本函数是为了让 #ask_box 与 #national_skill_box 共用同一套样式与清空语义，
 * 避免国家技能框与借用框争抢同一个 #ask_box 被覆盖（见 update_national_skill_box）。 */
// 【2026-10-16 之后】借用框 / 国家技能框整回合常驻，其 update_xxx_box 每帧都会调用本函数。
// 若每次都清空重建 DOM，按钮会"重弹"闪烁（用户报"每隔动作就重弹"）。
// 加内容签名缓存：标题+文本+按钮标签未变则跳过重建，框仍常驻、按钮仍可用，只是不闪。
const _box_last_sig = {}
function render_box_into(boxId, title, text, options) {
	const box = document.getElementById(boxId)
	if (!box)
		return
	const sig = (title == null ? 'NULL' : title) + '' + (text || '') + '' +
		(options || []).map(o => (o.label || '') + '|' + (o.cls || '')).join('~')
	if (_box_last_sig[boxId] === sig) {
		// 内容没变：保留已有 DOM，避免每帧重建导致框"重弹"
		return
	}
	_box_last_sig[boxId] = sig
	box.innerHTML = ""
	/*
	 * 【2026-10-15 修复】清空模式 = 标题为空（调用方传 null 显式收起面板）。
	 * 有标题 + 空 options 是【信息框】（如高速公路预算提示、无可征召地区提示），
	 * 必须照常显示——原逻辑把"无按钮"也当成收起，导致高速公路预算面板永远不可见。
	 */
	if (!title) {
		box.classList.add("hide")
		return
	}
	box.classList.remove("hide")

	const h = document.createElement("div")
	h.className = "ask_head"
	h.textContent = title
	box.appendChild(h)

	if (text) {
		const t = document.createElement("div")
		t.className = "ask_text"
		t.textContent = text
		box.appendChild(t)
	}

	for (const o of options) {
		const b = document.createElement("button")
		b.className = "action" + (o.cls ? " " + o.cls : "")
		b.textContent = o.label
		b.onclick = o.onClick
		box.appendChild(b)
	}
}

/* 通用询问面板（借用框 / 经济战 / 响应卡…共用，单一 #ask_box） */
function render_ask_box(title, text, options) {
	render_box_into("ask_box", title, text, options)
}

/* 国家技能专用面板（独立于 #ask_box，位置靠上；所有国家技能统一走这里） */
function render_national_skill_box(title, text, options) {
	render_box_into("national_skill_box", title, text, options)
}

/*
 * view.pending_ask：收回部队询问
 *
 * 【2026-10-22 玩家口径】不要列表按钮，改成 17532《战区移动》那种
 * "地图上高亮 + 点算子直接移除"的交互：
 *   · 候选部队由服务端下发（本方阵营全部部队），这里只负责高亮；
 *   · 面板只留标题/提示 + 「跳过」，不列清单；
 *   · 点击处理在 on_click_piece 的 pending_ask 分支（发 remove_piece）。
 */
function update_ask_box_from_view() {
	const ask = view && view.pending_ask
	if (!ask || !ask.pieces || !ask.pieces.length) {
		if (ask_state && ask_state.kind === "remove") {
			ask_state = null
			clear_piece_highlight("ask_remove")
			render_ask_box(null, null, [])
		}
		return
	}
	ask_state = { kind: "remove" }
	highlight_pieces(ask.pieces.map(p => p.id), "ask_remove")
	const facLabel = (ask.faction === "allies") ? "同盟国" : (ask.faction === "axis" ? "轴心国" : ask.nation)
	render_ask_box(
		"【" + facLabel + "】收回部队（" + ask.pieces.length + " 支可收回）",
		"点击地图上高亮的本方部队即可收回（可连续点，任意支数、任意兵种）；" +
			"点「跳过并关闭」会结束本次询问并把开关关掉。",
		[{ label: "跳过并关闭", cls: "primary", onClick: () => {
			clear_piece_highlight("ask_remove")
			send_action("clear_ask", {})
		} }]
	)
}

/* ============================================================
 * 【2026-09-29】各国牌库 / 弃牌堆 数量面板
 *
 * 数据来自 view.deck_counts / view.discard_counts —— 服务端【已经】给出
 * 全部六国（rules.js view 里按 ORDER_OF_NATIONS 遍历），
 * 以前客户端只显示了本国那一行，这里把它做成可展开的完整列表。
 *
 * 为什么有用：损耗规则（2026-09-29 口径）依赖牌库剩余张数——
 *   主动损耗牌库不足则无法发动；被动损耗不足要按差额扣分。
 * 玩家能直接看到各国牌库张数，才能判断"现在能不能损耗 / 会被扣几分"。
 * ============================================================ */
const AXIS_NATIONS = ["德国", "日本", "意大利"]
let deck_panel_open = false

function toggle_deck_panel() {
	deck_panel_open = !deck_panel_open
	update_deck_panel()
}

function update_deck_panel() {
	const listEl = document.getElementById("deck_list")
	const btn = document.getElementById("deck_toggle")
	if (!listEl) return

	/* 按钮上直接显示本国牌库，收起时也能看到关键数字 */
	const me = view && view.my_nation
	const dc = (view && view.deck_counts) || {}
	if (btn && me)
		btn.textContent = "各国牌库（我：" + (dc[me] || 0) + "）"

	if (!deck_panel_open) {
		listEl.classList.add("hide")
		return
	}
	listEl.classList.remove("hide")

	const order = (view && view.order_of_nations) || AXIS_NATIONS
	const disc = (view && view.discard_counts) || {}
	const rows = []
	for (const nat of order) {
		const deck = dc[nat] || 0
		const dis = disc[nat] || 0
		const isAxis = AXIS_NATIONS.indexOf(nat) >= 0
		/*
		 * 见底阈值：<=2 标红。
		 * 依据损耗规则——牌库不足时被动损耗会【差额扣分】，
		 * 主动损耗则【无法发动】，所以低牌库是需要玩家注意的状态。
		 */
		const low = deck <= 2
		rows.push(
			'<div class="deck-row' + (nat === me ? ' is-me' : '') +
			(low ? ' is-low' : '') + '">' +
			'<span class="dk-side" style="background:' +
			(isAxis ? '#8a2d2d' : '#1e3a5f') + '"></span>' +
			'<span class="dk-nation">' + esc(nat) + '</span>' +
			'<span class="dk-deck">牌库 ' + deck + '</span>' +
			'<span class="dk-discard">弃牌 ' + dis + '</span>' +
			'</div>')
	}
	if (!rows.length)
		listEl.textContent = "（暂无数据）"
	else
		listEl.innerHTML = rows.join("")
}

/* 【2026-10-18】各国后备面板：仅展示各国"陆/海/空 后备"（= 该兵种剩余可建容量，
 * 实时取自 上限−已部署），不展示"剩余可建"合计字段。
 * 数据来自 view.reserve_info（服务端实时计算），随每次 view 刷新实时更新，绝不硬编码。
 * 复用 各国牌库 面板的 .deck-row 形态与样式。 */
let reserve_panel_open = false

function toggle_reserve_panel() {
	reserve_panel_open = !reserve_panel_open
	update_reserve_panel()
}

function update_reserve_panel() {
	const listEl = document.getElementById("reserve_list")
	const btn = document.getElementById("reserve_toggle")
	if (!listEl) return

	const me = view && view.my_nation
	const res = (view && view.reserve_info) || {}
	if (btn)
		btn.textContent = "各国后备"

	if (!reserve_panel_open) {
		listEl.classList.add("hide")
		return
	}
	listEl.classList.remove("hide")

	/* 按服务端 reserve_info 实际给出的国家渲染（含中国/法国等），缺数据时回退到出战顺序，
	 * 不在此处硬编码任何国家名单。 */
	const order = Object.keys(res).length ? Object.keys(res) :
		((view && view.order_of_nations) || [])
	const rows = []
	for (const nat of order) {
		/* 真实数据缺省保护：任一字段缺失都以 0 兜底，绝不显示硬编码数值 */
		const r = res[nat] || { remaining: { army: 0, navy: 0, air: 0 } }
		const rem = r.remaining || { army: 0, navy: 0, air: 0 }
		const isAxis = AXIS_NATIONS.indexOf(nat) >= 0
		rows.push(
			'<div class="deck-row' + (nat === me ? ' is-me' : '') + '">' +
			'<span class="dk-side" style="background:' +
			(isAxis ? '#8a2d2d' : '#1e3a5f') + '"></span>' +
			'<span class="dk-nation">' + esc(nat) + '</span>' +
			'<span class="dk-reserve">陆：' + rem.army +
				'，海：' + rem.navy +
				'，空：' + rem.air + '</span>' +
			'</div>')
	}
	if (!rows.length)
		listEl.textContent = "（暂无数据）"
	else
		listEl.innerHTML = rows.join("")
}

/* ============================================================
 * 【2026-10-22】行动记录（history）与回退 / 时间回溯（rollback）
 *
 * 服务端契约：
 *   view.history            最近 120 条动作，每条带 from/to（对应 view.log 区间）
 *   view.history_total      累计动作数
 *   view.rollback_points    本回合（整轮）内可回退的检查点 [{index,turn,nation,label}]
 *   view.rollback_proposal  { by_side, label, turn } 或 null
 *   view.actions.propose_rollback / accept_rollback / reject_rollback / cancel_rollback
 *
 * 交互：
 *   顶栏「回退」-> 打开抽屉并定位到检查点区；点「回退到此处」发起提议（需对方同意）
 *   顶栏「记录」-> 打开抽屉看全局出牌流水
 *   提议挂起时：#rollback_bar 横幅给「同意 / 拒绝」（对方）或「撤回」（本方）
 * ============================================================ */

let hist_open = false
const hist_expanded = {}      /* 历史条目 n -> 是否展开该步日志 */

function my_side_key() {
	if (view && view.my_faction) return view.my_faction
	return (typeof player === 'string' && player === 'Axis') ? 'axis' : 'allies'
}

/*
 * 【2026-10-24 玩家口径】顶部只保留「行动记录」一个入口。
 *
 * 原先顶部有「回退」和「行动记录」两个按钮，但它们打开的是【同一个抽屉】
 * （toggle_history(true) 只是打开后滚到 #rb_section），容易被误认为两个功能。
 * #btn_rollback 已删除，这里退化为纯粹的"开/关抽屉"；
 * 回退区作为抽屉内的一个分区保留，点「回退到此处」仍需对方同意。
 */
function toggle_history() {
	const panel = document.getElementById('history_panel')
	if (!panel)
		return
	hist_open = !hist_open
	panel.classList.toggle('hide', !hist_open)
	if (hist_open)
		update_history_ui(true)
}

/* 回放模式下禁止发起回退（view 来自历史快照，提交会打乱真实对局） */
function in_replay_mode() {
	return !!(typeof params !== 'undefined' && params && params.mode === 'replay')
}

function can_propose_rollback() {
	if (in_replay_mode())
		return false
	return !!(view && view.actions && view.actions.propose_rollback)
}

/* n = 行动记录编号（= 服务端检查点编号，0 = 开局） */
function propose_rollback_to(n) {
	if (!can_propose_rollback()) {
		toast('现在不能提议回退（须轮到你行动、且存在检查点）')
		return
	}
	let h = null
	for (const x of (view.history || []))
		if (x.n === n) { h = x; break }
	const label = '第 ' + n + ' 步' + (h && h.label ? ' · ' + h.label : '')
	if (!confirm('回退到「' + label + '」需要对方同意。\n确认发起提议？'))
		return
	send_action('propose_rollback', { n: n })
}

function answer_rollback(accept) {
	send_action(accept ? 'accept_rollback' : 'reject_rollback', {})
}

function cancel_rollback() {
	send_action('cancel_rollback', {})
}

function toggle_hist_item(n) {
	hist_expanded[n] = !hist_expanded[n]
	update_history_ui(true)
}

function update_history_ui(force) {
	const panel = document.getElementById('history_panel')
	if (!panel || !view)
		return
	/* 抽屉关着就不重建（每步 view 都会调到这里，省开销） */
	if (!hist_open && !force)
		return

	/* ---------- ① 状态提示（检查点已并入下方流水，每条右侧有「回退」） ---------- */
	const rbList = document.getElementById('rb_list')
	if (rbList) {
		const n = (view.rollback_points || []).length
		const pr = view.rollback_proposal
		let html = ''
		if (pr) {
			html = '<div class="hist_empty">回退提议待确认：' + esc(pr.label || ('第 ' + pr.turn + ' 步')) +
				'（等对方在顶部横幅里同意/拒绝）</div>'
		} else if (!can_propose_rollback()) {
			html = '<div class="hist_empty">现在不能提议回退（需轮到你行动且存在检查点）</div>'
		} else {
			html = '<div class="hist_empty">点记录右侧「↺ 回退」发起时光回溯（需对方同意）；' +
				'当前保留 ' + n + ' 个检查点</div>'
		}
		rbList.innerHTML = html
	}

	/* ---------- ② 出牌流水（每条可展开日志；有检查点的可发起回退） ---------- */
	const cnt = document.getElementById('hist_count')
	const arr = (view.history || []).slice().reverse()
	if (cnt)
		cnt.textContent = '（共 ' + (view.history_total || 0) + ' 步，显示最近 ' + arr.length + ' 条）'

	const list = document.getElementById('hist_list')
	if (list) {
		if (!arr.length) {
			list.innerHTML = '<div class="hist_empty">暂无行动记录</div>'
		} else {
			const mine = my_side_key()
			const allow = can_propose_rollback() && !view.rollback_proposal
			list.innerHTML = arr.map(function (h) {
				const cls = 'hist_row' + (h.by === mine ? ' mine' : '')
				let detail = ''
				if (hist_expanded[h.n]) {
					const lines = (view.log || []).slice(h.from, h.to)
					detail = '<div class="hist_detail">' +
						lines.map(function (l) { return '<div>' + esc(l) + '</div>' }).join('') +
						'</div>'
				}
				const btn = (allow && h.can_rollback)
					? '<button class="hist_rb_btn" type="button" ' +
						'onclick="event.stopPropagation();propose_rollback_to(' + h.n + ')">↺ 回退</button>'
					: ''
				return '<div class="' + cls + '" onclick="toggle_hist_item(' + h.n + ')">' +
					'<span class="hist_step">#' + h.n + '</span>' +
					'<span class="hist_meta">T' + h.turn + ' · ' + esc(h.nation || '') + ' · ' +
					esc(PHASE_ZH[h.phase] || h.phase || '') + '</span>' +
					'<span class="hist_label">' + esc(h.label || '') + '</span>' +
					btn +
					detail +
					'</div>'
			}).join('')
		}
	}
}

function update_rollback_bar() {
	const bar = document.getElementById('rollback_bar')
	if (!bar)
		return
	const pr = view && view.rollback_proposal
	if (!pr) {
		bar.classList.add('hide')
		return
	}
	const mine = (pr.by_side === my_side_key())
	const txt = document.getElementById('rb_bar_text')
	const acts = document.getElementById('rb_bar_actions')
	if (txt) {
		txt.textContent = mine
			? '你提议回退到「' + (pr.label || '') + '」，等待对方确认…'
			: '对方提议回退到「' + (pr.label || '') + '」——同意后对局将退回该时点'
	}
	if (acts) {
		acts.innerHTML = mine
			? '<button class="action" type="button" onclick="cancel_rollback()">撤回提议</button>'
			: '<button class="action" type="button" onclick="answer_rollback(false)">拒绝</button>' +
			'<button class="action primary" type="button" onclick="answer_rollback(true)">同意回退</button>'
	}
	bar.classList.remove('hide')
}

/* 开关：友方出牌回合开始时是否询问（默认关闭 = 跳过） */
function toggle_ask_remove() {
	send_action("toggle_ask_remove", { value: !view.ask_remove })
	toast(view.ask_remove ? "已关闭询问（默认跳过）" : "已开启询问")
}

/* ============================================================
 * 基本卡的"选目标"流程
 *
 * 点卡 -> 查询合法目标（basic_targets）-> 高亮地图地区 ->
 * 点地区 -> send_action('play_card', {card, space, piece, mode})
 * Esc / 右键 / 再点同卡 -> 取消
 * ============================================================ */

let pending_card = null      /* 正在等待选目标的卡 */
let pending_mode = null      /* 《空军力量》的 mode */
let pending_targets = null   /* { spaces: [...], pieces: [...] } */
let lend_lease_active = null /* 租借法案委托中：当前被委托国（如 '英国'）；非空时基本卡选目标提交改走 resolve_us_lend_lease_play */
/* 【2026-10-22】17729 卡佩里尼：链中打出基本卡时同样复用 start_basic_card 流程
 * （《空军力量》的三选一、发起陆战/海战的选发起单位都由既有 UI 完成），
 * 最终提交改走 resolve_italy_play。非空 = 当前被处置国。 */
let italy_chain_active = null
let italy_chain_sub_started = null /* 已启动基本卡流程的实例 id，避免每帧重复 start */

function start_basic_card(c) {
	/* 再点同一张 -> 取消 */
	if (pending_card && pending_card.id === c.id) { cancel_basic_card(); return }

	/*
	 * 《空军力量》有三选一，先让玩家选模式。
	 * 这里用简单的方式：依次询问。为了不做复杂弹窗，
	 * 用 confirm 风格的自定义选择（用 toast + 三次点击循环太绕），
	 * 改为在卡牌上循环：第一次点击弹出模式选择按钮。
	 */
	if (c.name === "空军力量") {
		pending_card = c
		show_mode_chooser(c)
		return
	}

	pending_card = c
	pending_mode = null
	/*
	 * 注意：client.js 的签名是 send_query(q, param)，
	 * 结果通过全局 on_reply(q, result) 回调返回 —— 不是 (q, cb)。
	 */
	send_query("basic_targets", c.name)
	/* 进入选地块/选目标后刷新桌面状态卡（15341/15342 在打建设卡时可放弃建设） */
	update_table_status()
}

/* 《空军力量》的模式选择：在侧栏显示三个按钮 */
function show_mode_chooser(c) {
	const box = document.getElementById("mode_chooser")
	if (!box)
		return
	box.innerHTML = ""
	box.classList.remove("hide")

	/*
	 * 空军阶段只能"部署"或"夺取制空权"（2026-09-22 玩家明确）；
	 * "调度空军"在空军阶段走侧栏的【调度空军…】按钮（代价是弃 1 张手牌），
	 * 因此这里在空军阶段不列出 move，避免两条路径重复。
	 *
	 * 【2026-10-07】可行模式优先取服务端下发的 hand_ready[c.id].modes
	 * （判定同源，见 rules.js hand_ready 的《空军力量》特判）：
	 * 客户端不再只按阶段猜，否则会列出"本国没空军 -> 夺取制空权"这种
	 * 选了才被拒的死选项。服务端没给（老存档/异常）时退回按阶段猜。
	 */
	const hr = view.hand_ready && view.hand_ready[c.id]
	const okModes = (hr && hr.modes && hr.modes.length) ? hr.modes : null
	const allModes = [
		["deploy", "部署空军（须与本国补给中的陆/海军同格）"],
		["seize", "夺取制空权（移除敌方空军）"],
		["move", "调度空军（移到本国陆/海军处）"],
	]
	let modes = allModes
	if (okModes)
		modes = allModes.filter(([m]) => okModes.indexOf(m) >= 0)
	else if (view.turn_phase === "airforce")
		modes = allModes.filter(([m]) => m !== "move")

	if (!modes.length) {
		/* 一个可选项都没有：明确告诉玩家为什么，而不是弹出空框 */
		toast("《空军力量》当前无可执行的选项：" +
			((hr && hr.reason) || "没有合法目标"))
		cancel_basic_card()
		return
	}

	for (const [m, label] of modes) {
		const b = document.createElement("button")
		b.className = "action"
		b.textContent = label
		b.onclick = () => {
			pending_mode = m
			box.classList.add("hide")
			send_query("basic_targets", { card_name: "空军力量", mode: m })
		}
		box.appendChild(b)
	}

	/*
	 * 兜底：#mode_chooser 是 position:fixed 浮层，但 client.js 会给 main 加
	 * transform:scale —— 只要祖先有 transform，fixed 就退化成相对该祖先定位，
	 * 会被 main 的缩放带出可视区（历史上表现为"点了没反应 / 框不见了"，
	 * 见 play.css 里 #mode_chooser 的注释）。显示后自检一次，
	 * 落在视口外就改挂到 body 下，恢复真正的视口定位。
	 */
	if (box.parentElement !== document.body) {
		const rc = box.getBoundingClientRect()
		if (rc.height > 0 && (rc.bottom > window.innerHeight + 4 || rc.top < -4))
			document.body.appendChild(box)
	}

	const cancel = document.createElement("button")
	cancel.className = "action"
	cancel.textContent = "取消"
	cancel.onclick = () => { box.classList.add("hide"); cancel_basic_card() }
	box.appendChild(cancel)
}

/* 在地图上高亮可选地区 */
function highlight_targets(t) {
	clear_target_highlight()
	if (!t || !t.spaces)
		return
	for (const s of t.spaces) {
		const el = space_elt(s.id)
		if (el) {
			el.classList.add("target")
			el.title = s.reason || ""
		}
	}
	/* 可选敌方部队也高亮 */
	for (const p of (t.pieces || [])) {
		const el = piece_elt(p.id)
		if (el)
			el.classList.add("target")
	}
}

function clear_target_highlight() {
	const list = document.querySelectorAll(".target")
	for (let i = 0; i < list.length; i++)
		list[i].classList.remove("target")
}

function cancel_basic_card() {
	pending_card = null
	pending_mode = null
	pending_targets = null
	battle_flow = null
	lend_lease_active = null
	/* 【2026-10-22】17729 链打牌路由清掉（否则后续普通出牌会被误路由到 resolve_italy_play）。
	 * italy_chain_sub_started 不在这里清：提交后到 view 更新的空档里若再跑一帧，
	 * 否则会重开一次模式选择框；它由链推进（ch.sub 消失）时统一复位。 */
	italy_chain_active = null
	clear_piece_highlight("initiator")
	clear_target_highlight()
	if (ask_state && ask_state.kind !== "remove")
		render_ask_box(null)
	const box = document.getElementById("mode_chooser")
	if (box)
		box.classList.add("hide")
	/* 退出选地块/地图选择后刷新桌面状态卡（15341/15342 提示复位） */
	update_table_status()
}

/* 基本卡"选目标"最终提交：
 *   · 租借法案委托模式（lend_lease_active 非空）-> 改提交 resolve_us_lend_lease_play 并带 nation；
 *   · 否则正常 play_card。
 * 三处共用：on_space_click_for_card / finish_battle_card / on_pick_airforce_piece。
 * 各调用点各自负责 cancel_basic_card 清理。 */
function submit_basic_card(arg) {
	/*
	 * 【2026-10-22】17729 卡佩里尼委托打牌：与租借法案同款改路由。
	 * 必须放在 play_card 之前——否则牌会当成"当前行动国自己出牌"结算，名额/归属都错。
	 */
	if (italy_chain_active) {
		send_action('resolve_italy_play', arg)
		return
	}
	if (lend_lease_active) {
		arg.nation = lend_lease_active
		send_action('resolve_us_lend_lease_play', arg)
	} else {
		send_action('play_card', arg)
	}
}

/* 【2026-10-14】委托打牌时，事件/增强/状态卡的"选目标 / 选代价 / 多选"等后续提交
 * 一律改走 resolve_us_lend_lease_play（带 nation=被委托国），让服务端按被委托国结算。
 * 非委托场景 lend_lease_active 为空，退回正常的 play_card。 */
function lend_play_action(arg) {
	if (lend_lease_active) {
		send_action('resolve_us_lend_lease_play', Object.assign({}, arg, { nation: lend_lease_active }))
	} else {
		send_action('play_card', arg)
	}
}

/* 地图上点击地区时（link / 放置 之外的默认模式）被调用 */
function on_space_click_for_card(space_id) {
	if (!pending_card)
		return false
	if (!pending_targets)
		return false

	const allowed = pending_targets.spaces.some(s => s.id === space_id)
	if (!allowed) {
		toast("该地区不是《" + pending_card.name + "》的合法目标")
		return true
	}

	/*
	 * 提示文案：空地（无守军）时明确提示"空打"，
	 * 避免玩家以为没生效（卡牌照常打出、该回合出牌阶段即已行动）。
	 */
	const hit = pending_targets.spaces.find(s => s.id === space_id)
	const isEmpty = !!hit && /空地/.test(hit.reason || "")

	/* 战斗卡，或《空军力量》的"夺取制空权"模式：走两步询问（选目标→选发起单位） */
	if (is_battle_card(pending_card) || pending_mode === 'seize') {
		play_battle_card(space_id, null, isEmpty)
		return true
	}

	const arg = { card: pending_card.id, space: space_id }
	if (pending_mode)
		arg.mode = pending_mode
	submit_basic_card(arg)
	toast("已打出《" + pending_card.name + "》到 " + (view.spaces[space_id] || {}).name +
		(isEmpty ? "（空打：无守军）" : ""))
	cancel_basic_card()
	return true
}

function is_battle_card(c) {
	return c && (c.name === "发起陆战" || c.name === "发起海战")
}

/*
 * ============================================================
 * 战斗卡的地图交互流程（2026-09-22 玩家明确）
 *
 *   ① 在地图上点【发起单位】（本国、补给中、与目标相邻的陆/海军）
 *      —— 空军不能发起，因此只高亮陆/海军
 *   ② 再点【目标地区】或目标地区的【敌方部队】（空军不可选）
 *   ③ 若受创目标所在地区有同国空军 -> 【由防守方决定】是否用空军代受：
 *        · 代受   -> 空军被移除，原目标部队保住
 *        · 不代受 -> 原目标被移除，该空军必须撤往相邻合法位置，
 *                    无位置则被移除
 *
 * 交互状态机（battle_pick）：
 *   { step: 'from', space, kind }      等待点发起单位
 *   { step: 'target', space, kind, from } 等待点目标地区/敌军
 * ============================================================
 */

let battle_flow = null   /* { step, space, kind, from, isEmpty, victim, airs, retreats } */

/*
 * 点战斗卡后：先把可选目标高亮出来（地区 + 敌军），
 * 同时把"可发起单位"也高亮，等待玩家先点发起单位。
 */
function play_battle_card(space_id, piece_id, isEmpty) {
	battle_flow = {
		step: "from",          /* 第一步：在地图上选发起单位 */
		space: space_id,
		from: null,
		isEmpty: isEmpty,
		/* 记下玩家已经点过的那支部队，选完发起单位后自动作为目标 */
		preVictim: piece_id || null,
		victim: null,
	}
	ask_initiator_on_map(space_id)
}

/*
 * ① 进入"在地图上选发起单位"的状态。
 * 由服务端 battle_initiators 返回候选（只有陆/海军），
 * 客户端把它们高亮，玩家点地图上的算子即选中。
 */
function ask_initiator_on_map(space_id) {
	if (pending_mode === 'seize')
		send_query("air_initiators", { space: space_id })
	else
		send_query("battle_initiators", { space: space_id })
}

function show_initiator_choices(list) {
	const nm = (view.spaces[battle_flow.space] || {}).name || "?"
	battle_flow.initiators = list

	if (!list.length) {
		/*
		 * 【2026-10-23 修复】没有可用发起单位时的清理，必须按【来源】分流。
		 *
		 * 原实现无条件调 cancel_basic_card()（基础卡的取消函数）：
		 * 对状态卡战斗（17544 美国海军陆战队 / 15338 / 15339 / 15346）不起作用 ——
		 * status_act_phase 仍停在 'battle'、battle_flow 仍在、ask_state 仍是上一轮的
		 * 'battle_from'，于是【点地图没有任何反应】；而状态卡的瞬间窗口在服务端
		 * 因 r.ok=false 被保留，玩家又能在桌面上【反复点击同一张卡】重新进来。
		 * 两个症状同源，就是这里。
		 */
		render_ask_box(null)
		const isStatus = !!(battle_flow && battle_flow.origin === 'status')
		toast(pending_mode === 'seize'
			? "没有可发起空战的本国补给飞机（须与目标相邻且处于补给状态）"
			: (isStatus
				? "该地区周边没有可发起战斗的本国陆军/海军（须相邻且处于补给状态），请重新点击状态卡并选择其它地区"
				: "没有可发起战斗的本国陆军或海军（空军不能发起战斗）"))
		if (isStatus) cancel_status_act()
		else cancel_basic_card()
		return
	}

	/* 高亮可发起的本国算子，提示玩家点地图 */
	highlight_targets(pending_targets)
	highlight_pieces(list.map(u => u.id), "initiator")

	const isSeize = (pending_mode === 'seize')
	ask_state = { kind: "battle_from" }
	render_ask_box(
		"选择发起单位",
		"请在地图上点击一支【处于补给状态、与目标相邻的本国" +
			(isSeize ? "空军" : "陆军/海军") + "】来发起对 " + nm + " 的攻击" +
			(isSeize ? "" : "（空军不能发起战斗）"),
		[{ label: "取消", onClick: () => (battle_flow && battle_flow.origin === 'status'
			? cancel_status_act() : cancel_basic_card()) }]
	)
}

/*
 * 【2026-10-01】放弃"事件卡战斗预算"的发起单位选择，回到预算面板。
 * 预算本身不会因此结算，玩家可以再点其它目标，或点「结束《…》」收尾。
 */
function cancel_event_budget_pick() {
	battle_flow = null
	ask_state = null
	clear_piece_highlight('initiator')
	clear_target_highlight()
	render_ask_box(null)
	update_panels()
}

/* 玩家在地图上点了某个算子 */
function on_pick_initiator(piece_id) {
	const isSeize = (pending_mode === 'seize')
	if (!battle_flow || !battle_flow.initiators)
		return false
	const u = battle_flow.initiators.find(x => x.id === piece_id)
	if (!u) {
		toast(pending_mode === 'seize'
			? "不能用它发起空战（须是本国、补给中、与目标相邻的飞机）"
			: "不能用它发起战斗（须是本国、补给中、与目标相邻的陆军/海军）")
		return true
	}
	battle_flow.from = piece_id
	/*
	 * 【2026-10-01】事件卡战斗预算：选定发起单位后【直接提交】，
 * 不再需要玩家再点一次手牌/按钮（见 finish_event_budget_battle）。
 */
	if (battle_flow.origin === 'event') {
		const s = battle_flow.space
		const eps = battle_flow.enemyPieces || []
		/* 单一敌方：直接开打（带 victim，避免服务端自动取第一个敌国） */
		if (eps.length <= 1) {
			send_action('event_battle', {
				target: s,
				from: piece_id,
				victim: eps[0] ? eps[0].id : undefined,
			})
			toast('对 ' + ((view.spaces[s] || {}).name || '?') + ' 发起' +
				(battle_flow.kind === 'sea' ? '海战' : '陆战'))
			clear_piece_highlight('initiator')
			battle_flow = null
			ask_state = null
			render_ask_box(null)
			return true
		}
		/* 多国部队同处一格：进入"选受击单位"步骤，让玩家点击要打的那一支 */
		battle_flow.from = piece_id
		battle_flow.step = 'target'
		pending_targets = { spaces: [], pieces: eps }
		highlight_pieces(eps.map(e => e.id), 'initiator')
		ask_state = { kind: 'event_battle_victim', target: s }
		render_ask_box(
			'选择攻击目标',
			'该地区有 ' + eps.length + ' 支敌方部队，请点击要攻击的那一支',
			[{ label: '取消', onClick: () => cancel_event_budget_pick() }]
		)
		return true
	}

	/*
	 * 玩家可能是先点了敌方算子才进到这里（点算子时会带着 target 进来），
	 * 这时把这支部队直接当作目标，省掉再点一次。
	 */
	if (battle_flow.preVictim) {
		const pv = battle_flow.preVictim
		const cand = ((pending_targets && pending_targets.pieces) || [])
			.find(p => p.id === pv)
		battle_flow.preVictim = null
		if (cand) {
			battle_flow.victim = cand.id
			battle_flow.space = cand.space
			battle_flow.isEmpty = false
			clear_piece_highlight("initiator")
			ask_defense()
			return true
		}
	}

	battle_flow.step = "target"
	clear_piece_highlight("initiator")
	ask_state = { kind: "battle_target" }
	const seizeBox2 = isSeize
		? "现在请在地图上点击【敌方空军】来夺取制空权（或点击目标地区本身）"
		: "现在请在地图上点击【目标地区】或该地区的【敌方部队】" +
			"（空军不能作为攻击目标；若该地区没有敌军，则只能点地块本身）"
	render_ask_box(
		"已选发起单位：" + u.name + " @" + u.space_name,
		seizeBox2,
		[
			{ label: "重选发起单位", onClick: () => ask_initiator_on_map(battle_flow.space) },
			{ label: "取消", onClick: () => cancel_basic_card() },
		]
	)
	return true
}

/* ② 玩家点了目标地区或敌方算子 */
function on_pick_battle_target(space_id, piece_id) {
	const bf = battle_flow
	if (!bf || bf.step !== "target")
		return false

	const cand = ((pending_targets && pending_targets.pieces) || [])
		.filter(p => p.space === space_id)

	if (piece_id) {
		const v = cand.find(p => p.id === piece_id)
		if (!v) {
			toast(pending_mode === 'seize'
				? "该算子不是可夺取的敌方空军"
				: "该算子不能作为攻击目标（空军不可攻击）")
			return true
		}
		bf.victim = piece_id
		bf.isEmpty = false
	} else {
		/* 点了地块本身：只有该地区没有可攻击敌军时才允许 */
		if (cand.length) {
			toast(pending_mode === 'seize'
				? "该地区有敌方空军，必须点击要夺取的敌方飞机"
				: "该地区有敌军，必须点击要攻击的敌方部队（空军不可攻击）")
			return true
		}
		/* 事件战斗预算的"选受击单位"步骤：必须点具体敌方部队，不能空打/误点别处 */
		if (bf.origin === 'event') {
			toast('请点击要攻击的敌方部队')
			return true
		}
		bf.victim = null
		bf.isEmpty = true
	}
	bf.space = space_id

	if (bf.isEmpty) {
		finish_battle_card()
		return true
	}
	ask_defense()
	return true
}

/*
 * ③ 受创目标确定后提交战斗。
 *
 * 【重要】(2026-09-22)：这里【不再】由发起方询问"是否用空军代受"。
 * 那是防守方的决定，服务端会把战斗挂起（game.pending_battle），
 * 由【防守方】的界面收到 view.pending_battle 后自行决定。
 * 这样就彻底避免了一个浏览器席位替对方做决定。
 */
function ask_defense() {
	const bf = battle_flow
	const cand = ((pending_targets && pending_targets.pieces) || [])
		.filter(p => p.space === bf.space)
	const victim = (bf.victim ? cand.find(p => p.id === bf.victim) : null) || cand[0]
	if (victim)
		bf.victim = victim.id

	if (bf.origin === 'event') {
		/* 事件战斗预算：直接提交 event_battle（自带 victim，避免自动打第一个敌国） */
		send_action('event_battle', {
			target: bf.space,
			from: bf.from,
			victim: victim ? victim.id : undefined,
		})
		clear_piece_highlight('initiator')
		clear_target_highlight()
		battle_flow = null
		ask_state = null
		render_ask_box(null)
		return
	}

	/* 直接提交；若该地区有可代受的空军，服务端会挂起等防守方 */
	finish_battle_card()
}

/*
 * 防守方的询问面板（由 view.pending_battle 驱动，只有防守方拿得到）。
 * 面板上的选择通过 resolve_battle 提交。
 */
function update_pending_battle_box() {
	const pb = view.pending_battle

	if (!pb) {
		if (ask_state && (ask_state.kind === "defend" || ask_state.kind === "retreat" ||
			ask_state.kind === "counter" || ask_state.kind === "guard" ||
			ask_state.kind === "kv2" || ask_state.kind === "kv2_ask" ||
			ask_state.kind === "su_step_back")) {
			ask_state = null
			render_ask_box(null)
		}
		return
	}

	if (ask_state && ask_state.kind === "retreat" && ask_state.space === pb.space)
		return   /* 已在撤离选择中，不要被覆盖 */

	/*
	 * ---------- 阶段零：保护卡窗口（2026-10-06，日本 15410 武士道）----------
	 *
	 * 服务端在 victim 确定【之后】、移除【之前】把战斗挂起（stage='guard'），
	 * 候选（guard_cards）已由服务端算好 —— 客户端【不】二次判能不能打。
	 * 带弃牌代价的卡要先弹"选 N 张代价"框（start_guard_discard），
	 * 无代价的直接 send_action。
	 */
	if (pb.stage === "guard") {
		ask_state = { kind: "guard", space: pb.space }
		const byId = view.pieces_by_id || {}
		const vInfo = byId[pb.victim]
		const cards = pb.guard_cards || []
		const opts = cards.map(g => ({
			label: "打出《" + g.name + "》" + (g.cost
				? "（弃置 " + g.cost + " 张" +
					(g.cost_filter === 'response' ? '响应牌' : '手牌') + "）"
				: ""),
			onClick: () => start_guard_discard(g),
		}))
		opts.push({
			label: "不使用保护卡（该部队照常被移除）",
			cls: "primary",
			onClick: () => send_action("resolve_battle", { declined: true }),
		})
		render_ask_box(
			"【" + pb.defender_nation + "】是否打出保护卡？",
			"受攻击地区：" + ((view.spaces[pb.space] || {}).name || "?") +
				"　受创部队：" +
				(vInfo ? (vInfo.type_zh + "@" + vInfo.space_name) : "部队") +
				(cards.length ? "" : "（手上没有可打出的保护卡）"),
			opts
		)
		return
	}

	/*
	 * ---------- 阶段二：发起方决定是否抵消（2026-09-23）----------
	 *
	 * 同一个面板函数要服务两个阶段，因为等待方不同：
	 *   stage='defend'  -> 防守方：要不要用空军代受
	 *   stage='counter' -> 发起方：要不要用相邻空军抵消这次代受
	 *
	 * 服务端已按 stage 把 pending_battle 只发给该表态的那一方，
	 * 所以这里拿到 pb 就说明"轮到我决定了"。
	 */
	/*
	 * ---------- 阶段零 KV2_ASK：持有方决定是否发动（2026-10-07，苏联 17837 KV-2）----------
	 *
	 * 玩家口径：先由【苏联（持有方）】决定是否发动；发动后权力才交给攻击方。
	 * 不发动则卡留于桌面、战斗照常结算。
	 */
	if (pb.stage === "kv2_ask") {
		ask_state = { kind: "kv2_ask", space: pb.space }
		const byId = view.pieces_by_id || {}
		const vInfo = byId[pb.victim]
		render_ask_box(
			"【苏联】《KV-2 重型坦克》—— 是否发动？",
			"受攻击地区：" + ((view.spaces[pb.space] || {}).name || "?") +
				"　受创部队：" +
				(vInfo ? (vInfo.type_zh + "@" + vInfo.space_name) : "部队") +
				"　（发动后由【" + pb.attacker + "】二选一：弃置 4 张手牌，或该陆军本次战斗不被移除）",
			[{
				label: "发动（交给" + pb.attacker + "选择）",
				cls: "primary",
				onClick: () => send_action("resolve_battle", { kv2_trigger: true }),
			}, {
				label: "不发动（卡留于桌面）",
				onClick: () => send_action("resolve_battle", {}),
			}]
		)
		return
	}

	/*
	 * ---------- 阶段零 KV2：攻击方二选一（2026-10-07，苏联 17837 KV-2）----------
	 *
	 * 与 guard 相反：这里拿到 pb 的是【攻击方】（服务端按 stage 让权），
	 * 由攻击方在"弃置 4 张手牌"与"该陆军本次战斗不被移除"之间二选一。
	 */
	if (pb.stage === "kv2") {
		ask_state = { kind: "kv2", space: pb.space }
		const byId = view.pieces_by_id || {}
		const vInfo = byId[pb.victim]
		render_ask_box(
			"【" + pb.attacker + "】《KV-2 重型坦克》—— 请选择",
			"受攻击地区：" + ((view.spaces[pb.space] || {}).name || "?") +
				"　受创部队：" +
				(vInfo ? (vInfo.type_zh + "@" + vInfo.space_name) : "部队") +
				"　（两个选项都对防守方有利，你只是选代价较小的那个）",
			[{
				label: "弃置 4 张手牌（该陆军照常被移除）",
				/* 【2026-10-23】复用战斗内通用的"选 N 张牌"入口，不另建 UI。
				 * 手牌不足 4 张时按现有张数选（与服务端 Math.min(4, hand.length) 同口径）。 */
				onClick: () => {
					/*
					 * 【2026-10-28 #8】代价张数必须按【cost_nation】的手牌算，
					 * 不能用 view.my_nation。
					 *
					 * KV-2 是【攻击发起国】弃牌（德国攻苏联时就是德国付），
					 * 服务端 view.pending_battle.cost_nation 已算好（rules.js 23898）。
					 * 旧写法取 view.my_nation —— 那只是"此刻该谁操作"，
					 * 一旦与 cost_nation 不同（同阵营多国共控、委托等），
					 * 张数会算成 0 -> start_guard_discard 走 !g.cost 分支直接提交，
					 * 选牌框根本不出现，表现为"没有选择框"。
					 */
					const cn = pb.cost_nation || view.my_nation
					const hand = ((view.hands || {})[cn] || {}).cards || []
					start_guard_discard({
						card_id: pb.kv2_card,
						name: 'KV-2 重型坦克',
						cost: Math.min(4, hand.length),
						submit_target: 'kv2',
						discard_nation: cn,
					})
				},
			}, {
				label: "使该陆军在本次战斗中不被移除",
				cls: "primary",
				onClick: () => send_action("resolve_battle", { kv2: "protect" }),
			}]
		)
		return
	}

	/*
	 * ---------- 阶段零 SU_STEP_BACK：苏联持有方决定是否发动（2026-10-18，苏联 17853）----------
	 *
	 * 与 KV-2（17837）同款：拿到 pb 的是【苏联（持有方）】。
	 * 发动 -> 复用 echo_discard_modal 选 4 张手牌作为代价（与保护卡弃牌代价同款 UI）。
	 * 不发动 -> 卡留桌面、战斗照常结算。
	 */
	if (pb.stage === "su_step_back") {
		ask_state = { kind: "su_step_back", space: pb.space }
		const byId = view.pieces_by_id || {}
		const vInfo = byId[pb.victim]
		render_ask_box(
			"【苏联】《一步也不许后退!》—— 是否发动？",
			"受攻击地区：" + ((view.spaces[pb.space] || {}).name || "?") +
				"　受创部队：" +
				(vInfo ? (vInfo.type_zh + "@" + vInfo.space_name) : "部队") +
				"　（发动需弃置 4 张手牌，使该陆军本回合不被移除）",
			[{
				label: "发动（弃置 4 张手牌保护）",
				cls: "primary",
				onClick: () => start_step_back_discard(pb),
			}, {
				label: "不发动（卡留于桌面）",
				onClick: () => send_action("resolve_battle", { step_back: false }),
			}]
		)
		return
	}

	if (pb.stage === "counter") {
		ask_state = { kind: "counter", space: pb.space }
		const cands = pb.counter_airs || []
		const byId = view.pieces_by_id || {}
		const desc = cands.map(c => {
			const info = byId[c.id]
			return info ? (info.type_zh + "@" + info.space_name)
				: ("空军 " + c.id)
		}).join("、")

		render_ask_box(
			"【" + pb.attacker + "】是否用空军抵消这次代受？",
			"受攻击地区：" + ((view.spaces[pb.space] || {}).name || "?") +
				"　对方已用 1 支空军代受（原部队暂时保住）" +
				"（可抵消的空军 " + cands.length + " 支：" + (desc || "无") + "）",
			cands.map((c, i) => ({
				label: "用第 " + (i + 1) + " 支空军抵消" +
					"（双方各损失 1 支空军，原目标照常被移除）",
				onClick: () => send_action("resolve_battle", { counter_air: c.id }),
			})).concat([{
				label: "不抵消（代受成立，原部队保住）",
				cls: "primary",
				onClick: () => send_action("resolve_battle", { declined: true }),
			}])
		)
		return
	}

	ask_state = { kind: "defend", space: pb.space }

	/*
	 * 【2026-10-31 玩家口径·15213 云雾】空军"无法防御战斗"= 既不能代受、也不能撤离，
	 * 只能【原地移除】。服务端此时 airs / retreats 都是空、并给 air_no_retreat=true，
	 * 客户端只渲染一个按钮，避免玩家点"不代受"再掉进空撤退列表（体验上像"没选项可选"）。
	 */
	if (pb.air_no_retreat) {
		const boxes = view.pieces_by_id || {}
		const vi = boxes[pb.victim]
		render_ask_box(
			"【" + pb.defender_nation + "】《云雾》生效中",
			"受攻击地区：" + ((view.spaces[pb.space] || {}).name || "?") +
				"　受创部队：" + (vi ? (vi.type_zh + "@" + vi.space_name) : "部队") +
				"\n本回合空军无法防御战斗：既不能代受、也不能撤离 —— 同地区空军只能原地移除",
			[{
				label: "确认（部队与同地区空军原地移除）",
				cls: "primary",
				onClick: () => send_action("resolve_battle", { declined: true }),
			}])
		return
	}

	/*
	 * 【不要】用 view.pieces 过滤 pb.airs（2026-09-22 踩坑）。
	 *
	 * pb.airs 是服务端算好的、可代受的空军实例 id 列表，
	 * 直接可用。曾经写成：
	 *     pb.airs.filter(p => view.pieces && view.pieces[p] != null)
	 * 结果面板上一个按钮都没有（防守方"无法选择代受"）。
	 * 原因有二：
	 *   a) view.pieces 是按【本方代表国】过滤过的部队列表，
	 *      而防守方此刻关心的可能不是本国（例如法国部队由英国代表）；
	 *   b) view.pieces 的键是部队行/算子对象，不是 id 索引，
	 *      view.pieces[p] 取不到东西。
	 * 总之：服务端已经把该给的都给了，客户端别再二次筛选。
	 */
	const airs = pb.airs || []

	/* 把可代受的空军名号写清楚，方便玩家核对是不是自己想用的那支 */
	const byId = view.pieces_by_id || {}
	const airDesc = airs.map(a => {
		const info = byId[a]
		return info
			? (info.type_zh + "@" + info.space_name)
			: ("空军 " + a)
	}).join("、")

	render_ask_box(
		"【" + pb.defender_nation + "】是否用空军代受？",
		"受攻击地区：" + ((view.spaces[pb.space] || {}).name || "?") +
			"　受创部队：" + (pb.victim_type === "air" ? "空军" : "部队") +
			"（可代受的空军 " + airs.length + " 支：" + (airDesc || "无") + "）" +
			(pb.air_defend_disabled ? "　【云雾】本回合空军无法代受，该选项已置灰" : ""),
		airs.map((a, i) => ({
			label: "用第 " + (i + 1) + " 支空军代受（空军被移除，部队保住）",
			onClick: () => send_action("resolve_battle", { use_air: a }),
		})).concat([{
			label: "不代受（部队被移除，空军撤离）",
			cls: "primary",
			onClick: () => {
				const list = pb.retreats || []
				ask_state = { kind: "retreat", space: pb.space }
				const opts = list.map(r => ({
					label: "撤往 " + r.name,
					onClick: () => send_action("resolve_battle",
						{ declined: true, retreat: r.id }),
				}))
				opts.push({
					label: list.length ? "不移走（空军直接移除）" : "无处可撤（空军直接移除）",
					cls: "primary",
					onClick: () => send_action("resolve_battle", { declined: true }),
				})
				render_ask_box("空军撤往哪里？",
					list.length
						? "不代受时，同地区的本国空军必须撤往相邻的合法位置"
						: "没有相邻的合法位置，这些空军将被移除",
					opts)
			},
		}])
	)
}

/*
 * 【2026-09-26】经济战卡挂起：受击方【依次】决定自己的方案。
 *
 * 15314 马耳他潜艇群 —— 德国、意大利各自选择：
 *   损耗 3 张牌  /  移除地中海的 1 支本国海军（无海军时该选项禁用）
 *
 * 只有 view.pending_econ 非 null 的一方（= 当前待答复国所属阵营）会进这里。
 * 每答复一个国家立即结算，服务端会把 step 推进到下一个国家。
 */
let econ_pick_navy = null   /* 选 remove 时指定的海军算子 */

function update_pending_econ_box() {
	const pe = view.pending_econ
	if (!pe) {
		if (ask_state && ask_state.kind === 'econ') {
			ask_state = null
			render_ask_box(null, null, null)
		}
		econ_pick_navy = null
		clear_piece_highlight('econ')
		return
	}

	/*
	 * 只有 step 变化时才重置"已选海军"：
	 * 同一个国家重复渲染（例如亮点更新）不该把玩家的选择清掉。
	 */
	if (!ask_state || ask_state.kind !== 'econ' ||
		ask_state.step !== pe.step || ask_state.nation !== pe.nation) {
		econ_pick_navy = null
		clear_piece_highlight('econ')
	}

	const optAttrite = pe.options.find(o => o.id === 'attrite')
	const optRemove = pe.options.find(o => o.id === 'remove')
	const done = pe.resolved.length
		? '（已答复：' + pe.resolved.map(x => x.nation).join('、') + '）'
		: ''

	const text = '《' + pe.card_name + '》[' + pe.tag + '] —— 轮到【' +
		pe.nation + '】选择' + done

	ask_state = { kind: 'econ', step: pe.step, nation: pe.nation, pe: pe }

	const buttons = []
	if (optAttrite)
		buttons.push({
			label: optAttrite.label, cls: 'primary',
			onClick: () => send_action('resolve_econ', { choice: 'attrite' }),
		})
	if (optRemove) {
		buttons.push({
			label: optRemove.label,
			cls: optRemove.enabled ? '' : 'disabled',
			/* 禁用时不回调：服务端也会拒绝，这里提前挡掉 */
			onClick: optRemove.enabled
				? () => econ_choose_remove(pe, optRemove)
				: null,
		})
	}
	render_ask_box('经济战等待选择', text, buttons)

	/* 选了 remove 但还没指定海军 -> 高亮可选海军，让玩家在地图上点 */
	if (econ_pick_navy === 'selecting') {
		const navies = (optRemove && optRemove.navies) || []
		if (navies.length)
			highlight_pieces(navies, 'econ')
	}
}

/* ============================================================
 * 高速公路（15228，德国卡组）/ 西伯利亚大铁路（17827，苏联卡组）选位 UI
 *
 * 服务端 play_card 命中后收回全部本国陆军、写入 view.pending_autobahn
 * （{ remaining, total, actor }）。客户端在这里：
 *   · 查询 autobahn_targets 拿到"当前可合法建设陆军"的地区并高亮；
 *   · 玩家点地图（on_click_space 顶部拦截）发 resolve_autobahn；
 *   · 与服务端 ECON 同理，期间锁住手牌等其他操作。
 *
 * 【2026-10-15 重构·改用独立持久面板】
 * 与巴巴罗萨《战斗预算》#event_budget_box 同款，不再占用 #ask_box。
 *
 * 为什么必须挪出 ask_box（玩家确认的 bug「贵在行动不能中途发动」）：
 *   本函数【每帧】都被 render 调用；旧实现无条件 render_ask_box(...) 重写 ask_box，
 *   于是玩家点桌面状态卡（如 15247 贵在行动）弹出的「发动状态卡」确认框，
 *   会在下一帧被本面板直接覆盖 —— 玩家根本点不到「确认发动」，
 *   表象就是"中途点了没反应 / 发动不了"。
 *   挪到独立面板后 ask_box 空出来给确认框，两者互不干扰。
 *
 * 候选地区高亮仍由 query autobahn_targets 的 on_reply 负责（不在此处贴）。
 * ============================================================ */
let autobahn_query_remaining = null   /* 上次查询时的剩余次数，仅用于节流，避免每帧打 RPC */
/*
 * 【2026-10-20】建设预算的候选【缓存】。
 * autobahn_targets 是 RPC 异步返回，而 update_map 每帧都会用 highlight_targets
 * （内部先全清 .target）刷新高亮 —— 不缓存的话候选活不过一帧，
 * 表现为"能点建设、却看不到高亮"。这里在 on_reply 存一份供每帧重贴。
 */
let autobahn_cands = null

function update_pending_autobahn_box() {
	const pa = view && view.pending_autobahn
	const box = document.getElementById('autobahn_box')
	if (!box) return
	if (!pa) {
		box.classList.add('hide')
		box.innerHTML = ''
		/*
		 * 【2026-10-07 修复（沿用）】只清理【本面板自己贴过的】高亮，
		 * 不能"顺手全清" —— 否则会把 update_event_budget_box 刚贴上
		 * 的高亮一起抹掉（表现为"15205 给出预算后地图没有高亮"）。
		 * 高亮是全局资源，谁贴的谁负责清。
		 */
		if (autobahn_query_remaining !== null) {
			autobahn_query_remaining = null
			clear_target_highlight()
		}
		if (ask_state && ask_state.kind === 'autobahn') ask_state = null
		return
	}

	/* 只在"剩余次数"变化时重新查询，避免每次刷新都打一次 RPC */
	if (autobahn_query_remaining !== pa.remaining) {
		autobahn_query_remaining = pa.remaining
		send_query('autobahn_targets', {})
	}

	/*
	 * 【2026-10-20】17529 委托建设预算（source==='su_build_delegate'）与
	 * 高速公路/西伯利亚大铁路共用本面板，但语义不同：委托预算【有】结束入口
	 * （点结束才归还美国并触发国家技能），且建设后可插入发动苏联本国状态卡。
	 */
	const isSuDelegate = (pa.source === 'su_build_delegate')
	const nm = isSuDelegate ? '摩尔曼斯克运输船队'
		: ((pa.actor === '苏联') ? '西伯利亚大铁路' : '高速公路')
	box.classList.remove('hide')
	box.innerHTML = ''

	const title = document.createElement('div')
	title.className = 'eb-title'
	title.textContent = '《' + nm + '》建设预算：剩 ' + pa.remaining + ' / ' + pa.total + ' 次'
	box.appendChild(title)

	const hint = document.createElement('div')
	hint.className = 'eb-hint'
	hint.textContent = isSuDelegate
		? '苏联建设 1 支陆军：点地图高亮地区建设（可先发动本国状态卡）。完成后点「结束预算」收尾并归还美国。'
		: '点地图上高亮的地区建设 1 支' + (pa.actor || '德国') +
			'陆军。收回的部队必须全部重建（本预算无「结束」）。'
	box.appendChild(hint)

	/* 委托建设预算的收尾按钮（唯一入口；顺序上严格晚于建设与状态卡） */
	if (isSuDelegate) {
		const btn = document.createElement('button')
		btn.className = 'action primary'
		btn.textContent = '结束预算（归还美国）'
		btn.onclick = () => send_action('finish_su_build_budget', {})
		box.appendChild(btn)
	}
}

/* ============================================================
 * 【2026-10-25】战区移动（17532）分步状态机 UI
 *
 * 服务端 view.pending_theater = { actor, stage, order, built, step, total, label, can_act }
 * 每步调一次 resolve_theater：
 *   stage='remove'      -> 点地图上的美国陆军/海军算子，传 { piece }
 *   stage='build_navy'  -> 点高亮海域，传 { space }
 *   stage='build_army'  -> 点高亮陆地，传 { space }
 *
 * 候选由 query('theater_targets') 按【当前 stage 现算】（服务端此时移除已真实发生），
 * 因此候选与执行天然同源；缓存两个数组供 update_map 每帧重贴高亮。
 * 与 15228 高速公路的区别：那边是"剩 N 次"循环，本卡是"有顺序的三步"。
 * ============================================================ */
let theater_query_sig = null
let theater_space_cands = null
let theater_piece_cands = null

function update_pending_theater_box() {
	const pa = view && view.pending_theater
	const box = document.getElementById('theater_box')
	if (!box) return
	if (!pa) {
		box.classList.add('hide')
		box.innerHTML = ''
		if (theater_query_sig !== null) {
			theater_query_sig = null
			theater_space_cands = null
			theater_piece_cands = null
			clear_target_highlight()
			clear_piece_highlight('theater')
		}
		return
	}
	/* 步骤变化才重查（节流，避免每帧打 RPC） */
	const sig = pa.stage + '|' + pa.step
	if (theater_query_sig !== sig) {
		theater_query_sig = sig
		theater_space_cands = null
		theater_piece_cands = null
		send_query('theater_targets', {})
	}
	box.classList.remove('hide')
	box.innerHTML = ''
	const title = document.createElement('div')
	title.className = 'eb-title'
	title.textContent = '《' + (pa.card_name || '战区移动') + '》第 ' + pa.step + ' / ' + pa.total + ' 步'
	box.appendChild(title)

	/*
	 * 【2026-10-30】本步"可先发动"的状态卡：直接用服务端算好的 ready，
	 * 客户端不二次判断（与 #event_step_box 的 offers 同款口径）。
	 * 每个都给一个「发动《X》」按钮，点它进入该卡既有的选地/选目标流程。
	 */
	const offers = (view.table_status || []).filter(t => t.ready === true)
	const hint = document.createElement('div')
	hint.className = 'eb-hint'
	if (!pa.can_act) {
		hint.textContent = '等待【' + pa.actor + '】操作：' + pa.label
	} else {
		const todo = pa.stage === 'remove'
			? '点地图上高亮的美国陆军或海军算子，移除 1 支'
			: ('点地图上高亮的地区，建设 1 支' + (pa.stage === 'build_navy' ? '海军' : '陆军'))
		hint.textContent = todo + (offers.length
			? '（可先发动 ' + offers.map(o => '《' + o.name + '》').join('、') +
				'；不发动就直接点「下一步」）'
			: '')
	}
	box.appendChild(hint)

	/*
	 * 【2026-10-31 玩家口径】本面板只留「下一步」一个按钮：
	 *   发动 -> 直接点桌面上的状态卡（沿用 17550 既有的选地流程）；
	 *   不发动 -> 点「下一步」。
	 * 不在右上角 UI 里再列「发动《X》」按钮，避免和桌面卡重复入口。
	 */

	const btn = document.createElement('button')
	btn.className = 'action primary'
	btn.textContent = '下一步'
	btn.disabled = !pa.can_act
	btn.onclick = () => {
		if (!pa.can_act) { toast('等待【' + pa.actor + '】操作《战区移动》'); return }
		send_action('theater_next', {})
	}
	box.appendChild(btn)

	const order = document.createElement('div')
	order.className = 'eb-log'
	const doneList = [pa.built.navy ? '海军' : null, pa.built.army ? '陆军' : null].filter(Boolean)
	order.textContent = '顺序：' +
		pa.order.map(t => (t === 'navy' ? '海军' : '陆军')).join(' → ') +
		'（已完成：' + (doneList.length ? doneList.join('、') : '无') + '）'
	box.appendChild(order)
}

/* ============================================================
 * 【2026-09-30】多步脚本卡的选牌 UI（15229/15239/14503）
 *
 * 服务端 view.pending_script 给出"当前第几步、要选几张"，
 * 候选通过 query('script_state') 拿（牌堆内容随时变，且不能进公共 view）。
 *
 * 三种 step_kind：
 *   pick    —— 从本国牌堆挑 N 张（15229 挑 1 张状态卡；15239 挑 2 张抽入手牌）
 *   discard —— 从本国手牌挑 1 张弃置（15239 第 2 步）
 *   answer  —— 让权后的英国挑 1 张桌面暗置响应暗弃（14503）
 * ============================================================ */
let script_state = null    /* 服务端 script_state 的返回值 */
let script_sel = []        /* 已选卡的实例 id */

const SCRIPT_STEP_LABEL = {
	pick: { name: '牌堆（点选切换）', confirm: '确认抽取' },
	discard: { name: '手牌（点选切换）', confirm: '确认弃置' },
	answer: { name: '桌面暗置的响应（点选切换）', confirm: '确认暗牌弃置' },
}

function update_pending_script_box() {
	const ps = view && view.pending_script
	if (!ps) {
		script_state = null
		script_sel = []
		const modal = document.getElementById('script_modal')
		if (modal) modal.classList.add('hide')
		return
	}
	/*
	 * 只在"步骤 / 来源卡"变化时重新查询：
	 * 否则每次 update_ui 都会打一次 RPC。
	 */
	if (!script_state || script_state.stage !== ps.stage ||
		script_state.source !== ps.source) {
		send_query('script_state', {})
		return
	}
	render_script_modal(ps)
}

function render_script_modal(ps) {
	const modal = document.getElementById('script_modal')
	if (!modal) return
	modal.classList.remove('hide')

	const st = script_state || {}
	const conf = SCRIPT_STEP_LABEL[st.step_kind] || SCRIPT_STEP_LABEL.pick

	set_text('script_title', (st.prompt || ('《' + ps.source_name + '》')) +
		'（第 ' + ps.stage + '/' + ps.total + ' 步）')
	set_text('script_name', conf.name)
	set_text('script_note', script_sel.length + '/' + (st.need || 1))

	const grid = document.getElementById('script_grid')
	if (grid) {
		grid.innerHTML = ''
		for (const c of (st.candidates || [])) {
			const picked = script_sel.indexOf(c.id) >= 0
			let d
			if (st.step_kind === 'answer') {
				/* 暗牌弃置：候选是桌面暗置响应，只显示卡背（身份不可见） */
				d = build_response_card_elt(null, false)
				d.title = '暗置的响应（背面向上，身份不明）'
				d.style.cursor = 'pointer'
				d.addEventListener('click', () => on_script_pick_card(c.id))
			} else {
				d = card_elt(c, () => on_script_pick_card(c.id))
			}
			d.classList.toggle('sel', picked)
			if (picked) {
				const b = document.createElement('span')
				b.className = 'badge'
				b.textContent = '已选 ' + (script_sel.indexOf(c.id) + 1)
				d.appendChild(b)
			}
			grid.appendChild(d)
		}
		if (!(st.candidates || []).length) {
			const p = document.createElement('div')
			p.className = 'empty-note'
			p.textContent = '没有可选的牌'
			grid.appendChild(p)
		}
	}
	const okBtn = document.getElementById('script_confirm')
	if (okBtn) {
		okBtn.textContent = (st.step_kind === 'pick' && ps.kind === 'play_status_from_deck')
			? '确认打出' : conf.confirm
		okBtn.disabled = (script_sel.length !== (st.need || 1))
	}
}

function on_script_pick_card(id) {
	const st = script_state || {}
	const need = st.need || 1
	const i = script_sel.indexOf(id)
	if (i >= 0)
		script_sel.splice(i, 1)
	else if (script_sel.length < need)
		script_sel.push(id)
	else {
		toast('本步只需选 ' + need + ' 张，请先取消一张')
		return true
	}
	render_script_modal((view && view.pending_script) || {})
	return true
}

function confirm_script_pick() {
	const ps = view && view.pending_script
	if (!ps || !script_state) return
	const picked = script_sel.slice()
	if (picked.length !== (script_state.need || 1)) {
		toast('还需选 ' + ((script_state.need || 1) - picked.length) + ' 张')
		return
	}
	script_sel = []
	/* 弃牌阶段是单张 —— 服务端 arg.discard；其余用 arg.pick 数组 */
	if (script_state.step_kind === 'discard')
		send_action('resolve_script', { discard: picked[0] })
	else
		send_action('resolve_script', { pick: picked })
}

/*
 * 点了"移除海军"后的两步：
 *   ① 先把状态切成 selecting，高亮地图上可选的本国海军，提示去点地图
 *   ② 玩家点了某个算子 -> econ_pick_navy = piece_id -> 按钮变成"确认移除"
 */
function econ_choose_remove(pe, optRemove) {
	const navies = optRemove.navies || []
	if (!navies.length) {
		toast('该国在地中海没有可移除的海军')
		return
	}
	econ_pick_navy = 'selecting'
	update_pending_econ_box()
	toast('请在地图上点击要移除的 1 支海军（该地区同国空军会一起移除）')
}

/*
 * 地图上点击算子时调用（见 on_click_piece）：经济战选海军。
 * 返回 true 表示"这次点击已被经济战流程消费掉"。
 *
 * 【别再二次筛选】服务业已经把可移除的海军 id 放进 pe.options[remove].navies，
 * 客户端直接用即可。view.pieces 是按本方代表国过滤的部队列表、且键不是 id
 * （2026-09-23 踩过同样的坑，见 docs/pitfalls.md），不要拿它去校验。
 */
function econ_on_pick_piece(piece_id) {
	const pe = view.pending_econ
	if (!pe || econ_pick_navy !== 'selecting') return false
	const optRemove = pe.options.find(o => o.id === 'remove')
	if (!optRemove) return false
	const navies = optRemove.navies || []
	const hit = navies.some(x => String(x) === String(piece_id))
	if (!hit) {
		toast('请选择该国位于' + (pe.space_name || '地中海') + '的海军')
		return true
	}
	econ_pick_navy = piece_id
	clear_piece_highlight('econ')
	highlight_pieces([piece_id], 'econ')
	render_ask_box('经济战等待选择',
		'确认移除位于【' + (pe.space_name || '地中海') + '】的那支' +
			pe.nation + '海军？（同地区' + pe.nation + '空军会一起移除）', [
			{
				label: '确认移除', cls: 'primary',
				onClick: () => send_action('resolve_econ',
					{ choice: 'remove', piece: piece_id }),
			},
			{
				label: '重新选择', cls: '',
				onClick: () => { econ_pick_navy = 'selecting'; update_pending_econ_box() },
			},
		])
	return true
}

/*
 * 【2026-09-26】桌面状态卡渲染。
 *
 * 服务端通过 view.table_status 暴露本方桌面上的状态卡 + 每张是否可触发。
 * 这里在桌面状态区（#table_status 或动态创建的容器）里渲染：
 *   · 每张状态卡一卡片（卡名 + 描述）
 *   · ready=true 时高亮可点击
 *   · 已用 once_per_turn 时打"本回合已用过"标记
 */
function update_table_status() {
	const list = (view.table_status || []).slice()
	const host = document.getElementById('table_status') ||
		ensure_table_status_host()
	if (!list.length) {
		host.style.display = 'none'
		host.innerHTML = ''
		return
	}
	host.style.display = ''
	host.innerHTML = '<div class="ts-title">桌面状态卡</div>'
	for (const c of list) {
		/*
		 * 【2026-10-12 重构】与手牌 / 桌面响应卡同尺寸、同交互。
		 *
		 * 复用 build_response_card_elt（响应卡的"只展示"卡片渲染器），
		 * 它已经提供：.card（120x180 卡图 2:3）+ 文字回落层 + title +
		 * 【悬停放大到 #tooltip】+ 不挂"打出"点击 —— 正是状态卡需要的，
		 * 不自己再造一套卡图渲染（铁律：复用优先）。
		 *
		 * 原先这里是 min-width:150/max-width:220 的"卡图 + 文字块"，
		 * 比手牌大近一倍且没有悬停大图。
		 */
		const cardObj = {
			id: c.card,
			name: c.name,
			img: c.img,
			text: c.text || c.desc || '',
			type: 'STATUS',
		}
		const el = build_response_card_elt(cardObj, true)
		el.classList.add('ts-card')
		el.setAttribute('data-card', c.card)

		/* 用 status_ui_of：c.card 是实例 id（#3），STATUS_UI 的 key 是基础 id */
		const ui = status_ui_of(c.card)
		let badge = ''
		let badgeCls = ''
		if (c.attrition_log != null) {
			/* 喷气式战斗机(15251)：只读查看德国损耗记录 */
			el.classList.add('ready', 'log-ready')
			badge = '查看损耗记录'
			badgeCls = 'blue'
		} else if (ui.build) {
			/*
			 * S4：仅当正在打《建设陆军》卡（进入选地块）时才高亮可放弃建设；
			 * 否则灰显，避免"错误时点显示可打出"。
			 *
			 * 【2026-09-28】这里【不能】再要求 c.ready：
			 * build_army 是事件驱动窗口，服务端 status_window_ready 恒 false
			 * （刻意如此，保证其余时间不可点）。若还要求 ready，
			 * 正在建设时该卡仍是灰显 -> 点了也会被 !c.ready 拦掉。
			 * 判定只看"是否正在建设中"（building），与 on_click_table_status 同源。
			 */
			/*
			 * 【2026-10-25 修复】必须再判【这张卡归属国 == 当前行动国】。
			 * 桌面状态区是【整个阵营】共享可见的，所以苏联/美国玩家也能看到
			 * 英国桌面的 15341《澳大利亚劳管局》/ 15342《印度宣布参战》；
			 * 旧判定只看"是否正在打《建设陆军》"，于是苏联/美国建设陆军时
			 * 这两张英国卡也亮成"可放弃建设"（点了会被服务端拒绝，
			 * 因为 register_status_actions 对它们要求 current_nation==='英国'）。
			 * 通用判据（不写死卡号）：卡归属国 == view.current_nation，
			 * 同时覆盖 17742《拉丁世界》（意大利）等所有"替换建设"卡。
			 */
			/*
			 * 【同源优先】服务端 view.table_status[].forgo_build 已经按
			 * "卡归属国 == 当前行动国"算好（15341/15342 仅在英国建设时为 true，
			 * 17742 仅在意大利建设时为 true），客户端直接采信，不二次判断国家。
			 * 老版本若没有该字段则退回国家比对。
			 */
			const ownerNation = c.nation ||
				((view.table_status || []).find(t => t.card === c.card) || {}).nation || ''
			const forgoOk = (c.forgo_build !== undefined && c.forgo_build !== null)
				? (c.forgo_build === true)
				: (ownerNation === view.current_nation)
			const building = !!(pending_card && pending_card.name === '建设陆军') && forgoOk
			if (building) {
				el.classList.add('ready', 'build-ready')
				badge = '可放弃建设'
				badgeCls = 'green'
			} else {
				el.classList.add('ts-disabled')
				badge = (pending_card && pending_card.name === '建设陆军')
					? '仅' + (ownerNation || '该国') + '建设时可放弃'
					: '待建设陆军'
				badgeCls = 'gray'
			}
		} else if (ui.auto) {
			/* 自动卡（15340 国家资源动员法）：计分阶段自动结算，不可主动触发 */
			el.classList.add('ts-auto')
			badge = '自动结算'
			badgeCls = 'gold'
		} else if (c.ongoing && !c.trigger) {
			/* 持续效果（光环/地图改动）卡：不可主动触发 */
			el.classList.add('ts-ongoing')
			badge = '持续效果'
			badgeCls = 'blue'
		} else if (c.ready) {
			el.classList.add('ready')
			badge = '可触发'
			badgeCls = ''
		} else {
			/* 不可触发（被压制 / 已用过 / 非本国回合 / 时机不对）：灰显 */
			el.classList.add('ts-disabled')
			if (c.once_per_turn && c.used_this_turn) {
				badge = '本回合已用'
				badgeCls = 'red'
			} else {
				badge = '不可发动'
				badgeCls = 'gray'
			}
		}
		if (badge) {
			const b = document.createElement('div')
			b.className = 'ts-badge ' + badgeCls
			b.textContent = badge
			el.appendChild(b)
		}

		/*
		 * 详细文案放进 title：卡名 + 卡面文字 + 状态原因。
		 * 原先这些文字直接渲染在卡下方（占大量高度），现在卡片只有 120x180，
		 * 文字改由 title（原生提示）与悬停大图承载，信息不丢失。
		 */
		const why = c.ready ? '可触发' : (c.ready_reason || '')
		el.title = c.name +
			'\n' + (c.desc || c.text || '') +
			(why ? '\n（' + why + '）' : '')

		/* 点击 -> 触发（可触发的触发效果，其余给原因提示） */
		el.onclick = () => on_click_table_status(c.card)
		host.appendChild(el)
	}
}

/*
 * 【2026-10-18】喷气式战斗机(15251) 只读损耗记录弹框。
 * 数据全部来自 view.table_status[].attrition_log（已随 view 下发），
 * 仅展示、不发送任何 action、不触发任何技能/效果/状态变更。
 */
function showAttrLogBox(cards) {
	const modal = document.getElementById('attr_log_modal')
	if (!modal) return
	modal.onclick = (e) => { if (e.target === modal) close_attr_log() }
	modal.classList.remove('hide')
	const grid = modal.querySelector('#attr_log_grid')
	const hint = modal.querySelector('#attr_log_hint')
	if (grid) grid.innerHTML = ''
	if (!cards || !cards.length) {
		if (hint) hint.textContent = '《喷气式战斗机》打出后，德国此后损耗的卡牌将记录于此。'
		return
	}
	if (hint) hint.textContent = '共 ' + cards.length + ' 张（自《喷气式战斗机》打出后德国损耗的卡牌）：'
	for (const c of cards) {
		const o = { id: c.id, name: c.name, img: c.img, text: c.text, type: 'UNKNOWN' }
		if (grid) grid.appendChild(build_response_card_elt(o, true))
	}
}
function close_attr_log() {
	const modal = document.getElementById('attr_log_modal')
	if (modal) modal.classList.add('hide')
}

/* 找不到 #table_status 容器就动态创建一个，插到手牌区上方 */
function ensure_table_status_host() {
	let h = document.getElementById('table_status')
	if (h) return h
	h = document.createElement('div')
	h.id = 'table_status'
	h.className = 'panel-list table-status'
	const hand = document.getElementById('hand_cards')
	const parent = hand ? hand.parentElement : document.querySelector('.main')
	if (parent && hand) parent.insertBefore(h, hand)
	else if (parent) parent.appendChild(h)
	else document.body.appendChild(h)
	return h
}

/*
 * 点击桌面状态卡 -> 触发它。
 *
 * 客户端需要知道每张触发卡需要哪些交互（弃牌 / 选发起单位 / 选目标地区）。
 * 这里用一份精简的 UI 配置镜像服务端 STATUS_EFFECTS 的 trigger 部分，
 * 因为 view.table_status 只给"是否就绪"，不给代价细节。
 *
 *   discard : 需要的弃牌张数（从手牌选）
 *   battle  : 'land' | 'sea' —— 需走两步地图流程（选地区 + 选发起单位 + 选目标）
 *   spaces  : 限定可攻击的地区名（如 15338 只能打西欧/意大利）
 *   attacker: 发起国（状态卡战斗一律由法国发起）
 *   fixed   : 战斗地区由触发窗口给定（15346），无需玩家选地区
 *   build   : 建设陆军窗口（S4），点击即放弃建设改为征召（由服务端校验上下文）
 */
const STATUS_UI = {
	/* 15338 / 15339：trigger 无 nation 字段，
	 * 发起方 = 状态卡所在桌面的 owner 国（英国玩家位 = 英国）。
	 * 与设计 §0 S3 一致：由英国陆/海军发起（相邻 + 补给中）。
	 * attacker_owner:true 表示取该卡桌面的 owner 国，而非固定法国。 */
	'15338': { discard: 2, battle: 'land', spaces: ['西欧', '意大利'], attacker_owner: true },
	'15339': { discard: 2, battle: 'sea', attacker_owner: true },
	/* 15346：tr.nation='法国'，固定由法国发起 */
	'15346': { battle: 'land', attacker: '法国', fixed: true },
	'15345': {},
	'15347': {},
	'15348': { count_by: { spaces: ['加拿大', '印度', '非洲南部'], nation: '英国', type: 'army' } },
	/* 15340 国家资源动员法：自动卡（计分阶段自动结算），不可主动触发 */
	'15340': { auto: true },
	/*
	 * 17749 轴心协定：自动卡，但【不是】计分阶段 ——
	 * 敌方部队在其大本营或相邻被友方攻击时由服务端钩子自动 +1 分。
	 * 标 auto 是为了不在桌面显示成"不可发动"（它无需点击，并非失效）；
	 * autoDesc 用于把提示文案说准（否则会误提示"计分阶段自动生效"）。
	 */
	'17749': { auto: true, autoDesc: '敌方部队在其大本营或相邻地区被友方攻击时，自动 +1 分（每国每回合 1 次）' },
	/* 15341/15342：打《建设陆军》卡进入选地块时可放弃建设，改在指定地区征召 */
	'15341': { build: true, recruit: '澳大利亚' },
	'15342': { build: true, recruit: '印度' },
	/* 【2026-10-08】17742 拉丁世界：同款"替换建设"，征召地为<拉丁美洲>。
	 * 服务端 view 的 forgo_build 由 trig.cost.forgo_build_army 自动推导，
	 * 客户端渲染/点击/无合法位置兜底三处均泛型，故只需在此登记一行。 */
	'17742': { build: true, recruit: '拉丁美洲' },
	/* 2026-10-10 建设预算状态卡：多地区须玩家手动点选相邻空格（不自动兜底）。
	 * 服务端 run 读 arg.space 经 status_build_valid 校验后建设/征召。 */
	'17552': { sbuild: 'army' },
	/* 17843 量与质兼得：弃1张[建设陆军]后建设1支陆军（弃牌+建设组合，先收弃牌再选地） */
	'17843': { discard: 1, filter: { type: 'BASIC', name: '建设陆军' }, sbuild: 'army' },
	'17547': { sbuild: 'army' },
	'17550': { sbuild: 'navy' },
	'15248': { sbuild: 'army' },
	'15242': { discard: 1, filter: { type: 'BASIC', name: '发起陆战' } },
	/* 战斗状态卡：服务端已正确读 ctx.arg（含 space/from/victim），仅需客户端补选目标流程 */
	/*
	 * 【2026-10-23】17544 美国海军陆战队：卡面"对【相邻地区】发起1次陆战"，
	 * 相邻 = 建设海军那个海域的相邻【陆地】。
	 * 必须 spaces_from_window：候选由服务端 status_battle_spaces 按窗口地区动态算
	 * （内建地形过滤，kind='land' 只留陆地）。原先三个字段都没有 → 客户端不设高亮、
	 * 玩家可点任意地区，点了才被服务端"只能对相邻地区"拒掉。
	 */
	'17544': { battle: 'land', attacker_owner: true, spaces_from_window: true },
	/*
	 * 【2026-10-15】15247 贵在行动：对【建设地点的相邻地区】发起陆战。
	 * 与同形卡 17544 同款走 battle 流程（选地区 -> 选发起单位 -> 选目标）。
	 * spaces_from_window：候选 = 触发窗口地区（建设地点）的相邻地区，
	 *   由服务端 query status_battle_spaces 动态计算 —— 不能写死地区名，
	 *   且候选【含空地】以支持空打（空打用以触发闪电战等后续窗口）。
	 */
	'15247': { battle: 'land', attacker_owner: true, spaces_from_window: true },
	/*
	 * 【2026-10-29 修复】17746 耀武：跳过出牌阶段行动 + 损耗2张牌 -> 发起1次陆战。
	 *
	 * 漏登记的后果（玩家截图：「《耀武》请先选择发起战斗的单位与地区（未支付代价）」）：
	 *   status_ui_of('17746#1') 拿到 {} -> 点击【发动】落到下面的"通用确认框"，
	 *   只发 activate_status{card}、不带 from；而服务端 2026-10-28 新增的
	 *   battle 参数预检（rules.js:29867）在付代价前就拒绝 -> 玩家看到的就是"点了没反应"。
	 * 卡面没有限定地区，故不配 spaces / spaces_from_window：
	 * 玩家先在地图点任意地区（status_start_battle_space），再选发起单位，最后带 space+from 提交。
	 */
	'17746': { battle: 'land', attacker_owner: true },
	/* 17842 喀秋莎：弃1张手牌后对战斗地区再发起1次陆战 */
	'17842': { discard: 1, battle: 'land', attacker_owner: true },
	/* 17846 坦克运输：弃1张[建设陆军]或[发起陆战]后以此陆军发起1次陆战
	 * 【2026-10-20】卡面是"或"，filter.name 用【数组】表达；
	 * 与服务端的 STATUS_EFFECTS['17846'].cost.discard_is 保持一致（判定同源）。 */
	'17846': { discard: 1, filter: { type: 'BASIC', name: ['建设陆军', '发起陆战'] }, battle: 'land', attacker_owner: true },
	/* 17848 正面攻击：弃2张手牌后对战斗地区或相邻地区发起1次陆战 */
	'17848': { discard: 2, battle: 'land', attacker_owner: true },
	/* 15245 闪电战前奏类：候选含战斗地区本身（空打用），故 spaces_from_window + include_base */
	'15245': { battle: 'land', attacker_owner: true, spaces_from_window: true, include_base: true },
	/* 17841 近卫军：弃2张手牌，从弃牌堆打出1张[建设陆军]（弃牌后选地建设陆军） */
	'17841': { discard: 2, sbuild: 'army' },
	/* 17849 中国人民解放军：出牌阶段选<中国>/<蒙古>之一征召中国陆军（地图选地） */
	'17849': { recruit: 'army' },
	/* 17539 常设联合国防委员会：弃1张[建设陆军]，在加拿大征召英国陆军（纯弃牌） */
	'17539': { discard: 1, filter: { type: 'BASIC', name: '建设陆军' } },
	/*
	 * 【2026-10-23】15356 地中海基地：跳过出牌阶段 + 弃 2 张手牌
	 * -> 在<地中海>建设海军。
	 * 建设地区由服务端 effect.space 写死，客户端无需选地，故不配 sbuild；
	 * 弃牌走通用 status_discard 框（无 filter = 任意手牌）。
	 */
	'15356': { discard: 2 },
}

/*
 * 【2026-09-28 R40】STATUS_UI 用【基础 id】（'15341'）做 key，
 * 但运行时拿到的是【实例 id】（'15341#3'）——直接查会 undefined，
 * 于是 ui.build / ui.auto / ui.discard 全丢失，表现为：
 *   · 渲染：该卡被当成普通卡 -> ready=false -> 灰显（ts-disabled）
 *   · 点击：buildingNow 为 false -> 被 !c.ready 拦掉（"此时机尚不能触发"）
 * 与服务端 R28（card_id === '15228' 匹配不上 '15228#3'）是【同一类坑】：
 * 实例 id 永远不等于基础 id，凡是按 id 查表的地方都要先去后缀。
 */
function status_ui_of(id) {
	return STATUS_UI[id] || STATUS_UI[String(id == null ? '' : id).split('#')[0]] || {}
}

/*
 * 借用状态卡（意大利借德国卡，17732）的"发起 / 归属国"修正。
 * 该卡仍挂在【德国桌面】，view.table_status 里它的 .nation 是桌面 owner（德国）；
 * 但借用生效后实际发动方是借用方（意大利）。战斗发起单位高亮、候选地区查询、
 * 建设归属都要用借用方，否则会高亮德国部队却打不成、或把陆军建到德国地盘。
 * 返回桌面 owner（默认）或借用方（命中 italy_borrow 时）。
 */
function status_effective_nation(cardId, desktopNation) {
	const ib = view && view.italy_borrow
	if (ib && ib.card_face === cardId && ib.nation)
		return ib.nation
	return desktopNation
}

/* 状态卡激活的临时状态 */
let status_discard_sel = null  /* { cardId, ui, need, picked:[] } */
let status_act_card = null
let status_act_discard = null
let status_act_ui = null
let status_act_owner = null   /* 桌面 owner 国（15338/15339 作为战斗发起方） */
let status_act_phase = null    /* 'space' | 'battle' */
let status_build_pending = false   /* 状态卡"建设预算"：等待玩家点选相邻空格 */
let status_build_cands = []          /* 合法候选空格 id 列表 */
let status_build_type = null         /* 'army' | 'navy' */
let status_build_discard = null      /* 进入选地前已收集的弃牌代价（如 17843 弃[建设陆军]） */
/* 【2026-10-15】状态卡战斗选地（15247 贵在行动）：服务端给的候选地区（含空地，可空打） */
let status_battle_cands = []

function status_name(id) {
	const e = (view.table_status || []).find(x => x.card === id)
	return e ? e.name : ('状态卡' + id)
}

function space_id_of_name(nm) {
	const sp = (view.spaces || {})
	/* view.spaces 是数组(data.spaces 原样下发)，for...in 返回数组索引而非地区 id，
	 * 必须改用元素自身的 id 字段；对象形式({id:{name}})则仍返回 key。 */
	if (Array.isArray(sp)) {
		const e = sp.find(x => (x && (x.name || '')) === nm)
		return e ? (e.id != null ? e.id : null) : null
	}
	for (const k in sp)
		if ((sp[k].name || '') === nm) return k
	return null
}

function status_ready_space(id) {
	const e = (view.table_status || []).find(x => x.card === id)
	if (e && e.ready_space != null) return e.ready_space
	if (view.last_battle && view.last_battle.space != null) return view.last_battle.space
	return null
}

function on_click_table_status(cardId) {
	const c = (view.table_status || []).find(x => x.card === cardId)
	if (!c) return
	/* 【2026-10-18】喷气式战斗机(15251)：点击仅只读查看德国损耗记录，
	 * 绝不触发其 react/技能/增强/事件响应，也不产生任何游戏状态变更。 */
	if (c.attrition_log) { showAttrLogBox(c.attrition_log); return }
	/* 同上：cardId 是实例 id，必须经 status_ui_of 去后缀再查 */
	const ui = status_ui_of(cardId)
	/* 自动结算卡（15340 计分阶段 / 17749 战斗时）：不可主动触发，点击提示 */
	if (ui.auto) {
		toast('《' + c.name + '》是自动结算卡，' +
			(ui.autoDesc || '满足条件时自动生效') + '，无需点击')
		return
	}
	/* 持续效果（光环/地图改动）卡：无需点击 */
	if (c.ongoing && !c.trigger) {
		toast('《' + c.name + '》是持续效果卡，无需点击')
		return
	}
	/*
	 * 【2026-09-28】"替换建设"（15341/15342）必须【先于】ready 检查放行。
	 *
	 * 原因：build_army 是【事件驱动】窗口（"正在建设陆军"），
	 * 服务端无法感知客户端"正在选地块"，所以 view.table_status.ready
	 * 对这类卡【恒为 false】（这是刻意的：保证其余时间 UI 不显示可点）。
	 * 若在这里按 !c.ready 拦掉，玩家就永远走不到下面的 ui.build 分支。
	 *
	 * 因此：只要处于"选地块中且打的是《建设陆军》"，就放行，
	 * 由下面 ui.build 分支带 from_status:true 提交（服务端据此跳过窗口判定）。
	 */
	/*
	 * 【2026-10-25 修复】与 update_table_status 的显示判定同源：
	 * 必须再判"这张卡归属国 == 当前行动国"，否则苏联/美国建设陆军时
	 * 点击英国桌面的 15341/15342 会走到下面 ui.build 分支，
	 * 弹出"放弃建设并征召"确认框，提交后却被服务端拒绝（点了白点）。
	 */
	const _ownerNation = c.nation ||
		((view.table_status || []).find(t => t.card === cardId) || {}).nation || ''
	const _forgoOk = (c.forgo_build !== undefined && c.forgo_build !== null)
		? (c.forgo_build === true)
		: (_ownerNation === view.current_nation)
	const buildingNow = !!(ui.build && pending_card && pending_card.name === '建设陆军') &&
		_forgoOk
	if (!c.ready && !buildingNow) {
		toast('《' + c.name + '》此时机尚不能触发：' + (c.ready_reason || ''))
		return
	}
	if (c.once_per_turn && c.used_this_turn) {
		toast('《' + c.name + '》本回合已触发过')
		return
	}
	/* S4：建设陆军窗口下点击 -> 放弃正在进行的建设，改为征召。
	 * 设计 §3.3：打《建设陆军》卡进入选地块时，可改点状态卡放弃建设。
	 * 因此必须正在打《建设陆军》（pending_card 即该卡）才能触发；
	 * 确认时取消原建设选择（cancel_basic_card，并不真正建设），
	 * 服务端 cost.forgo_build_army 仅记录、effect 在指定地区 recruit。 */
	if (ui.build) {
		const building = !!(pending_card && pending_card.name === '建设陆军')
		if (!building) {
			toast('请先打出一张《建设陆军》卡并进入选地块，再点击此状态卡放弃建设')
			return
		}
		const where = ui.recruit || '指定地区'
		render_ask_box(
			'放弃建设陆军',
			'正在建设《' + pending_card.name + '》，放弃该建设，改为在' +
				where + '征召 1 支陆军？',
			[
				{ label: '放弃建设并征召', cls: 'primary', onClick: () => {
					const cid = cardId
					/*
					 * 【2026-09-28】先把正在打出的《建设陆军》实例 id 存下来。
					 * 必须在 cancel_basic_card()【之前】取，否则 pending_card 已被清空。
					 * 服务端凭它把这张建设卡【真正打出】（进弃牌堆）——
					 * 否则玩家既征召了陆军，建设卡又退回手牌，等于白嫖。
					 */
					const buildCardId = pending_card ? pending_card.id : null
					cancel_basic_card()      /* 放弃原建设选择（不真正建设） */
					render_ask_box(null)
					/*
					 * 【关键】必须带 from_status:true：
					 * 服务端的 build_army 窗口默认关闭（它是事件驱动窗口），
					 * 只有 from_status 才会跳过窗口判定放行替换建设，
					 * 并且不额外占出牌名额、不受阶段限制。
					 */
					/*
					 * build_card：被放弃的那张《建设陆军》，服务端据此将其打出。
					 */
					send_action('activate_status', {
						card: cid, from_status: true, build_card: buildCardId,
					})
					toast('发动《' + status_name(cid) + '》（放弃建设，《建设陆军》已打出）')
				} },
				{ label: '取消', onClick: () => cancel_status_act() },
			])
		return
	}
	/*
	 * 需弃牌代价：先进入手牌弃置选择（弃牌后可链式进入 battle / sbuild）。
	 *
	 * 【2026-10-23】张数取 `ui.discard || c.cost_discard`：以服务端下发的
	 * `c.cost_discard` 兜底。STATUS_UI 是手写表，漏登记过的卡（15356 地中海基地）
	 * 会退化成下面的"通用确认框"——点确认不带 discard，服务端拒绝、
	 * 客户端又没有任何提示，表现就是【弹窗后点了没反应】。
	 */
	const discNeed = ui.discard || c.cost_discard || 0
	if (discNeed) {
		start_status_discard(cardId, ui, discNeed)
		return
	}
	/* 建设预算：玩家手动点选相邻空格（不自动兜底） */
	if (ui.sbuild) {
		start_status_build(cardId, ui)
		return
	}
	/* 征召预算：玩家手动点选<中国>/<蒙古>之一（17849 中国人民解放军） */
	if (ui.recruit) {
		start_status_recruit(cardId, ui)
		return
	}
	/* 需选战斗目标：进入地图两步流程 */
	if (ui.battle) {
		start_status_battle(cardId, ui, null)
		return
	}
	/* 其余（15345/15347/15348 等）：弹代价确认框后提交。
	 * 15348 额外显示可执行次数（B2：N = 指定地区英国陆军数）。 */
	const extra = status_confirm_extra(ui)
	render_ask_box(
		'发动状态卡',
		'确认发动《' + c.name + '》？' + (extra ? '\n' + extra : ''),
		[
			{ label: '确认发动', cls: 'primary', onClick: () => {
				send_action('activate_status', { card: cardId })
				toast('发动《' + c.name + '》')
				render_ask_box(null)
			} },
			{ label: '取消', onClick: () => cancel_status_act() },
		])
}

/* ---------- 状态卡"建设预算"：玩家手动点选相邻合法空格 ---------- */
function start_status_build(cardId, ui, preDiscard) {
	const owner = status_effective_nation(cardId,
		((view.table_status || []).find(t => t.card === cardId) || {}).nation || '')
	const type = ui.sbuild // 'army' | 'navy'
	status_act_card = cardId
	status_act_ui = ui
	status_act_owner = owner
	status_build_type = type
	status_build_discard = preDiscard || null
	status_build_pending = true
	status_build_cands = []
	status_act_phase = 'space'
	/* 【2026-10-30】进入状态卡选地：先清掉战区移动的高亮/候选缓存，避免两套高亮叠在一起 */
	clear_target_highlight()
	theater_query_sig = null
	send_query('status_build_spaces', { card: cardId, nation: owner, type: type })
	render_ask_box('建设地区',
		'请点击地图上的高亮地区，建设' + (type === 'navy' ? '海军' : '陆军') +
		'（每格每国限 1 支，已满地区不可选）',
		[{ label: '取消', onClick: () => cancel_status_act() }])
}

/* 17849 中国人民解放军：出牌阶段选<中国>/<蒙古>之一征召中国陆军。
 * 复用 start_status_build 的地图选地 + on_click_space 的 status_build 发送分支
 * （status_act_phase='space' 且 status_build_pending 时 send_action activate_status {card,space}），
 * 仅候选固定为中国/蒙古、文案改为"征召"。run 收到 space 后服务端走征召路径。 */
function start_status_recruit(cardId, ui) {
	const owner = status_effective_nation(cardId,
		((view.table_status || []).find(t => t.card === cardId) || {}).nation || '')
	status_act_card = cardId
	status_act_ui = ui
	status_act_owner = owner
	status_act_phase = 'space'
	status_build_pending = true
	status_build_type = ui.recruit || 'army'
	status_build_discard = null
	/* 卡面<中国> = 中国西部/东北/东部(REGION_GROUPS['中国'])，<蒙古>单列；与服务端校验同源，且候选须为数字 id */
	const chinaRegion = ['中国西部', '中国东北', '中国东部']
	status_build_cands = chinaRegion.map(space_id_of_name)
		.concat([space_id_of_name('蒙古')]).filter(x => x != null).map(Number)
	highlight_targets({ spaces: status_build_cands.map(id => ({ id: id })) })
	render_ask_box('征召地区',
		'请点击地图上的高亮地区（中国/蒙古）征召1支中国陆军',
		[{ label: '取消', onClick: () => cancel_status_act() }])
}

/* 15348 等带 count_by 的卡：计算并显示可执行次数 */
function status_confirm_extra(ui) {
	if (!ui || !ui.count_by) return ''
	const sps = (ui.count_by.spaces || []).map(space_id_of_name).filter(x => x != null)
	const n = (view.pieces || []).filter(p =>
		p.nation === ui.count_by.nation &&
		(p.type || 'army') === (ui.count_by.type || 'army') &&
		sps.indexOf(p.loc) >= 0).length
	return '最多可执行 ' + n + ' 次（每次失去 1 分摸 1 张牌），本点击将执行 1 次'
}

/* ---------- 弃牌代价选择 ---------- */
function start_status_discard(cardId, ui, need) {
	status_discard_sel = { cardId: cardId, ui: ui, need: need, picked: [] }
	render_status_discard_box()
	update_hand_panel()
	toast('请选择 ' + need + ' 张手牌作为《' + status_name(cardId) + '》的代价')
}

/*
 * 弃牌选择 UI【改成弹框】（2026-09-28 玩家要求：参考资源再分配的 UI）。
 *
 * 之前是 render_ask_box 的文字框 + 让玩家去点【下方手牌区】选牌，
 * 视觉上没有缩略图、也没有"选了第几张"的直观反馈。
 * 现在复用 echo_discard_modal（与资源再分配同款的 modal + card-grid），
 * 在弹框内直接点卡图切换选中，选满后【确认弃牌】才发送。
 */
/*
 * 客户端镜像 card_matches_filter：状态卡弃牌代价按 filter 限定可选卡（15242 只能选【发起陆战】）。
 *
 * 【2026-10-20】name 支持【数组】= "或" 关系（17846 坦克运输：弃 1 张[建设陆军]或[发起陆战]）。
 * ⚠ 这是服务端 card_matches_filter 的镜像，两侧必须同步（判定同源）：
 *   只改服务端会出现"服务端接受[发起陆战]、但客户端候选里根本看不到它"。
 */
function card_match_filter_client(c, req) {
	if (!c || !req) return false
	if (req.type && c.type && String(c.type).toUpperCase() !== String(req.type).toUpperCase()) return false
	if (req.name) {
		const names = Array.isArray(req.name) ? req.name : [req.name]
		if (names.indexOf(c.name) < 0) return false
	}
	return true
}

function render_status_discard_box() {
	const modal = document.getElementById("echo_discard_modal")
	if (!modal) {
		/* 兜底：找不到弹框就退回文字框 */
		const s = status_discard_sel
		if (!s) { render_ask_box(null); return }
		const left = s.need - s.picked.length
		const btns = []
		if (left <= 0)
			btns.push({
				label: '确认弃置（' + s.need + ' 张）', cls: 'primary',
				onClick: () => finish_status_discard(),
			})
		btns.push({ label: '取消', onClick: () => cancel_status_act() })
		render_ask_box('触发状态卡：弃置手牌',
			'《' + status_name(s.cardId) + '》需弃置 ' + s.need + ' 张手牌（还需 ' +
			Math.max(0, left) + ' 张）', btns)
		return
	}

	const s = status_discard_sel
	if (!s) {
		/*
		 * 弹框可能被 ECHO/EVENT 流程共用：
		 * 只有【自己】开着的时候才关，避免把别人（pending_echo_discard）的框关掉。
		 */
		if (!pending_echo_discard) modal.classList.add("hide")
		update_hand_panel()
		return
	}
	modal.classList.remove("hide")

	/* 标题 / 计数 */
	const title = document.getElementById("echo_discard_title")
	if (title)
		title.textContent = "《" + status_name(s.cardId) + "》：选 " + s.need + " 张手牌作为代价"
	const note = document.getElementById("echo_discard_note")
	if (note) note.textContent = s.picked.length + "/" + s.need

	/* 手牌网格（点选切换） */
	const grid = document.getElementById("echo_discard_grid")
	if (grid) {
		grid.innerHTML = ""
		const hand = (view.hands[view.my_nation] && view.hands[view.my_nation].cards) || []
		const filt = s.ui && s.ui.filter
		let shown = 0
		for (const c of hand) {
			if (filt && !card_match_filter_client(c, filt)) continue
			shown++
			const picked = s.picked.indexOf(c.id) >= 0
			const d = card_elt(c, () => on_status_discard_pick(c.id))
			d.classList.toggle("sel", picked)
			if (picked) {
				const b = document.createElement("span")
				b.className = "badge"
				b.textContent = "代价 " + (s.picked.indexOf(c.id) + 1)
				d.appendChild(b)
			}
			grid.appendChild(d)
		}
		if (!shown) {
			const p = document.createElement("div")
			p.className = "empty-note"
			/* 【2026-10-20】filter.name 可能是数组（"或"），须展开为"建设陆军或发起陆战" */
			const nmTxt = (filt && filt.name)
				? (Array.isArray(filt.name) ? filt.name.join('或') : filt.name)
				: ''
			p.textContent = nmTxt
				? '手牌中未找到【' + nmTxt + '】作为代价'
				: "手牌为空，无法支付代价"
			grid.appendChild(p)
		}
	}

	/* 确认按钮：选满才可用 */
	const ok = document.getElementById("echo_discard_confirm")
	if (ok) ok.disabled = (s.picked.length !== s.need)
	/* 关掉文字询问框，避免两个框同时出现 */
	render_ask_box(null)
	update_hand_panel()
}

function on_status_discard_pick(cardId) {
	const s = status_discard_sel
	if (!s) return false
	if (s.ui && s.ui.filter) {
		const c = ((view.hands[view.my_nation] && view.hands[view.my_nation].cards) || [])
			.find(h => h.id === cardId)
		if (!card_match_filter_client(c, s.ui.filter)) {
			/* 【2026-10-20】同上：filter.name 可能是数组 */
			const nm = s.ui.filter.name
			const nmTxt = Array.isArray(nm) ? nm.join('或') : (nm || '指定')
			toast('只能选择【' + nmTxt + '】作为代价')
			return false
		}
	}
	const i = s.picked.indexOf(cardId)
	if (i >= 0)
		s.picked.splice(i, 1)
	else if (s.picked.length < s.need)
		s.picked.push(cardId)
	else {
		toast('已选满 ' + s.need + ' 张')
		return true
	}
	render_status_discard_box()
	return true
}

function finish_status_discard() {
	const s = status_discard_sel
	status_discard_sel = null
	/*
	 * 【2026-10-16 修复】弃牌框使命完成，立即关掉共用 modal。
	 * 之前只靠 update_echo_discard_box()（随 view 刷新才跑）隐藏，而
	 * "弃牌 -> 选战斗地区/建设地区"是纯本地转移、没有服务端往返，
	 * modal 会一直残留：挡住地图点击，且再点【确认弃牌】时两个状态
	 * 都已为 null -> confirm_echo_discard 静默 return（点了没反应、卡死）。
	 */
	update_echo_discard_box()
	if (!s) return
	const ui = s.ui
	const picked = s.picked.slice()
	update_hand_panel()
	render_ask_box(null)
	if (ui.battle)
		start_status_battle(s.cardId, ui, picked)
	else if (ui.sbuild)
		start_status_build(s.cardId, ui, picked)
	else
		send_action('activate_status', { card: s.cardId, discard: picked })
}

/* ---------- 战斗目标选择（复用 battle_flow） ---------- */
function start_status_battle(cardId, ui, discard) {
	status_act_card = cardId
	status_act_discard = discard || null
	status_act_ui = ui
	/* 桌面 owner 国：15338/15339 由它作为战斗发起方（英国），
	 * 15346 由 tr.nation='法国' 固定发起。 */
	status_act_owner = status_effective_nation(cardId,
		((view.table_status || []).find(t => t.card === cardId) || {}).nation || '')
	const name = status_name(cardId)
	if (ui.fixed) {
		const sp = status_ready_space(cardId)
		if (sp == null) {
			toast('未找到战斗地区（需本回合本方已发起战斗）')
			cancel_status_act()
			return
		}
		status_start_battle_space(sp)
		return
	}
	status_act_phase = 'space'
	/*
	 * 【2026-10-15】候选由服务端按"触发窗口地区"【动态】计算（15247 贵在行动）。
	 * 与 sbuild（start_status_build）同款：先发 query，on_reply 里高亮；
	 * 提示框立刻渲染，避免出现"点了没反应"的空窗感。
	 */
	if (ui.spaces_from_window) {
		status_battle_cands = []
		send_query('status_battle_spaces', {
			card: cardId, nation: status_act_owner, kind: ui.battle || 'land',
			include_base: !!ui.include_base,
		})
		render_ask_box(
			'选择战斗地区',
			'请点击地图上的高亮地区（建设地点的相邻地区）发起《' + name + '》的陆战。' +
			'若无守军则为空打：不移除任何单位、仅消耗，可用于触发闪电战等后续效果。',
			[{ label: '取消', onClick: () => cancel_status_act() }])
		toast('点击地图上高亮的相邻地区以发起《' + name + '》的陆战')
		return
	}
	const spaces = (ui.spaces || []).map(space_id_of_name).filter(x => x != null)
	if (spaces.length)
		highlight_targets({
			spaces: spaces.map(id => ({ id: id, reason: '可发起战斗的地区' })),
			pieces: [],
		})
	render_ask_box(
		'选择战斗地区',
		'请点击地图上的目标地区发起《' + name + '》的战斗' +
			(spaces.length ? '（仅 ' +
				spaces.map(id => (view.spaces[id] || {}).name || id).join('、') + '）' : ''),
		[{ label: '取消', onClick: () => cancel_status_act() }])
	toast('点击地图上的目标地区以发起《' + name + '》的战斗')
}

function status_start_battle_space(space_id) {
	status_act_phase = 'battle'
	render_ask_box(null)
	clear_target_highlight()
	battle_flow = {
		step: 'from', space: space_id, from: null, isEmpty: false,
		preVictim: null, victim: null, origin: 'status',
	}
	/* 目标地区的敌方算子（供点击选择攻击目标）。
	 * 与 basic_targets 一样填进 pending_targets.pieces，
	 * on_pick_battle_target 据此判定玩家点的是不是合法目标。
	 *
	 * 发起方（attacker）：
	 *   · ui.attacker 固定值（15346 = 法国）
	 *   · 否则若 attacker_owner，取桌面 owner 国（15338/15339 = 英国）
	 *   · 兜底法国 */
	const attacker = (status_act_ui && status_act_ui.attacker) ||
		((status_act_ui && status_act_ui.attacker_owner) ? status_act_owner : '法国')
	const enemyPieces = (view.pieces || []).filter(p =>
		p.loc === space_id && p.nation !== attacker)
	pending_targets = {
		spaces: [{ id: space_id }],
		pieces: enemyPieces.map(p => ({
			id: p.id,
			space: p.loc,
			space_name: (view.spaces[p.loc] || {}).name || p.loc,
			name: ((view.pieces_by_id || {})[p.id] || {}).type_zh || p.type,
		})),
	}
	send_query('battle_initiators', { space: space_id, nation: attacker })
}

function cancel_status_act() {
	status_discard_sel = null
	status_act_card = null
	status_act_discard = null
	status_act_ui = null
	status_act_owner = null
	status_act_phase = null
	status_build_pending = false
	status_build_cands = []
	status_build_type = null
	status_battle_cands = []
	battle_flow = null
	clear_piece_highlight('initiator')
	clear_target_highlight()
	render_ask_box(null)
	update_hand_panel()
	/*
	 * 【2026-10-30】取消状态卡后，若《战区移动》仍在进行，让它重算候选并恢复面板
	 * （期间地图可能已变，旧候选缓存不可再用）。
	 */
	after_status_space_done()
}

/*
 * 【2026-09-30 重构·战斗预算(event_budget)】独立于 #ask_box 的持久面板：
 * 展示剩余机会数、可攻击目标（地图高亮）、战斗日志，并提供"结束"按钮。
 * 期间地图/手牌照常可用，玩家可先点桌面已武装的「闪电战 / 15245 / 状态卡 /
 * 免死响应 / 飞机代受」等，再点目标发起下一场或点"结束"结算。
 */
/* ============================================================
 * 【2026-10-04】响应卡效果"需要玩家选择"的统一 UI
 *
 * 服务端在 view.response_choice 下发窗口（kind + candidates），
 * 本函数按 kind 分派到【已有】的交互组件，不另造一套：
 *   · space  -> highlight_targets（地区高亮，玩家点地图）
 *   · piece  -> highlight_targets（算子高亮，玩家点算子）
 *   · card   -> render_ask_box（弃牌堆里挑 1 张牌）
 *   · option -> render_ask_box（四选一等选项）
 *
 * ⚠ 高亮/候选一律用服务端下发的数据，客户端【不二次过滤】，
 *   否则又会漂移出"看得见点不中"（见 rtt-client-server-contract 第四节）。
 * ============================================================ */
function update_response_choice_box() {
	const rc = view && view.response_choice
	if (!rc) {
		/* 窗口没了：若本框还占着 ask_box 就清掉 */
		if (ask_state && ask_state.kind === 'response_choice') {
			ask_state = null
			render_ask_box(null, null, null)
		}
		return
	}

	const mkBtn = (label, cls, fn) => ({ label, cls, onClick: fn })
	const submit = (choice) => {
		ask_state = null
		render_ask_box(null, null, null)
		send_action('resolve_response_choice', { choice })
		toast('《' + rc.name + '》已结算')
	}

	if (rc.kind === 'space') {
		/* 复用事件卡的高亮：格式必须是 [{id, reason}] */
		const cands = (rc.candidates || []).map(c => ({ id: c.id, reason: c.name || '' }))
		if (!cands.length) {
			toast('《' + rc.name + '》当前没有合法目标')
			return
		}
		highlight_targets({ spaces: cands, pieces: [] })
		return
	}

	if (rc.kind === 'piece') {
		const cands = (rc.candidates || []).map(c => ({ id: c.id, reason: c.name || '' }))
		if (!cands.length) {
			toast('《' + rc.name + '》当前没有合法目标部队')
			return
		}
		highlight_targets({ spaces: [], pieces: cands })
		return
	}

	/* card / option：弹选项框（响应卡在队列里，优先级高，直接占用 ask_box） */
	ask_state = { kind: 'response_choice' }
	render_ask_box(
		'《' + rc.name + '》：选择',
		rc.prompt || '请选择一项',
		(rc.candidates || []).map(c => mkBtn(c.name || String(c.id), 'primary', () => submit(c.id)))
	)
}

function update_event_budget_box() {
	const eb = view && view.event_budget
	const box = document.getElementById('event_budget_box')
	if (!box) return
	if (!eb) {
		box.classList.add('hide')
		box.innerHTML = ''
		return
	}
	box.classList.remove('hide')
	const nm = eb.card_name || '事件'
	const against = eb.against ? ('对' + eb.against) : '对敌'
	const kindTxt = eb.kind === 'sea' ? '海战' : '陆战'
	box.innerHTML = ''

	const title = document.createElement('div')
	title.className = 'eb-title'
	title.textContent = '《' + nm + '》战斗预算：剩 ' + eb.remaining + ' 次' + against + kindTxt + '机会'
	box.appendChild(title)

	const hint = document.createElement('div')
	hint.className = 'eb-hint'
	hint.textContent = eb.remaining > 0
		? '点地图上高亮的' + against + '陆地发起战斗；结算后可插入状态/免死/飞机代受等；或点「结束」放弃剩余。'
		: '战斗机会已用尽，点「结束》结算（含德国国家技能）。'
	box.appendChild(hint)

	const btn = document.createElement('button')
	btn.className = 'action primary'
	btn.textContent = '结束《' + nm + '》'
	btn.onclick = () => send_action('event_finish', {})
	box.appendChild(btn)

	if (eb.descs && eb.descs.length) {
		const log = document.createElement('div')
		log.className = 'eb-log'
		log.textContent = eb.descs.join('；')
		box.appendChild(log)
	}

	/* 高亮可攻击目标（地图点选由 on_click_space 处理） */
	if (eb.can_finish && eb.targets && eb.targets.length) {
		highlight_targets({ spaces: eb.targets.map(id => ({ id: id })) })
	}
}

/* ============================================================
 * 【2026-10-21 方案 B】事件卡分步执行机的"步骤边界"面板。
 *
 * 服务端把多步事件卡按"一个原子动作一停"推进（docs/event-step-machine.md）：
 * 每执行完 remove/build/recruit 就停在这里，让玩家在两步之间插入
 * 状态卡 / 增强卡 / 响应窗口，处理完再点「下一步」。
 *
 * 文案与可点性【全部由服务端算好下发】（view.pending_event_step）：
 *   next_label 下一步动作文案、desc 已完成步骤、blockers 未清窗口原因、can_next 是否可推进。
 * 客户端只负责显示与派发 event_step_next，不二次判断（pitfalls 通用教训 3）。
 * ============================================================ */
function update_event_step_box() {
	const ps = view && view.pending_event_step
	const box = document.getElementById('event_step_box')
	if (!box) return
	if (!ps) {
		box.classList.add('hide')
		box.innerHTML = ''
		return
	}
	box.classList.remove('hide')
	box.innerHTML = ''

	/* 结构与 #event_budget_box 保持一致：title -> hint -> log -> button */
	const title = document.createElement('div')
	title.className = 'eb-title'
	title.textContent = '《' + (ps.card_name || '事件') + '》第 ' +
		(ps.step + 1) + '/' + ps.total + ' 步'
	box.appendChild(title)

	const hint = document.createElement('div')
	hint.className = 'eb-hint'
	if (ps.can_next) {
		/*
		 * 有可发动的窗口时明确告知"也可以直接下一步放弃"——
		 * 旧实现把状态卡窗口当成硬阻塞，玩家不想发动就永远卡住
		 * （代价付不起时尤其致命：窗口已武装但 activate_status 会失败）。
		 */
		hint.textContent = ps.offers && ps.offers.length
			? ('下一步：' + (ps.next_label || '继续') +
				'（有可发动的' + ps.offers.join('、') + '；不发动就直接点「下一步」）')
			: ('下一步：' + (ps.next_label || '继续') +
				'（可先发动状态卡/响应卡，再点「下一步」）')
	} else {
		/* 硬阻塞（响应卡/战斗/经济战）：必须处理完才能推进 */
		hint.textContent = '请先处理当前的' + (ps.blockers || []).join('、') +
			'，再点「下一步」'
	}
	box.appendChild(hint)

	const btn = document.createElement('button')
	btn.className = 'action primary'
	btn.textContent = '下一步'
	btn.disabled = !ps.can_next
	btn.onclick = () => {
		if (!ps.can_next) {
			toast('请先处理当前的' + (ps.blockers || []).join('、'))
			return
		}
		send_action('event_step_next', {})
	}
	box.appendChild(btn)

	/* 已完成的步骤（服务端拼好的描述）—— 与 #event_budget_box 的 descs 同在按钮之后 */
	if (ps.desc) {
		const done = document.createElement('div')
		done.className = 'eb-log'
		done.textContent = '已完成：' + ps.desc
		box.appendChild(done)
	}
}

/* ============================================================
 * 【2026-10-18】17851 天王星行动：重复选择菜单（发起陆战 / 建设陆军 / 结束）
 * 复用 #event_budget_box 同款样式；战斗分支交给通用 event_budget 面板。
 * ============================================================ */
function update_uranus_box() {
	const pu = view && view.pending_uranus
	const box = document.getElementById('uranus_box')
	if (!box) return
	if (!pu) {
		box.classList.add('hide')
		box.innerHTML = ''
		/* 仅在无战斗预算时才清高亮，避免抹掉战斗分支的目标高亮 */
		if (!(view && view.event_budget)) clear_target_highlight()
		return
	}
	box.classList.remove('hide')
	box.innerHTML = ''
	const sn = pu.space_name || '乌克兰'

	const title = document.createElement('div')
	title.className = 'eb-title'
	title.textContent = '《天王星行动》：剩 ' + pu.remaining + ' / ' + (pu.total || pu.remaining) + ' 次'
	box.appendChild(title)

	const hint = document.createElement('div')
	hint.className = 'eb-hint'
	hint.textContent = '每次：对<' + sn + '>发起陆战，或在<' + sn + '>建设陆军；或结束放弃剩余。'
	box.appendChild(hint)

	const row = document.createElement('div')
	row.className = 'eb-actions'

	const bB = document.createElement('button')
	bB.className = 'action primary'
	bB.textContent = '对<' + sn + '>发起陆战'
	bB.onclick = () => send_action('uranus_choice', { choice: 'battle' })
	row.appendChild(bB)

	const bU = document.createElement('button')
	bU.className = 'action'
	bU.textContent = '在<' + sn + '>建设陆军'
	bU.onclick = () => send_action('uranus_choice', { choice: 'build' })
	row.appendChild(bU)

	const bE = document.createElement('button')
	bE.className = 'action'
	bE.textContent = '结束'
	bE.onclick = () => send_action('uranus_choice', { choice: 'end' })
	row.appendChild(bE)

	box.appendChild(row)

	/* 高亮乌克兰（与战斗分支共用 .target） */
	const sp = pu.space
	if (sp) highlight_targets({ spaces: [{ id: sp }] })
}

/*
 * 【2026-10-13 重构为屏幕中央卡片网格范式】17817 进攻是最好的防守 + 17850 大清洗 联动面板。
 *
 * 背景：苏联打出 17817 后：先结束中立并（若有大清洗）给出一次性出牌机会，
 * 玩家处理完大清洗（或主动继续）后，才由 su_17817_proceed / su_purge_play 建立对德战斗预算。
 *
 * 渲染改为复用 #us_political_modal 的「屏幕中央卡片网格 + 点选高亮(.sel) + 底部确认」范式
 * （#su_purge_modal，与 #us_political_modal 同结构）：玩家在屏幕中间看到状态卡真实牌面并点选，
 * 而非旧版侧边小按钮列名字。
 *
 * 显示条件 = view.su_17817_pending 或 view.actions.su_purge_play 任一为真（已修复 view.acts→view.actions）。
 * 路径区分：
 *   · 走 17817：view.actions.su_17817_proceed 真 → 底部给「继续进攻（建立对德战斗预算）」(放弃大清洗)；
 *   · 被攻击 / 压力参战（无 17817 待结算）：view.actions.su_purge_skip 真 → 底部给「跳过（不发动大清洗）」。
 *   · 无论哪条路径，选 1 张[状态卡]后底部「确认打出」按钮置可点，send_action('su_purge_play', {card})。
 */
/* ============================================================
 * 【2026-10-25】15328《破译恩尼格码》延迟窗口（英国回合开始时）。
 *
 * 触发：德国在【计分阶段】凭[状态卡]自动得分（15241 / 15244 / 6601）后，
 *       服务端在切到英国回合时置 view.uk_enigma_offer。
 * 两段式：
 *   ① 未点「发动」：只给「发动」「放弃」两个按钮（view.uk_enigma_pick 为 null）；
 *   ② 点「发动」后：服务端回传候选（view.uk_enigma_pick.candidates = 那些德国状态卡），
 *      这里渲染卡片网格供点选，确认后 send_action('uk_enigma_play', { card })。
 * 仅英国阵营可见（服务端已按阵营过滤）。
 * ============================================================ */
let uk_enigma_sel = null
function update_uk_enigma_box() {
	const modal = document.getElementById('uk_enigma_modal')
	if (!modal) return
	const show = !!(view && view.uk_enigma_offer &&
		view.actions && view.actions.uk_enigma_play)
	if (!show) {
		modal.classList.add('hide')
		const _b = modal.querySelector('.modal-box')
		if (_b) _b.innerHTML = ''
		uk_enigma_sel = null
		return
	}
	modal.classList.remove('hide')
	const box = modal.querySelector('.modal-box')
	box.innerHTML = ''

	const head = document.createElement('div')
	head.className = 'modal-head'
	const title = document.createElement('span')
	title.className = 'modal-title'
	title.textContent = '破译恩尼格码'
	const sub = document.createElement('span')
	sub.className = 'modal-sub'
	sub.textContent = '德国刚在计分阶段凭[状态卡]自动得分，可弃置其中 1 张德国[状态卡]'
	head.append(title, sub)
	box.appendChild(head)

	const cands = (view.uk_enigma_pick && view.uk_enigma_pick.candidates) || []
	if (cands.length) {
		const sec = document.createElement('div')
		sec.className = 'modal-section'
		const label = document.createElement('div')
		label.className = 'modal-label'
		label.textContent = '选择要弃置的 1 张德国[状态卡]'
		const hint = document.createElement('span')
		hint.className = 'modal-hint'
		hint.textContent = uk_enigma_sel ? '已选 1 / 1，点确认弃置' : '点选 1 张状态卡'
		label.appendChild(hint)
		sec.appendChild(label)

		const grid = document.createElement('div')
		grid.className = 'card-grid'
		for (const c of cands) {
			const el = card_elt(c, () => {
				uk_enigma_sel = (uk_enigma_sel === c.id) ? null : c.id
				update_uk_enigma_box()
			})
			if (uk_enigma_sel === c.id) el.classList.add('sel')
			grid.appendChild(el)
		}
		sec.appendChild(grid)
		box.appendChild(sec)
	}

	const foot = document.createElement('div')
	foot.className = 'modal-foot'

	if (!cands.length) {
		/* ① 阶段：先问是否发动 */
		const go = document.createElement('button')
		go.className = 'action primary'
		go.textContent = '发动（选择要弃置的状态卡）'
		go.onclick = () => send_action('uk_enigma_play', {})
		foot.appendChild(go)
	} else {
		const ok = document.createElement('button')
		ok.className = 'action primary'
		const chosen = cands.find(c => c.id === uk_enigma_sel)
		ok.textContent = uk_enigma_sel && chosen
			? ('弃置《' + (chosen.name || chosen.id) + '》') : '确认弃置'
		ok.disabled = !uk_enigma_sel
		ok.onclick = () => {
			if (!uk_enigma_sel) return
			const card = uk_enigma_sel
			uk_enigma_sel = null
			send_action('uk_enigma_play', { card })
		}
		foot.appendChild(ok)
	}

	if (view.actions && view.actions.uk_enigma_skip) {
		const skip = document.createElement('button')
		skip.className = 'action'
		skip.textContent = '放弃（响应卡留于桌面）'
		skip.onclick = () => { uk_enigma_sel = null; send_action('uk_enigma_skip', {}) }
		foot.appendChild(skip)
	}
	box.appendChild(foot)
}

let su_purge_sel = null
function update_su_17817_box() {
	const modal = document.getElementById('su_purge_modal')
	if (!modal) return
	/*
	 * 【2026-10-31 修复】再加一道"本国"闸：即使服务端字段哪天又漏了阵营过滤，
	 * 也不会把《大清洗》选牌框弹到对手屏幕上（该框只属于苏联）。
	 */
	const show = view && view.my_nation === '苏联' &&
		(view.su_17817_pending || (view.actions && view.actions.su_purge_play))
	if (!show) { modal.classList.add('hide'); const _b = modal.querySelector('.modal-box'); if (_b) _b.innerHTML = ''; su_purge_sel = null; return }
	modal.classList.remove('hide')
	const box = modal.querySelector('.modal-box')
	box.innerHTML = ''

	const head = document.createElement('div')
	head.className = 'modal-head'
	const title = document.createElement('span')
	title.className = 'modal-title'
	title.textContent = view.su_17817_pending
		? '《进攻是最好的防守》已打出：苏联已结束中立'
		: '苏联结束中立：大清洗机会'
	const sub = document.createElement('span')
	sub.className = 'modal-sub'
	sub.textContent = '大清洗：弃置《大清洗》，打出 1 张[状态卡]'
	head.append(title, sub)
	box.appendChild(head)

	const sec = document.createElement('div')
	sec.className = 'modal-section'
	const label = document.createElement('div')
	label.className = 'modal-label'
	label.textContent = '选择 1 张[状态卡]'
	const hint = document.createElement('span')
	hint.className = 'modal-hint'
	hint.textContent = su_purge_sel ? '已选 1 / 1，点确认打出' : '点选 1 张状态卡'
	label.appendChild(hint)
	sec.appendChild(label)

	const hand = (view.hands[view.my_nation] && view.hands[view.my_nation].cards) || []
	const statusCards = hand.filter(c => String(c.type || '').toUpperCase() === 'STATUS')
	const grid = document.createElement('div')
	grid.className = 'card-grid'
	if (!statusCards.length) {
		const empty = document.createElement('p')
		empty.className = 'empty-note'
		empty.textContent = '手牌中无可用状态卡'
		grid.appendChild(empty)
	} else {
		for (const c of statusCards) {
			const el = card_elt(c, () => {
				su_purge_sel = (su_purge_sel === c.id) ? null : c.id
				update_su_17817_box()
			})
			if (su_purge_sel === c.id) el.classList.add('sel')
			grid.appendChild(el)
		}
	}
	sec.appendChild(grid)
	box.appendChild(sec)

	const foot = document.createElement('div')
	foot.className = 'modal-foot'
	/* 放弃出口：17817 路径用 proceed；被攻击/压力路径用 skip（互斥，build_actions 已保证） */
	if (view.actions && view.actions.su_17817_proceed) {
		const proceed = document.createElement('button')
		proceed.className = 'action'
		proceed.textContent = '继续进攻（建立对德战斗预算）'
		proceed.onclick = () => { su_purge_sel = null; send_action('su_17817_proceed', {}) }
		foot.appendChild(proceed)
	} else if (view.actions && view.actions.su_purge_skip) {
		const skip = document.createElement('button')
		skip.className = 'action'
		skip.textContent = '跳过（弃置《大清洗》）'
		skip.onclick = () => { su_purge_sel = null; send_action('su_purge_skip', {}) }
		foot.appendChild(skip)
	}
	const ok = document.createElement('button')
	ok.className = 'action primary'
	const chosen = statusCards.find(c => c.id === su_purge_sel)
	ok.textContent = su_purge_sel && chosen ? ('打出《' + (chosen.name || chosen.id) + '》') : '确认打出'
	ok.disabled = !su_purge_sel
	ok.onclick = () => {
		if (!su_purge_sel) return
		const card = su_purge_sel
		su_purge_sel = null
		send_action('su_purge_play', { card })
	}
	foot.appendChild(ok)
	box.appendChild(foot)
}

/* ============================================================
 * 【2026-10-18】17852 罗科索夫斯基 朱可夫 科涅夫：从手牌选 1~N 张[状态卡]一次性打出。
 * 复用 #su_purge_modal 同款「屏幕中央卡片网格 + 点选高亮(.sel) + 底部确认」范式，
 * 区别：多选（status_play_sel 数组，toggle），footer 显示「已选 k / N」。
 * 候选来自 view.hands[my_nation].cards 按 type==='STATUS' 过滤（与 update_su_17817_box 同源）。
 * ============================================================ */
let status_play_sel = []
function update_status_play_box() {
	const sp = view && view.pending_status_play
	const modal = document.getElementById('status_play_modal')
	if (!modal) return
	if (!sp) {
		modal.classList.add('hide')
		const _b = modal.querySelector('.modal-box'); if (_b) _b.innerHTML = ''
		status_play_sel = []
		return
	}
	modal.classList.remove('hide')
	const box = modal.querySelector('.modal-box')
	box.innerHTML = ''

	const head = document.createElement('div')
	head.className = 'modal-head'
	const title = document.createElement('span')
	title.className = 'modal-title'
	title.textContent = '《罗科索夫斯基 朱可夫 科涅夫》：打出状态卡'
	const sub = document.createElement('span')
	sub.className = 'modal-sub'
	sub.textContent = '可打出最多 ' + sp.total + ' 张[状态卡]，已选 ' + status_play_sel.length + ' / ' + sp.remaining
	head.append(title, sub)
	box.appendChild(head)

	const sec = document.createElement('div')
	sec.className = 'modal-section'
	const label = document.createElement('div')
	label.className = 'modal-label'
	label.textContent = '选择[状态卡]'
	const hint = document.createElement('span')
	hint.className = 'modal-hint'
	hint.textContent = status_play_sel.length ? ('已选 ' + status_play_sel.length + ' / ' + sp.remaining) : '点选手牌中的状态卡（可多选）'
	label.appendChild(hint)
	sec.appendChild(label)

	const hand = (view.hands[view.my_nation] && view.hands[view.my_nation].cards) || []
	const statusCards = hand.filter(c => String(c.type || '').toUpperCase() === 'STATUS')
	const grid = document.createElement('div')
	grid.className = 'card-grid'
	if (!statusCards.length) {
		const empty = document.createElement('p')
		empty.className = 'empty-note'
		empty.textContent = '手牌中无可用状态卡（可点「结束」放弃）'
		grid.appendChild(empty)
	} else {
		for (const c of statusCards) {
			const el = card_elt(c, () => {
				const i = status_play_sel.indexOf(c.id)
				if (i >= 0) status_play_sel.splice(i, 1)
				else if (status_play_sel.length < sp.remaining) status_play_sel.push(c.id)
				update_status_play_box()
			})
			if (status_play_sel.indexOf(c.id) >= 0) el.classList.add('sel')
			grid.appendChild(el)
		}
	}
	sec.appendChild(grid)
	box.appendChild(sec)

	const foot = document.createElement('div')
	foot.className = 'modal-foot'
	const ok = document.createElement('button')
	ok.className = 'action primary'
	const selNames = statusCards.filter(c => status_play_sel.indexOf(c.id) >= 0).map(c => c.name || c.id)
	ok.textContent = status_play_sel.length ? ('打出 ' + status_play_sel.length + ' 张状态卡' + (selNames.length ? '（《' + selNames.join('》《') + '》）' : '')) : '确认打出'
	ok.disabled = status_play_sel.length < 1 || status_play_sel.length > sp.remaining
	ok.onclick = () => {
		if (!status_play_sel.length) return
		const cards = status_play_sel.slice()
		status_play_sel = []
		send_action('su_status_play', { cards })
	}
	foot.appendChild(ok)
	const end = document.createElement('button')
	end.className = 'action'
	end.textContent = '结束（放弃剩余）'
	end.onclick = () => { status_play_sel = []; send_action('su_status_skip', {}) }
	foot.appendChild(end)
	box.appendChild(foot)
}

/*
 * 响应卡挂起：持有方在询问框里决定"发动 / 不发动"。
 * 只有 view.pending_trigger 非 null 的一方会看到（服务端已按阵营过滤）。
 */
let resp_ui = null, resp_ui_sig = null
function move_resp_order(i, d) {
	const j = i + d
	if (j < 0 || j >= resp_ui.order.length) return
	const t = resp_ui.order[i]; resp_ui.order[i] = resp_ui.order[j]; resp_ui.order[j] = t
}
function send_resp_reorder() {
	/*
	 * order = 结算先后；skip = 本次要移出本组的卡（「跳过」按钮）。
	 * 服务端把 skip 存成帧上的 f.skipped，确认顺序时这些帧直接移出本组，
	 * 后续逐张询问不会再到它们（卡仍留在桌面、不消耗）。
	 */
	send_action('response_reorder', {
		order: resp_ui.order.slice(),
		skip: Object.keys(resp_ui.skip || {}),
	})
}
function update_pending_trigger_box() {
	const pt = view.pending_trigger
	if (!pt) {
		resp_ui = null
		resp_ui_sig = null
		if (ask_state && (ask_state.kind === 'response' || ask_state.kind === 'response_order')) {
			ask_state = null
			render_ask_box(null, null, null)
		}
		return
	}
	/* 正在为该响应卡选目标：交给响应选择框，不显示发动/排序框 */
	if (view.response_choice) {
		if (ask_state && ask_state.kind === 'response') {
			ask_state = null
			render_ask_box(null, null, null)
		}
		return
	}
	const cands = pt.candidates || []
	const multi = cands.length > 1 && !pt.ordered
	if (!multi) {
		/*
		 * 单卡 / 已确认顺序：逐张询问"是否发动这一张"。
		 *
		 * 【2026-10-28 玩家口径】确认顺序后，服务端一次只执行一张，
		 * 所以这里必须只显示【当前这一张】（pt.current，服务端算好下发），
		 * 不能像旧版那样把整组名字拼成一句"是否发动《A》、《B》？"
		 * —— 那样点一次发动只结算一张，读起来完全对不上。
		 */
		const curId = pt.current || (pt.order && pt.order[0]) ||
			(cands[0] && cands[0].card_id)
		const cur = cands.find(c => c.card_id === curId) || cands[0]
		const names = '《' + (cur ? cur.name : '?') + '》'
		const rest = cands.length > 1
			? ('（本组共 ' + cands.length + ' 张，逐张询问）') : ''
		const where = pt.space ? ('（于 ' + (data.name_of(pt.space) || pt.space) + '）') : ''
		const kind = pt.pre ? '——可令对方该行动无效' : ''
		/*
		 * 【2026-10-31 玩家口径】拦截询问先亮出"被拦的是哪张卡"：
		 * 15329 拦经济战 / 17736 拦轰炸行动时，显示「被拦截：【德国】打出《电动潜艇》」，
		 * 拦截方不用靠记忆判断要不要用这张响应卡。
		 */
		const tgt = pt.target || null
		const tgtLine = tgt
			? ('被拦截：【' + (tgt.nation || '敌方') + '】' +
				(tgt.via === 'trigger' ? '触发' : '打出') + '《' + tgt.name + '》')
			: ''
		const tgtText = tgt && tgt.text ? String(tgt.text).replace(/\s+/g, ' ').slice(0, 90) : ''
		const title = '响应卡等待决定'
		const text = (tgtLine ? (tgtLine + '\n') : '') +
			(tgtText ? ('　' + tgtText + '\n') : '') +
			'是否发动 ' + names + '？' + where + kind + rest
		ask_state = { kind: 'response', pt: pt }
		render_ask_box(title, text, [
			{ label: '发动响应', cls: 'primary', onClick: () => send_action('trigger_response', {}) },
			{ label: '不发动', cls: '', onClick: () => send_action('pass_response', {}) },
		])
		return
	}
	/* 多卡未确认：排序 + 逐行「跳过/恢复」（跳过 = 本次移出本组，不再询问） */
	const sig = JSON.stringify(cands) + '|' + JSON.stringify(pt.order) + '|' + JSON.stringify(pt.skip)
	if (!resp_ui || resp_ui_sig !== sig) {
		resp_ui = {
			order: (pt.order || cands.map(c => c.card_id)).slice(),
			skip: Object.assign({}, pt.skip || {}),
		}
		resp_ui_sig = sig
	}
	ask_state = { kind: 'response_order' }
	const box = document.getElementById('ask_box')
	if (!box) return
	box.innerHTML = ''
	box.classList.remove('hide')
	const h = document.createElement('div'); h.className = 'ask_head'
	h.textContent = '响应卡结算顺序（请排序后确认）'; box.appendChild(h)
	const tip = document.createElement('div'); tip.className = 'ask_text'
	tip.textContent = '多张响应卡同时触发，决定先后结算顺序；确认后逐张询问是否发动。' +
		'「跳过」= 本次不发动、确认后不再询问（卡留在桌面）。'; box.appendChild(tip)
	const list = document.createElement('div'); list.style.margin = '6px 0'; box.appendChild(list)
	const byId = {}; for (const c of cands) byId[c.card_id] = c
	resp_ui.order.forEach((id, i) => {
		const c = byId[id]; if (!c) return
		const row = document.createElement('div')
		row.style.cssText = 'display:flex;align-items:center;gap:6px;margin:3px 0'
		const name = document.createElement('span'); name.style.flex = '1'
		name.textContent = (i + 1) + '. ' + c.name +
			((resp_ui.skip && resp_ui.skip[id]) ? '（跳过）' : '')
		row.appendChild(name)
		const up = document.createElement('button'); up.className = 'action'; up.textContent = '↑'
		up.onclick = () => { move_resp_order(i, -1); send_resp_reorder() }
		row.appendChild(up)
		const down = document.createElement('button'); down.className = 'action'; down.textContent = '↓'
		down.onclick = () => { move_resp_order(i, 1); send_resp_reorder() }
		row.appendChild(down)
		/*
		 * 【2026-10-28 玩家口径】跳过 = 本次移出本组：确认顺序后不再询问这一张，
		 * 卡仍留在桌面、不消耗。可随时「恢复」。
		 */
		const sk = document.createElement('button'); sk.className = 'action'
		sk.textContent = (resp_ui.skip && resp_ui.skip[id]) ? '恢复' : '跳过'
		sk.onclick = () => {
			resp_ui.skip = resp_ui.skip || {}
			if (resp_ui.skip[id]) delete resp_ui.skip[id]
			else resp_ui.skip[id] = true
			send_resp_reorder()
		}
		row.appendChild(sk)
		list.appendChild(row)
	})
	const btnRow = document.createElement('div'); btnRow.style.cssText = 'margin-top:8px;display:flex;gap:8px'
	const okB = document.createElement('button'); okB.className = 'action primary'
	okB.textContent = '确认顺序'
	okB.onclick = () => send_action('response_confirm', {})
	btnRow.appendChild(okB)
	/* 逃生口：整组一起放弃（pass_response all:true，服务端整组丢弃） */
	const skipAll = document.createElement('button'); skipAll.className = 'action'
	skipAll.textContent = '全部跳过'
	skipAll.onclick = () => send_action('pass_response', { all: true })
	btnRow.appendChild(skipAll)
	box.appendChild(btnRow)
}

/*
 * 提交战斗卡。
 *
 * 注意：这里【不再】需要 defendAir / retreatTo ——
 * "是否用空军代受"由防守方通过 resolve_battle 单独提交，
 * 服务端会把战斗挂起并只把询问发给防守方。
 */
function finish_battle_card() {
	const bf = battle_flow

	/*
	 * 状态卡战斗（15338/15339/15346）走 activate_status，
	 * 而非 play_card。所有参数（space / from / victim / discard）一致，
	 * 只是 action 名与 card 指向状态卡本身。
	 */
	if (bf && bf.origin === 'status') {
		const base = { card: status_act_card, space: bf.space }
		if (bf.from) base.from = bf.from
		if (bf.victim) base.victim = bf.victim
		if (status_act_discard && status_act_discard.length)
			base.discard = status_act_discard.slice()
		render_ask_box(null)
		ask_state = null
		battle_flow = null
		clear_piece_highlight("initiator")
		clear_target_highlight()
		const nm = status_name(status_act_card)
		status_act_card = null
		status_act_discard = null
		status_act_ui = null
		status_act_phase = null
		status_battle_cands = []
		send_action("activate_status", base)
		toast("已触发《" + nm + "》于 " +
			((view.spaces[base.space] || {}).name || "?"))
		return
	}

	const base = { card: pending_card.id, space: bf.space }
	if (pending_mode)
		base.mode = pending_mode
	if (bf.from)
		base.from = bf.from
	if (bf.victim)
		base.piece = bf.victim

	render_ask_box(null)
	ask_state = null
	battle_flow = null
	clear_piece_highlight("initiator")
	submit_basic_card(base)
	toast("已打出《" + pending_card.name + "》到 " +
		((view.spaces[base.space] || {}).name || "?") +
		(bf.isEmpty ? "（空打：该地区无可攻击敌军）" : ""))
	cancel_basic_card()
}

/*
 * 算子高亮（用于"在地图上选发起单位"）：
 * 给指定算子加上 .pickable 类，让玩家一眼看出哪些能点。
 */
const piece_highlight = {}   /* kind -> [piece_id] */

function highlight_pieces(ids, kind) {
	clear_piece_highlight(kind)
	piece_highlight[kind] = (ids || []).slice()
	for (const id of piece_highlight[kind]) {
		const el = piece_elt(id)   /* ui.piece_el 注册表，比 DOM 查询更可靠 */
		if (el) el.classList.add("pickable")
	}
}

function clear_piece_highlight(kind) {
	for (const id of (piece_highlight[kind] || [])) {
		const el = piece_elt(id)
		if (el) el.classList.remove("pickable")
	}
	piece_highlight[kind] = []
}

/*
 * 【2026-10-24 玩家口径】侧栏「海峡：」这一行已删除，其下方内容整体上移。
 *
 * 原实现（保留在这里以便随时恢复，恢复时同时把 play.html 里被注释掉的
 * <div id="strait_line"> 还原，并在 on_update 里补回 update_strait_line() 调用）：
 *
 *   function update_strait_line() {
 *       const el = document.getElementById("strait_line")
 *       if (!el) return
 *       if (!view.straits || !view.strait_control) { el.textContent = ""; return }
 *       const parts = []
 *       for (const s of view.straits) {
 *           const c = view.strait_control[s.name]
 *           const cls = c === "axis" ? "st-axis" : "st-allies"
 *           const label = c === "axis" ? "轴" : "同"
 *           parts.push(s.name + '<span class="' + cls + '">' + label + "</span>")
 *       }
 *       el.innerHTML = "海峡：" + parts.join(" ")
 *   }
 *
 * 注意：view.straits / view.strait_control 仍在服务端下发，
 * 地图上的海峡高亮等其它功能（本文件 9190 附近）照旧使用，未受影响。
 */

/* ============================================================
 * 分数面板（2026-09-22）
 *
 * 显示两块内容：
 *   ① 阵营总分（轴心 / 同盟）+ 分差
 *   ② 【本方代表国】当前可得分数的明细（按地块），
 *      标注是"独自占领"还是"共同占领"，以及同格的友军
 * ============================================================ */
function update_score_panel() {
	const sc = view.score || {}
	const a = Number(sc.axis || 0)
	const b = Number(sc.allies || 0)

	set_text("score_axis", fmt_score(a))
	set_text("score_allies", fmt_score(b))
	set_text("score_gap", a === b ? "平分" : (a > b ? "轴心领先 " : "同盟领先 ") +
		fmt_score(Math.abs(a - b)))

	/* 胜负横幅 */
	const winEl = document.getElementById("score_winner")
	if (winEl) {
		winEl.classList.toggle("hide", !view.winner)
		if (view.winner)
			winEl.textContent = (view.winner === "axis" ? "轴心胜利" : "同盟胜利") +
				(view.win_reason ? "：" + view.win_reason : "")
	}

	/* 明细 */
	const headEl = document.getElementById("score_detail_head")
	const detEl = document.getElementById("score_detail")
	if (!detEl)
		return
	detEl.innerHTML = ""

	const bd = view.my_score_detail
	if (headEl) {
		headEl.classList.toggle("hide", !bd)
		if (bd) {
			/* 代表团一并显示，例如"英国（含法国）" */
			const bloc = (bd.bloc || []).slice()
			const extra = bloc.length > 1 ? "（含 " + bloc.slice(1).join("/") + "）" : ""
			set_text("score_my_nation", (bd.counted_as || view.my_nation || "—") + extra)
		}
	}
	if (!bd || !bd.total) {
		const d = document.createElement("div")
		d.className = "none"
		d.textContent = "（当前还未占领任何有计分标记的地区）"
		detEl.appendChild(d)
		return
	}

	for (const it of bd.items) {
		const row = document.createElement("div")
		row.className = "row" + (it.shared ? " shared" : "")

		const nm = document.createElement("span")
		nm.className = "nm"
		nm.textContent = it.name + (it.shared ? "（共同占领）" : "")
		row.appendChild(nm)

		const who = document.createElement("span")
		who.className = "who"
		who.textContent = it.shared && it.friendly && it.friendly.length
			? "友军 " + it.friendly.join("、")
			: ""
		row.appendChild(who)

		const pt = document.createElement("span")
		pt.className = "pt"
		pt.textContent = "+" + fmt_score(it.gained)
		row.appendChild(pt)

		detEl.appendChild(row)
	}

	const tot = document.createElement("div")
	tot.className = "total"
	tot.innerHTML = "<span>本次可得</span><span>+" + fmt_score(bd.total) + "</span>"
	detEl.appendChild(tot)
}

/* 分数显示：整数不带小数点，半整数（终局 +0.5）保留一位 */
function fmt_score(v) {
	return Number.isInteger(v) ? String(v) : v.toFixed(1)
}

/* ============================================================
 * 地图上的计分标记
 *
 * 每个有标记的地块右上角画一个胶囊：★N
 *   · N = 该地块的标记总分
 *   · 若标记有归属（只对某国生效），胶囊变绿色并标出国名
 * ============================================================ */
function update_markers() {
	const wrap = document.getElementById("pieces")
	const markers = view.markers || {}
	if (!wrap)
		return

	const seen = {}

	for (const key of Object.keys(markers)) {
		const space_id = Number(key)
		const list = markers[key] || []
		if (!list.length)
			continue

		const total = list.reduce((s, mk) => s + (mk.value || 1), 0)
		/* 归属：全部或部分标记指定了国家时显示 */
		const owners = []
		for (const mk of list) {
			if (mk.owner && owners.indexOf(mk.owner) < 0) owners.push(mk.owner)
		}

		seen[space_id] = true
		let elt = ui.marker_el[space_id]
		if (!elt) {
			elt = document.createElement("div")
			elt.className = "marker-badge"
			const star = document.createElement("span")
			star.className = "star"
			star.textContent = "★"
			elt.appendChild(star)
			const num = document.createElement("span")
			num.className = "num"
			elt.appendChild(num)
			const who = document.createElement("span")
			who.className = "who"
			elt.appendChild(who)
			wrap.appendChild(elt)
			ui.marker_el[space_id] = elt
			/* 【2026-10-28 性能】子元素缓存，省掉每帧两次 querySelector */
			elt.__num = num
			elt.__who = who
		}

		/*
		 * 位置：地块右上角。
		 * data.spaces 只有 x/y（左上角），宽高在 layout 里，
		 * 所以用固定偏移把胶囊摆在格子右上外侧，避免压住地区名。
		 * 【2026-10-28 性能】位置没变就不写 style。
		 */
		const sp = data.spaces[space_id]
		if (sp) {
			const l = (sp.x + 6) + "px"
			const t = (sp.y - 16) + "px"
			if (elt.style.left !== l)
				elt.style.left = l
			if (elt.style.top !== t)
				elt.style.top = t
		}

		const totalTxt = String(total)
		const whoTxt = owners.length ? owners.join("/") : ""
		if (elt.__num && elt.__num.textContent !== totalTxt)
			elt.__num.textContent = totalTxt
		if (elt.__who && elt.__who.textContent !== whoTxt)
			elt.__who.textContent = whoTxt
		const wantOwned = owners.length > 0
		if (elt.classList.contains("owned") !== wantOwned)
			elt.classList.toggle("owned", wantOwned)
		const tip = data.name_of(space_id) + "：" + total + " 个计分标记" +
			(owners.length ? "（仅 " + owners.join("/") + " 可计分）" : "")
		if (elt.title !== tip)
			elt.title = tip
	}

	/* 清掉已无标记的 */
	for (const key of Object.keys(ui.marker_el)) {
		const id = Number(key)
		if (!seen[id]) {
			ui.marker_el[key].remove()
			delete ui.marker_el[key]
		}
	}
}

/*
 * 补给状态行：显示当前行动国 + 各国断补数
 * 断补的部队会在其算子上叠红圈（见 play.css 的 .unit.out_of_supply）
 */
function update_supply_line() {
	const el = document.getElementById("supply_line")
	if (!el)
		return

	const by = (view.supply && view.supply.by_nation) || {}
	const parts = []
	for (const n of (view.order_of_nations || [])) {
		const d = by[n]
		if (!d)
			continue
		const bad = d.total - d.ok
		const cur = (n === view.current_nation) ? " cur" : ""
		parts.push(
			'<span class="sn' + cur + '">' + n +
			'<b>' + d.ok + "/" + d.total + "</b>" +
			(bad > 0 ? '<i class="bad">−' + bad + "</i>" : "") +
			"</span>"
		)
	}
	el.innerHTML = parts.length
		? "补给：" + parts.join(" ")
		: "补给：场上无部队"
	/*
	 * 【2026-10-24】「行动国：」单独一行（CSS 里 .cur_nation 设为 block），
	 * 顺带去掉原先用于拼同一行的前导空格。
	 */
	if (view.current_nation)
		el.insertAdjacentHTML("beforeend",
			'<span class="cur_nation">行动国：' + view.current_nation + "</span>")
}

/*
 * 同步地块的"补给点"CSS class。
 *
 * 为什么需要：markup_classes() 只在 build_map() 时跑一次，
 * 而补给点现在【可被卡牌改变】，之后必须刷新，
 * 否则地图上的★会和实际状态对不上（"改了但没画出来"）。
 *
 * 见 docs/pitfalls.md 通用教训 1：渲染时机 ≠ 状态时机。
 */
function update_supply_classes() {
	const byId = (view && view.supply_by_id) || {}
	for (const s of Object.keys(ui.spaces)) {
		const elt = ui.spaces[s]
		const d = byId[s]
		/*
		 * 【2026-10-28 性能】先比对再 toggle。
		 * classList.toggle() 即使"结果没变"也可能走一次属性写入 + 样式失效，
		 * 而这里每帧要遍历【全部格位】（上百个），累积开销不明。
		 */
		const want_supply = !!d
		const want_half = !!(d && d.axis !== d.allies)
		if (elt.classList.contains("supply") !== want_supply)
			elt.classList.toggle("supply", want_supply)
		/* 仅对单一阵营有效的补给点用 half 标记，视觉上区分 */
		if (elt.classList.contains("half") !== want_half)
			elt.classList.toggle("half", want_half)
	}
}

/*
 * 参战状态行（苏联 / 美国的中立规则）
 *
 * 显示形如：
 *   参战：苏联<b class="neutral">中立</b> 美国<b class="joined">已参战</b>
 *
 * 点击某个国家名可以展开它的条件进度（还差什么才能参战），
 * 数据全部来自 view.neutral_detail（服务端算好的，客户端不再推导）。
 */
function update_neutral_line() {
	const el = document.getElementById("neutral_line")
	if (!el)
		return

	const neutral = view.neutral || {}
	const detail = view.neutral_detail || {}
	const names = Object.keys(neutral)
	if (!names.length) {
		el.innerHTML = ""
		return
	}

	const parts = []
	for (const n of names) {
		const isNeutral = neutral[n]
		const cls = isNeutral ? "neutral" : "joined"
		const label = isNeutral ? "中立" : "已参战"
		let tip = n + "：" + label
		const d = detail[n]
		if (d && d.reason)
			tip += "\n参战原因：" + d.reason
		/*
		 * 【2026-10-24 玩家口径】「参战」行与「海峡」行之间【不要任何间隔】。
		 *
		 * 原先中立国的"参战条件进度"会另起一个 .cond_list 插在下方：
		 * 窄侧栏里长文案折行，视觉上只剩一排空圆圈，还把两行撑开一大段空白。
		 * （另：那里误写成 esc(d.zh)，`d` 是国家级详情、没有 zh 字段，
		 *  所以连文字都被吞了 —— 真正该取的是 c.zh。）
		 * 现改为并进每个国家标签的 title：悬停即可看到条件与进度，
		 * DOM 上不再多一行 —— 信息不丢，间隔消失。
		 */
		if (d && d.conditions && d.conditions.length) {
			tip += "\n参战条件："
			for (const c of d.conditions)
				tip += "\n" + (c.done ? "✓ " : "○ ") + (c.zh || "")
		}
		parts.push(
			'<span class="nt ' + cls + '" title="' + esc_attr(tip) + '">' +
			n + "<b>" + label + "</b></span>"
		)
	}
	el.innerHTML = "参战：" + parts.join(" ")
	/* 条件进度已并入上面每个国家标签的 title，这里不再生成 .cond_list */
}

/* HTML 文本转义（条件文案里有 <> 等字符） */
function esc(s) {
	return String(s == null ? "" : s)
		.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
}

/* 供 title 属性用：转义引号与换行 */
function esc_attr(s) {
	return esc(s).replace(/"/g, "&quot;").replace(/\n/g, "&#10;")
}

/*
 * 【2026-10-24 玩家口径】日志面板可折叠（默认收起）。
 *
 * ⚠ #log 元素【不能删】：平台 common/client.js 的 update_log() 会
 * `document.getElementById("log")` 后直接读 children/lastChild，
 * 元素缺失就抛 TypeError、日志渲染整条链断掉。
 * 所以"折叠"只切 class（display:none），元素始终在。
 *
 * 收起时标题显示"N 条新"，避免错过关键日志；折叠状态存 localStorage
 * （跟着浏览器走，不跟着对局）。
 */
let log_collapsed = true
let log_seen = 0
let log_ready = false

function update_log_toggle() {
	const btn = document.getElementById("log_toggle")
	const box = document.getElementById("log")
	if (!btn || !box) return

	if (!log_ready) {
		log_ready = true
		try {
			const v = window.localStorage.getItem("qm_log_collapsed")
			if (v === "0") log_collapsed = false
		} catch (e) { /* 隐私模式禁用 localStorage 时忽略 */ }
		/* 首次进来把已有日志视为已读，否则会显示"800 条新" */
		log_seen = box.children.length
		box.classList.toggle("collapsed", log_collapsed)
	}

	const n = box.children.length
	const unread = log_collapsed ? Math.max(0, n - log_seen) : 0
	btn.textContent = (log_collapsed ? "日志 ▾" : "日志 ▴") +
		(unread ? "　" + unread + " 条新" : "")
	if (!log_collapsed) log_seen = n
}

function toggle_log() {
	const box = document.getElementById("log")
	if (!box) return
	log_collapsed = !log_collapsed
	try {
		window.localStorage.setItem("qm_log_collapsed", log_collapsed ? "1" : "0")
	} catch (e) {}
	log_seen = box.children.length
	update_log_toggle()
}

/* 绑定折叠按钮（本文件以 defer 加载，执行时 DOM 已解析完） */
;(function () {
	const b = document.getElementById("log_toggle")
	if (b) b.onclick = toggle_log
})()

function update_violations() {
	/* 留空，后续规则检查接入 */
	set_text("violations", "")
}

/* ---- 算子渲染 ---- */

function update_pieces() {
	if (!view.pieces)
		return
	const wrap = document.getElementById("pieces")
	if (!wrap)
		return

	const seen = {}

	/* 同一格位多个算子需要错开摆放，先按格位分组 */
	const by_space = {}
	for (const p of view.pieces) {
		if (p.loc == null)
			continue
		;(by_space[p.loc] = by_space[p.loc] || []).push(p)
	}

	for (const space_id of Object.keys(by_space)) {
		const list = by_space[space_id]
		list.sort(compare_pieces)

		/*
		 * 分行：单位（陆军/海军）在下，空军在上。
		 * 只有一行时让它在格位正中，两行时才上下分开。
		 */
		const units = list.filter(p => p.type !== "air")
		const airs = list.filter(p => p.type === "air")
		const two_rows = units.length > 0 && airs.length > 0

		const place_row = (arr, dy) => {
			arr.forEach((p, i) => {
				seen[p.id] = true
				let elt = ui.piece_el[p.id]
				if (!elt) {
					elt = build_piece(p)
					ui.piece_el[p.id] = elt
					wrap.appendChild(elt)
				}
				const dx = (i - (arr.length - 1) / 2) * PIECE_GAP
				position_piece(elt, Number(space_id), dx, dy)
				update_piece_face(elt, p)
			})
		}

		place_row(units, two_rows ? UNIT_ROW_DY : 0)
		place_row(airs, two_rows ? AIR_ROW_DY : 0)
	}

	/* 移除已不在场上的算子 */
	for (const id of Object.keys(ui.piece_el)) {
		if (!seen[id]) {
			ui.piece_el[id].remove()
			delete ui.piece_el[id]
		}
	}
}

function build_piece(p) {
	const elt = document.createElement("div")
	elt.piece_id = p.id
	elt.className = "unit"

	const label = document.createElement("div")
	label.className = "unit_label"
	elt.appendChild(label)

	elt.addEventListener("click", on_click_piece)
	elt.addEventListener("mouseenter", on_focus_piece)
	elt.addEventListener("mouseleave", on_blur_piece)

	return elt
}

/*
 * 【2026-10-28 性能】只在内容真的变了才写 DOM。
 *
 * 原来每帧无条件重写 className / title / label。其中 className 是致命的：
 * .unit::before 的 filter（9 层 drop-shadow 描边，见 play.css）由类名决定，
 * 一次赋值就会让全场每个算子的 9 层阴影全部重新栅格化 —— 一次 view 刷新
 * 等于几十个算子 × 9 次阴影合成，这是"点牌延迟"的最大来源。
 */
function update_piece_face(elt, p) {
	const nation = p.nation || "?"
	const cls = "unit " + (p.type || "army") +
		" " + (NATION_CLS[nation] || "") +
		(p.in_supply ? " in_supply" : " out_of_supply")
	if (elt.className !== cls)
		elt.className = cls
	const tip = nation + " " + (TYPE_LABEL[p.type] || p.type) +
		(p.in_supply ? "（补给正常）" : "（断补，补给阶段将被移除）")
	if (elt.title !== tip)
		elt.title = tip
	/* 子元素缓存：每帧 querySelector 本身也是一次遍历，顺手省掉 */
	const label = elt.__label || (elt.__label = elt.querySelector(".unit_label"))
	const text = TYPE_LABEL[p.type] || "?"
	if (label && label.textContent !== text)
		label.textContent = text
}

/*
 * 同格位多算子的排版参数。
 *
 * 按共存规则（每国 1 个单位 + 1 个飞机）分行摆放：
 *   · 单位行（陆军/海军）在格位中心偏下
 *   · 空军行在上方，视觉上"在空中"
 * 算子直径 46px，行内间距取 52px 以留出缝隙、避免相互遮挡。
 */
const PIECE_GAP = 52
const UNIT_ROW_DY = 12
const AIR_ROW_DY = -40

/*
 * 稳定排序：国家 -> 类型（单位在前、空军在后）-> id。
 * 按国家而非 id 排序，是为了让同一格位的算子左右顺序稳定，
 * 增删其它算子时不会让已有的算子左右跳动。
 */
function compare_pieces(a, b) {
	const na = a.nation || "", nb = b.nation || ""
	if (na !== nb)
		return na.localeCompare(nb, "zh")
	const ta = (a.type === "air") ? 1 : 0
	const tb = (b.type === "air") ? 1 : 0
	if (ta !== tb)
		return ta - tb
	return String(a.id).localeCompare(String(b.id))
}

function position_piece(elt, space_id, dx, dy) {
	const sp = data.spaces[space_id]
	if (!sp)
		return
	/* 【2026-10-28 性能】位置没变就不写（每帧无谓写 style 会触发样式重算） */
	const l = (sp.x + dx) + "px"
	const t = (sp.y + dy) + "px"
	if (elt.style.left !== l)
		elt.style.left = l
	if (elt.style.top !== t)
		elt.style.top = t
}

/*
 * client.js 的查询回调（send_query 的结果通过它返回）。
 * 目前只处理基本卡的合法目标。
 */
/* 实际的 on_reply 定义在文件末尾（合并了所有查询分支） */


/* ============================================================
 * 交互：Esc / 右键取消基本卡的选目标
 * ============================================================ */

document.addEventListener("keydown", (e) => {
	if (e.key !== "Escape")
		return
	if (pending_event_card) {
		cancel_event_card()
		return
	}
	if (pending_card) {
		cancel_basic_card()
		toast("已取消选择")
	}
	cancel_discard_mode()
	cancel_discard_playmode()
	cancel_resource_swap()
	cancel_air_move()
	/* 弃牌阶段：Esc 清空已框住的选择 */
	if (discard_pick.length) {
		discard_pick = []
		update_hand_panel()
		update_phase_buttons()
	}
})

/* 点弹框外的遮罩关闭（点击内容区不关） */
document.addEventListener("click", (e) => {
	const modal = document.getElementById("resource_modal")
	if (modal && !modal.classList.contains("hide") && e.target === modal)
		cancel_resource_swap()
})

document.addEventListener("contextmenu", (e) => {
	if (pending_card) {
		e.preventDefault()
		cancel_basic_card()
		toast("已取消选择")
	}
})

/* ============================================================
 * 三、交互
 * ============================================================ */

/* 取格位 / 算子的 DOM 元素（供高亮使用） */
function space_elt(id) { return ui.spaces[id] || null }
function piece_elt(id) { return ui.piece_el[id] || null }

/*
 * 【2026-10-30】状态卡"选地"点击的处理（从 on_click_space 抽出并上移）。
 *
 * 优先级原则：**玩家显式点某张桌面卡发起的流程** > 任何隐式流程
 * （战区移动 / 高速公路 / 让权委托 …），因为隐式流程不需要玩家先做选择、随时可继续。
 *
 * 为什么必须这样：战区移动（17532）在建设步会把地图点击直接提交给 resolve_theater，
 * 而状态卡（17550 先进造船厂等）此时正等玩家点地建海军 —— 点击被战区移动吃掉后，
 * 玩家看到的提示还在，但怎么点都不生效（#4 的真实原因）。
 */
function handle_status_space_pick(s) {
	/* 状态卡"建设预算"：玩家点选合法空格（17547/17550/15248/17843…） */
	if (status_build_pending) {
		if (status_build_cands.indexOf(Number(s)) < 0) { toast('请在合法高亮地区中选择'); return true }
		status_build_pending = false
		highlight_targets(null)
		const cid = status_act_card
		const hadDiscard = status_build_discard
		render_ask_box(null)
		const sArg = { card: cid, space: s }
		if (hadDiscard && hadDiscard.length) sArg.discard = hadDiscard
		status_build_discard = null
		send_action('activate_status', sArg)
		toast('发动《' + status_name(cid) + '》')
		after_status_space_done()
		return true
	}
	/*
	 * 状态卡"战斗选地"（15247 贵在行动 / 17544 等）-> 进入选发起单位流程。
	 * 仅当【当前这张卡】确实用服务端动态候选时才按候选校验，
	 * 否则（17544/15338 等静态 spaces 或无 spaces）不能用上一张卡的残留候选去拦。
	 */
	if (status_act_ui && status_act_ui.spaces_from_window &&
		status_battle_cands.length && status_battle_cands.indexOf(Number(s)) < 0) {
		toast('请在合法高亮地区中选择（须是建设地点的相邻陆地）')
		return true
	}
	const allow = (status_act_ui && status_act_ui.spaces)
		? status_act_ui.spaces.map(space_id_of_name).filter(x => x != null).map(Number)
		: null
	if (allow && allow.indexOf(s) < 0) {
		toast('该地区不在《' + status_name(status_act_card) + '》可攻击范围内')
		return true
	}
	status_start_battle_space(s)
	return true
}

/* 状态卡选地结束后：让战区移动的面板/候选重新算一遍（期间地图可能变了） */
function after_status_space_done() {
	theater_query_sig = null
	theater_space_cands = null
	if (typeof update_pending_theater_box === 'function') update_pending_theater_box()
}

function on_click_space(evt) {
	const s = evt.currentTarget.space_id

	/*
	 * 【2026-10-30】最高优先级：玩家已点开状态卡、正在等选地
	 * （见 handle_status_space_pick 的注释）。
	 */
	if (status_act_phase === 'space') return handle_status_space_pick(s)

	/*
	 * 【2026-10-31】增强卡"多步 need"选地区（17514 飞虎队 / 17815 Z 计划 等）：
	 * 玩家已选完 option，正在等点地图 -> 用【同一个 play_card】带齐参数重发。
	 * 优先级与状态卡同级（也是玩家显式发起的流程），都排在战区移动这类隐式流程之前。
	 */
	if (echo_need_pick) {
		const sid = Number(s)
		if ((echo_need_pick.cands || []).indexOf(sid) < 0) {
			toast('请在合法高亮地区中选择')
			return
		}
		const arg = { card: echo_need_pick.card, space: s }
		if (echo_need_pick.choice != null) arg.choice = echo_need_pick.choice
		clear_echo_need_pick()
		send_action('play_card', arg)
		return
	}

	/*
	 * 【2026-10-25】战区移动（17532）：建设步点地区即提交。
	 * 候选来自 RPC 缓存（本步现算），不在候选内直接提示，不发请求。
	 * 【2026-10-30】降为"次级"—— 状态卡选地已在上面拦下。
	 */
	if (view && view.pending_theater &&
		(view.pending_theater.stage === 'build_navy' || view.pending_theater.stage === 'build_army')) {
		if (!view.pending_theater.can_act) {
			toast('等待【' + view.pending_theater.actor + '】操作《战区移动》')
			return
		}
		const ids = theater_space_cands || []
		if (ids.indexOf(Number(s)) >= 0) {
			send_action('resolve_theater', { space: s })
			theater_space_cands = null
			theater_query_sig = null
			clear_target_highlight()
		} else {
			toast('该地区不是《战区移动》的合法建设目标')
		}
		return
	}

	/*
	 * 【2026-10-07】armed 增强卡多步交互：需要选地区时拦截。
	 * 候选由服务端算好下发（view.armed_offer.pending.candidates），客户端不二次过滤。
	 */
	/* 17729 卡佩里尼：打出基本卡选目标位置 */
	if (view && view.delegate && view.delegate.mode === 'order' && view.delegate.sub) {
		/*
		 * 【2026-10-22】改走真实基本卡流程：需要 mode（空军力量三选一）/发起单位，
		 * 不能再直接提交裸 {space}（那样 mode 丢失 -> 卡打出了却没效果）。
		 */
		if (on_space_click_for_card(s)) return
		send_action('resolve_italy_play', { space: s })
		return
	}

	/* 16304 中国远征军：让权美国 —— 点相邻地区之一，中国在此征召陆军 */
	if (view && view.us_china_delegate &&
		(view.us_china_delegate.candidates || []).some(c => c.id === s)) {
		clear_target_highlight()
		send_action('resolve_china_delegate', { space: s })
		return
	}
	/* 17526 民主兵工厂：让权英国 —— 顺序已定，点候选地区建【当前这一支】 */
	if (view && view.uk_build_delegate && !view.uk_build_delegate.waiting_for &&
		view.uk_build_delegate.stage === 'build') {
		const dg = view.uk_build_delegate
		const hit = (dg.candidates || []).find(c => c.id === s)
		if (hit) {
			clear_target_highlight()
			send_action('resolve_uk_build_delegate', { space: s, build: dg.current })
			return
		}
	}
	/* 17529 摩尔曼斯克运输船队：让权苏联 —— 点候选地区，苏联建设 */
	if (view && view.su_build_delegate &&
		(view.su_build_delegate.candidates || []).some(c => c.id === s)) {
		clear_target_highlight()
		send_action('resolve_su_build_delegate', { space: s })
		return
	}
	/* 17537 美国人民同情中国：美国帮中国 —— 点候选地区，中国征召 */
	if (view && view.us_china_build &&
		(view.us_china_build.candidates || []).some(c => c.id === s)) {
		clear_target_highlight()
		send_action('resolve_us_china_build', { space: s })
		return
	}
	/* 17532 战区移动：美国 —— 点候选地区，建设 */
	if (view && view.us_theater_delegate &&
		(view.us_theater_delegate.candidates || []).some(c => c.id === s)) {
		clear_target_highlight()
		send_action('resolve_us_theater_delegate', { space: s })
		return
	}
	/* 【2026-10-25】17531 现购自运政策：已选兵种 -> 点候选地区即完成征召 */
	if (view && view.us_merchant && view.us_merchant.step === 'space' &&
		(view.us_merchant.targets || []).some(t => t.id === s)) {
		clear_target_highlight()
		send_action('resolve_us_merchant_build', { space: s })
		return
	}

	if (pending_armed && pending_armed.need === 'space') {
		if ((pending_armed.candidates || []).indexOf(s) >= 0) {
			const card = pending_armed.card
			clear_target_highlight()
			pending_armed = null
			send_action('use_armed_offer', { card: card, space: s })
			toast('已选择地区')
		} else {
			toast('不能选这里 —— 请点高亮地区')
		}
		return
	}
	/*
	 * 【2026-10-17】armed 选部队(need:'piece')步里附带的空白合法地块（15406 空打）：
	 * 点到空白地块 = 对该地区空打（victim 传空），用于触发闪电战/after_ally_battle 等。
	 */
	if (pending_armed && pending_armed.need === 'piece' &&
		(pending_armed.spaceCandidates || []).indexOf(s) >= 0) {
		const card = pending_armed.card
		clear_target_highlight()
		clear_piece_highlight('armed')
		pending_armed = null
		send_action('use_armed_offer', { card: card, space: s })
		toast('已选择空打地区')
		return
	}

	/*
	 * 【2026-10-15】状态卡"建设预算"选地（17547/17550/15248/17843…）必须
	 * 【优先于】高速公路：这是玩家【显式点击状态卡】发起的选地；
	 * 而高速公路的选位是【隐式】的（期间点在地图上任何地方都被当作重建）。
	 * 旧顺序 pending_autobahn 在前面，会把状态卡的选地点击整个吞掉，
	 * 表现为"高速公路期间点 15248 合成燃料没反应" ——
	 * 与 15247 确认框被覆盖属同一类"点击优先级争抢"。
	 * （原本此分支写在下方 status_act_phase==='space' 里，故被 autobahn 抢先；
	 *   现整体上移到这里，下面不再保留重复实现。）
	 */
	/*
	 * 【2026-10-30】状态卡"选地"分支已上移到 on_click_space 的最前面
	 * （改为 handle_status_space_pick），因为它必须优先于战区移动/高速公路等
	 * 隐式流程 —— 否则玩家点开状态卡后，点地图会被隐式流程吃掉，
	 * 表现为"分步机中间无法触发状态卡"（#4）。
	 */

	/*
	 * 战斗卡 / 状态卡战斗：点地区 = 选目标地区（须先选好发起单位）。
	 *
	 * 【2026-10-15】必须排在 pending_autobahn【之前】—— 与上方
	 * status_act_phase==='space' 上移是同一个病：
	 * 状态卡战斗（15247 贵在行动）在高速公路期间发动时，玩家选完发起单位后
	 * battle_flow.step='target'，此时点目标地区若被 pending_autobahn 抢先，
	 * 就会被当成"高速公路选位"发成 resolve_autobahn —— 战斗【永远提交不出去】，
	 * 状态卡原地不动（现象：全流程能显示，但实际没发动、状态仍待发动）。
	 *
	 * 判据同前：battle_flow 是玩家【显式】发起的战斗流程，
	 * 优先于高速公路的【隐式】选位（期间点地图任何地方都算重建）。
	 */
	if (battle_flow) {
		if (!battle_flow.from) {
			toast("请先在地图上点击一支本国陆军/海军作为发起单位（空军不能发起战斗）")
			return
		}
		if (battle_flow.step === "target") {
			on_pick_battle_target(s, null)
			return
		}
	}

	/* 高速公路（15228）：选建设位置 -> 发 resolve_autobahn */
	if (view && view.pending_autobahn) {
		send_action('resolve_autobahn', { space: s })
		return
	}


	/*
	 * 战斗预算(event_budget)：点合法目标地区 -> 选择发起单位 -> 发起一次原子战斗。
	 *
	 * 【2026-10-01 修复 · 一类问题】原先这里直接 send_action('event_battle',{target})
	 * 不带发起单位，服务端预算里的 b.from 是 undefined，do_battle 自动挑一支 ——
	 * 于是"攻击地点固定、但由哪支部队发起"玩家【无法选择，也没有高亮】。
	 *
	 * 现在改为与【基本卡】同款的两步流程：
	 *   ① 点目标地区 -> 向服务端查询该格位的候选发起单位(battle_initiators)；
	 *   ② 只有一个候选就直接用它开打；有多个就把候选算子高亮，
	 *      玩家在地图上点算子(on_pick_initiator)后再提交。
	 */
	if (view && view.event_budget) {
		const eb = view.event_budget
		if (eb.targets && eb.targets.indexOf(s) >= 0) {
			if (!eb.can_finish) {
				toast('请先完成当前战斗的结算（代受/抵消）再发起下一场')
				return
			}
			const inits = (eb.initiators && eb.initiators[s]) || []
			if (!inits.length) {
				toast('没有可发起战斗的本国陆军或海军（空军不能发起战斗）')
				return
			}
			/* 该格的敌方（多国）部队：多于 1 支时需让玩家选择要攻击哪一支 */
			const enemyPieces = (eb.enemies && eb.enemies[s]) || []
			if (inits.length === 1 && enemyPieces.length <= 1) {
				send_action('event_battle', {
					target: s,
					from: inits[0].id,
					victim: enemyPieces[0] ? enemyPieces[0].id : undefined,
				})
				toast('对 ' + ((view.spaces[s] || {}).name || '?') + ' 发起' + (eb.kind === 'sea' ? '海战' : '陆战'))
				return
			}
			/* 需要玩家选择发起单位 和/或 受击单位：进入"选发起单位"状态 */
			battle_flow = { origin: 'event', space: s, initiators: inits, step: 'initiator', enemyPieces: enemyPieces }
			highlight_pieces(inits.map(u => u.id), 'initiator')
			ask_state = { kind: 'event_battle_from', target: s }
			const ktxt = eb.kind === 'sea' ? '海军' : '陆军/海军'
			render_ask_box(
				'选择发起单位',
				'请在地图上点击一支【处于补给状态、与目标相邻的本国' + ktxt +
					'】来发起对 ' + ((view.spaces[s] || {}).name || '?') + ' 的攻击（共 ' +
					inits.length + ' 支可选）',
				[{ label: '取消', onClick: () => cancel_event_budget_pick() }]
			)
			return
		}
	}

	/* 空军调度：点地区选目标 */
	if (air_move) {
		if (!air_move.air) {
			toast("请先点 1 支本国空军算子")
			return
		}
		/*
		 * 【2026-10-30】优先用"该空军自己的合法目标表"（targets_by_air），
		 * 这样"原地调度"（落到自己当前格）能点，而"落到已有别的本国空军的格"仍然点不了。
		 */
		const perAir = air_move.targetsByAir && air_move.targetsByAir[air_move.air]
		const okT = perAir
			? (perAir || []).some(x => Number(x) === Number(s))
			: air_move.targets.some(t => t.id === s)
		if (!okT) {
			toast("该地区没有处于补给状态的本国陆军或海军（或已有本国空军）")
			return
		}
		air_move.target = s
		if (!air_move.card) {
			update_air_box()
			toast("还差一步：请在下方手牌中点 1 张作为弃牌代价")
			return
		}
		send_action("air_support", { air: air_move.air, target: s, card: air_move.card })
		toast("调度空军到 " + ((view.spaces[s] || {}).name || "?") + "（弃 1 张手牌）")
		cancel_air_move()
		return
	}

	/*
	/* 基本卡选目标优先于其他一切 */
	if (pending_card && on_space_click_for_card(s))
		return

	/*
	 * EVENT / ECHO 卡选目标（2026-09-25）：
	 * 玩家点了一个高亮地区 -> 累积选择。
	 *
	 * 【2026-09-25 修正多选】之前注释写"多选暂不实现"，pick>1 时
	 * 玩家点第一个地区就立刻 send_action 单个 space，导致
	 * 15326 自由法国同盟（pick:2）只能选 1 个、服务端也只建 1 支陆军。
	 * 现在：累积到 pick 数量后才提交 picks 数组。
	 */
	if (pending_event_card && pending_event_targets) {
		const cands = (pending_event_targets.candidates || []).map(c => c.id)
		if (cands.indexOf(s) < 0) {
			toast("该地区不是《" + pending_event_card.name + "》的合法目标")
			return
		}
		const pick = pending_event_targets.pick || 1
		/* 【2026-09-30】pickMin：多选区间下限（"1 或 2 次"类卡面） */
		const pickMin = event_pick_range().min
		/*
		 * 单选：直接提交 space（保留旧格式，与服务端 resolve_event_card
		 * 的 pick_space_for 兼容）。
		 */
		if (pick <= 1) {
			/*
			 * 【2026-09-29】多步卡（total>1）：先把本次选择累积到
			 * pending_event_spaces[step]，再带【完整 spaces】重新 query。
			 * 若服务端回 need:null（都选齐了）才真正提交。
			 *
			 * 单步卡（total<=1）保持原流程，直接提交，避免多一次往返。
			 */
			const total = pending_event_targets.total || 1
			if (total > 1) {
				if (!pending_event_spaces) pending_event_spaces = []
				pending_event_spaces[pending_event_targets.step] = s
				send_query("event_targets", {
					card: pending_event_card.id,
					spaces: pending_event_spaces.slice(),
					/*
					 * 【2026-10-21 修复】必须把已累积的 pieces 一并回传
					 * （与 submit_event_piece 回传 spaces 对称）：
					 * 17532 这类"先 remove 再 build"的多步卡，若选建设地区时
					 * 丢掉 pieces，服务端会重新问"选要移除的部队" ->
					 * 客户端再问选地区 -> 两张皮球踢来踢去，永远提交不了。
					 */
					...(pending_event_pieces && pending_event_pieces.length
						? { pieces: pending_event_pieces.slice() } : {}),
					...(pending_event_choice != null ? { choice: pending_event_choice } : {}),
					/* 【2026-10-14】委托打牌带 nation=被委托国 */
					nation: lend_lease_active || undefined,
				})
				toast("已选 " + ((view.spaces[s] || {}).name || "?") +
					"（第 " + (pending_event_targets.step + 1) + "/" + total + " 步）")
				return
			}

			const arg = { card: pending_event_card.id, space: s }
			/*
			 * 【2026-09-25 bug 修复】多步卡（如 15324 荷属东印度：第 0 步海军在南海、
			 * 第 1 步才需玩家选印度尼西亚/新几内亚）服务端 pick_space_for 对
			 * total>1 只读 arg.spaces[i]，而旧代码只发单个 space，
			 * 导致服务端读不到值、反复回 need:'space'（高亮能显示、点了没反应）。
			 * 这里把选的地区放到 pending step 对应的下标，传 spaces 数组，
			 * 同时保留 space 以兼容单步卡（total===1）的旧路径。
			 * ⚠ 改这里前先读 rules.js pick_space_for 注释与 docs/pitfalls.md R15，
			 *   不要把服务端 pick_space_for 改成读 arg.space（会污染 step0 位置）。
			 */
			if (pending_event_targets && pending_event_targets.step != null) {
				const sp = []
				sp[pending_event_targets.step] = s
				arg.spaces = sp
			}
			if (pending_event_choice != null)
				arg.choice = pending_event_choice
			/*
			 * 若卡片有 cost.discard 且玩家已选弃牌，
			 * 一并提交 cards: [id, ...]，让服务端按玩家的选择弃牌
			 * （resolve_event_card 的 ② 代价分支已支持 arg.cards）。
			 */
			if (pending_echo_cards && pending_echo_cards.length)
				arg.cards = pending_echo_cards.slice()
			lend_play_action(arg)
			toast("打出《" + pending_event_card.name + "》到 " +
				((view.spaces[s] || {}).name || "?"))
			cancel_event_card()
			return
		}
		/*
		 * 多选：累积到 picks 数组，达到 pick 数量后显示"Done"按钮，
		 * 玩家点 Done 才真正提交（参考 pog 的右上角 Done 按钮）。
		 * 同一地区点两次 = 取消选中；超选会被拒。
		 */
		if (!pending_event_picks)
			pending_event_picks = []
		const i = pending_event_picks.indexOf(s)
		if (i >= 0) {
			pending_event_picks.splice(i, 1)
			toast("已取消 " + ((view.spaces[s] || {}).name || "?") +
				"（已选 " + pending_event_picks.length + "/" + pick + "）")
		} else if (pending_event_picks.length >= pick) {
			toast("已选满 " + pick + " 个，请先取消一个或点【Done】确认")
			return
		} else {
			pending_event_picks.push(s)
			toast("已选 " + ((view.spaces[s] || {}).name || "?") +
				"（" + pending_event_picks.length + "/" + pick + "）" +
				(pending_event_picks.length >= pickMin
					? "，可点【Done】确认" : "，还差 " + (pickMin - pending_event_picks.length) + " 个才能确认"))
		}
		/* 重新高亮，把已选的标 .sel */
		highlight_event_targets(pending_event_targets)
		/* 更新 Done 按钮状态 */
		update_event_done_button()
		return
	}

	/*
	 * 【2026-10-04】响应卡效果需要选【地区】时（如日本 15419/15422/15423...）：
	 * 复用事件卡的 highlight_event_targets 流程（不另造 UI），
	 * 玩家点高亮地区 -> send_action('resolve_response_choice', { choice: s })。
	 *
	 * ⚠ view.response_choice 的 candidates 已由服务端归一化成 [{id,name}]，
	 *   这里直接吃，不要自己再过滤（避免与服务端判定漂移）。
	 */
	if (view && view.response_choice && view.response_choice.kind === 'space') {
		const rc = view.response_choice
		if ((rc.candidates || []).some(c => c.id === s)) {
			send_action('resolve_response_choice', { choice: s })
			toast('《' + rc.name + '》对 ' + ((view.spaces[s] || {}).name || '?') + ' 生效')
		} else {
			toast('《' + rc.name + '》不能选这里 —— 请点高亮地区')
		}
		return
	}

	/* 调试模式优先 */
	if (ui.debug_mode === "place") {
		debug_do_place(s)
		return
	}
	if (ui.debug_mode === "remove") {
		set_debug_hint("请点击地图上的部队")
		return
	}

	select_space(s)
}

function select_space(s) {
	/* 取消上次选中 */
	if (ui.selected && ui.spaces[ui.selected])
		ui.spaces[ui.selected].classList.remove("selected")
	document.querySelectorAll(".space.connected_to_selected")
		.forEach(e => e.classList.remove("connected_to_selected"))

	if (ui.selected === s) {
		ui.selected = null
		return
	}
	ui.selected = s
	const elt = ui.spaces[s]
	if (elt)
		elt.classList.add("selected")

	/* 显示本方视角下与该格位相邻的格位（直观验证连通性） */
	const nbrs = (view.adjacency && view.adjacency[s]) || []
	for (const n of nbrs) {
		const e = ui.spaces[n]
		if (e)
			e.classList.add("connected_to_selected")
	}

	const sp = data.spaces[s]
	const names = nbrs.map(n => data.name_of(n)).join("、")
	toast(`${sp.name}：相邻 ${nbrs.length} 处 — ${names}`)
}

function on_click_piece(evt) {
	evt.stopPropagation()
	const id = evt.currentTarget.piece_id

	/*
	 * 【2026-10-25】战区移动（17532）：stage='remove' 时点美国算子即提交移除。
	 * 放在所有其它分支之前 —— 本卡挂起期间只有这一步可操作（服务端也冻结了其它动作）。
	 */
	if (view && view.pending_theater && view.pending_theater.stage === 'remove') {
		if (!view.pending_theater.can_act) {
			toast('等待【' + view.pending_theater.actor + '】操作《战区移动》')
			return
		}
		const ids = theater_piece_cands || []
		if (ids.some(x => String(x) === String(id))) {
			send_action('resolve_theater', { piece: id })
			theater_piece_cands = null
			theater_query_sig = null
			clear_piece_highlight('theater')
		} else {
			toast('《战区移动》只能选高亮的美国陆军或海军')
		}
		return
	}

	/*
	 * 【2026-10-07】armed 增强卡多步交互：需要选部队时拦截。
	 * 候选由服务端算好下发，客户端不二次过滤。
	 */
	if (pending_armed && pending_armed.need === 'piece') {
		if ((pending_armed.candidates || []).some(c => String(c) === String(id))) {
			const card = pending_armed.card
			clear_piece_highlight('armed')
			pending_armed = null
			send_action('use_armed_offer', { card: card, piece: id })
			toast('已选择部队')
		} else {
			toast('不能选这支部队')
		}
		return
	}

	/*
	 * 【2026-09-26】经济战选海军优先：
	 * 面板已点过"移除海军"时，这一下点击算是在挑要移除的那支。
	 */
	if (econ_on_pick_piece(id)) {
		update_hand_panel()
		return
	}

	/*
	 * 【2026-10-04】响应卡效果需要选【部队】时（如日本 15433/15434/7905 消灭敌方陆军）：
	 * 点候选算子 -> send_action('resolve_response_choice', { choice: id })。
	 * 候选由服务端算好下发（view.response_choice.candidates），客户端不二次过滤。
	 */
	if (view && view.response_choice && view.response_choice.kind === 'piece') {
		const rc = view.response_choice
		if ((rc.candidates || []).some(c => c.id === id)) {
			send_action('resolve_response_choice', { choice: id })
			toast('《' + rc.name + '》对该部队生效')
		} else {
			toast('《' + rc.name + '》不能选这支部队')
		}
		return
	}

	/*
	 * 【2026-10-22】"收回部队"询问：点地图上高亮的本方部队直接收回。
	 * 交互对齐 17532《战区移动》：不弹列表，只高亮 + 点算子；候选由服务端下发。
	 */
	if (view && view.pending_ask) {
		const pa = view.pending_ask
		const isCand = (pa.pieces || []).some(p => String(p.id) === String(id))
		if (isCand) {
			send_action('remove_piece', { piece: id })
			toast('已收回该部队（可继续点其它高亮部队，或点「跳过」）')
		} else {
			toast('只能收回高亮的【本方】部队；不想收回请点「跳过」')
		}
		return
	}

	/*
	 * 【2026-10-10】17532 战区移动：step0 移除己方棋子。
	 * 候选由服务端算好下发（view.us_theater_delegate.remove_pieces），客户端不二次过滤。
	 */
	if (view && view.us_theater_delegate && view.us_theater_delegate.current_op === 'remove') {
		const rps = view.us_theater_delegate.remove_pieces || []
		if (rps.some(c => String(c) === String(id))) {
			clear_piece_highlight('theater')
			send_action('resolve_us_theater_delegate', { piece: id })
			toast('已选择移除该部队')
		} else {
			toast('《战区移动》只能选高亮的美国陆军或海军')
		}
		return
	}

	/*
	 * 【2026-10-06】EVENT/ECHO 卡要求选【部队】时（15411 夜间运输）。
	 * 候选由服务端算好下发，客户端不二次过滤。
	 */
	if (pending_event_targets && pending_event_targets.need === 'piece') {
		const cands = pending_event_targets.candidates || []
		if (cands.some(c => String(c.id) === String(id)))
			submit_event_piece(id)
		else
			toast('《' + (pending_event_card ? pending_event_card.name : '?') +
				'》不能选这支部队')
		update_hand_panel()
		return
	}

	/*
	 * 空军调度模式：点本国空军算子 = 选中它
	 */
	if (air_move) {
		if (air_move.airs.indexOf(id) >= 0) {
			air_move.air = id
			update_air_box()
			toast("选中空军 " + id + "，再点目标地区（须有本国补给中的陆/海军）")
		} else {
			toast("这不是可调度的本国空军")
		}
		update_hand_panel()
		return
	}

	/*
	 * 战斗卡：先在地图上点【发起单位】，再点目标。
	 */
	if (battle_flow) {
		const isSeize = (pending_mode === 'seize')
		/* 还在选发起单位 */
		if (battle_flow.step === "from" || !battle_flow.from) {
			if (on_pick_initiator(id))
				return
		}
		/* 已选好发起单位 -> 这个算子作为攻击目标 */
		if (battle_flow.step === "target") {
			const cand = ((pending_targets && pending_targets.pieces) || [])
				.find(p => p.id === id)
			if (cand) {
				on_pick_battle_target(cand.space, id)
				return
			}
			/* 空战（seize）：点本国飞机 = 重选发起单位，而非"空军不可攻击" */
			if (isSeize && battle_flow.initiators.some(x => x.id === id)) {
				if (on_pick_initiator(id))
					return
			}
			toast(isSeize
				? "请选择要夺取的敌方空军（或该地区本身）"
				: "该算子不能作为攻击目标（空军不可攻击，也须先选发起单位）")
			return
		}
	}

	/* 基本卡等待选目标时：点敌方算子 = 指定战斗目标 */
	if (pending_card && pending_targets) {
		const sp = (pending_targets.pieces || []).find(p => p.id === id)
		if (sp) {
			if (is_battle_card(pending_card) || pending_mode === 'seize') {
				/* 战斗卡 / 夺取制空权：走地图两步流程（先选目标/敌机，再选发起单位） */
				play_battle_card(sp.space, id, false)
				return
			}
			const arg = { card: pending_card.id, space: sp.space }
			if (pending_mode)
				arg.mode = pending_mode
			/* 《空军力量》等：指定使用哪支己方算子 */
			arg.piece = id
			submit_basic_card(arg)
			toast("《" + pending_card.name + "》目标：" + sp.name + "（" + sp.space_name + "）")
			cancel_basic_card()
			return
		}
		toast("该算子不是合法目标")
		return
	}

	if (ui.debug_mode === "remove") {
		send_action("debug_remove", { piece: id })
		set_debug_hint("已移除 " + id)
		return
	}

	/* 非调试模式：仅提示位置 */
	const p = (view.pieces || []).find(x => x.id === id)
	if (p) {
		const sp = data.spaces[p.loc]
		toast(`${p.nation} ${TYPE_LABEL[p.type] || p.type} @ ${sp ? sp.name : "?"}`)
	}
}

function on_focus_space(evt) {
	const s = evt.currentTarget.space_id
	const sp = data.spaces[s]
	if (!sp)
		return
	let text = sp.name
	const attrs = []
	if (sp.terrain === "land") attrs.push("陆地")
	if (sp.terrain === "sea") attrs.push("海域")
	/* 补给点走动态层（可能被卡牌改过 / 仅对某阵营有效） */
	const sd = view && view.supply_by_id && view.supply_by_id[sp.id]
	if (sd) {
		if (sd.axis && sd.allies) attrs.push("★补给点")
		else if (sd.allies) attrs.push("★补给点（仅同盟）")
		else if (sd.axis) attrs.push("★补给点（仅轴心）")
	}
	if (sp.home_base) attrs.push("⌂大本营")
	if (sp.strait) attrs.push("🚧海峡")
	text += "（" + attrs.join(" / ") + "）"
	show_status(text)
}

function on_blur_space() { show_status("") }

function on_focus_piece(evt) {
	const p = (view.pieces || []).find(x => x.id === evt.currentTarget.piece_id)
	if (p)
		show_status(`${p.nation} ${TYPE_LABEL[p.type] || p.type}`)
}

function on_blur_piece() { show_status("") }

function show_status(text) {
	const el = document.getElementById("status")
	if (el)
		el.textContent = text
}

/* 轻量提示（复用 status 栏，避免依赖对话框 API） */
let toast_timer = null
function toast(text) {
	show_status(text)
	clearTimeout(toast_timer)
	toast_timer = setTimeout(() => show_status(""), 3000)
}

/* ============================================================
 * 四、侧栏查询
 * ============================================================ */

function show_straits() {
	const lines = []
	for (const s of view.straits) {
		const c = view.strait_control[s.name]
		lines.push(`${s.name}（${s.a} ↔ ${s.b}）：${c === "axis" ? "轴心国" : "同盟国"}控制`)
	}
	toast(lines.join("　"))
}

/*
 * 查询回复的统一入口（client.js 的 send_query 结果都走这里）。
 *
 * 注意：本文件里【只能有一个】on_reply 定义 ——
 * 函数声明重复定义时后者静默覆盖前者，曾导致 basic_targets 分支永远不执行。
 */
function on_reply(q, params) {
	console.log("[REPLY] on_reply called, q=", q, "params=", params ? JSON.stringify(params).slice(0, 200) : null)
	/* 【2026-10-29】调试卡牌：当前国的牌面目录 */
	if (q === "debug_card_catalog") {
		dbg_catalog = Array.isArray(params) ? params : []
		populate_debug_card_types()   /* 先按真实 type 重建下拉，再渲染 */
		render_debug_cards()
		return
	}
	/* 【2026-10-31】调试手牌视角：本方阵营可选国家 + 当前 override */
	if (q === "debug_view_options") {
		populate_debug_view_nations(params || {})
		return
	}
	if (q === "straits") {
		const txt = (params || []).map(s =>
			`${s.name}: ${s.a} ↔ ${s.b} → ${s.controller === "axis" ? "轴心" : "同盟"}控制`
		).join("　")
		toast(txt)
		return
	}

	if (q === "adjacency") {
		const n = params && ui.selected ? params[data.name_of(ui.selected)] : null
		if (n)
			toast("本方视角相邻：" + n.join("、"))
		else
			toast("请先点选一个格位")
		return
	}

	/* 状态卡"建设预算"候选地区 */
	if (q === 'status_build_spaces') {
		if (!params || params.ok === false) {
			toast((params && params.reason) || '无法获取建设候选地区')
			status_build_pending = false
			return
		}
		status_build_cands = ((params && params.spaces) || []).map(Number)
		highlight_targets({ spaces: status_build_cands.map(id => ({ id: id })) })
		if (status_build_cands.length === 0)
			toast('相邻无合法可建设地区（需空格且未被占用）')
		return
	}

	/* 【2026-10-15】状态卡战斗候选地区（15247 贵在行动：建设地点的相邻地区，含空地） */
	if (q === 'status_battle_spaces') {
		if (!params || params.ok === false) {
			toast((params && params.reason) || '无法获取可攻击地区')
			return
		}
		status_battle_cands = ((params && params.spaces) || []).map(Number)
		highlight_targets({
			spaces: status_battle_cands.map(id => ({ id: id, reason: '可发起陆战（空地为"空打"）' })),
		})
		if (status_battle_cands.length === 0)
			toast('建设地点的相邻地区没有可发起陆战的陆地')
		return
	}

	/* 基本卡的可选目标 */
	if (q === "basic_targets") {
		if (!pending_card)
			return
		pending_targets = params || { spaces: [], pieces: [] }

		/*
		 * 没有合法目标 -> 直接取消选卡并明确提示。
		 * 否则会停在"已进入选目标模式但一个地区都点不了"的状态，
		 * 玩家只能按 Esc 退出，看起来像卡住了（空军力量最容易触发）。
		 */
		const n = (pending_targets.spaces || []).length
		const np = (pending_targets.pieces || []).length
		if (n === 0 && np === 0) {
			const nm = pending_card.name
			/*
			 * 【2026-09-28】例外：打出的是《建设陆军》且桌上有"替换建设"类状态卡
			 * （15341 澳大利亚劳管局 / 15342 印度宣布参战）时，【不要】取消选卡。
			 *
			 * 场景：英国大本营为空、场上无英国陆军 -> 建设陆军没有合法位置。
			 * 但 15341 的语义就是"【放弃】建设，改为在澳大利亚征召陆军"，
			 * 它【不依赖】建设位置的合法性——征召地点是澳大利亚，不是地图上选的位置。
			 * 若这里取消选卡，pending_card 变空，状态卡就再也点不动了
			 * （客户端靠 pending_card 判断"正在建设"）。
			 *
			 * 所以保留 pending_card，并明确提示可以点状态卡替换。
			 * 同时把 ui.build 打开，让 on_click_table_status 能识别"正在建设"。
			 */
			const forgoCards = (view.table_status || []).filter(c =>
				c.forgo_build && c.ready !== true)
			if (nm === "建设陆军" && forgoCards.length) {
				ui.build = true
				update_hand_panel()
				toast("《建设陆军》当前没有合法建设位置，但可点击桌面的《" +
					forgoCards.map(c => c.name).join("》《") +
					"》放弃建设、改为征召（或按 Esc 取消）")
				return
			}
			cancel_basic_card()
			toast("《" + nm + "》当前没有合法目标，无法打出" +
				(pending_mode ? "（模式：" + pending_mode + "）" : ""))
			return
		}

		highlight_targets(pending_targets)
		toast("《" + pending_card.name + "》：可选 " + n + " 个地区" +
			(np ? "，" + np + " 支部队" : "") + "（右键 / Esc 取消）")
		return
	}

	/* 空军阶段②：本国空军 + 合法调度目标（本国补给中的陆/海军所在地） */
	if (q === "air_options") {
		if (!air_move)
			return
		air_move.airs = (params && params.airs) || []
		air_move.targets = (params && params.targets) || []
		/* 【2026-10-30】按空军逐支的合法目标（支持"原地调度"）；旧服务端不带此字段则回退并集 */
		air_move.targetsByAir = (params && params.targets_by_air) || null
		update_air_box()
		toast("调度空军：先点 1 张手牌作为代价，再点空军算子与目标地区")
		return
	}

	/*
	 * 【2026-09-30】多步脚本卡的候选（15229/15239/14503）。
	 * 每次回答后服务端会把 stage 推进，这里【保留】玩家还没提交的本地选择中
	 * 仍然有效的部分，避免多点一次。
	 */
	if (q === "script_state") {
		if (!params) return
		script_state = params
		script_sel = (script_sel || []).filter(id =>
			(params.candidates || []).some(c => c.id === id))
		update_pending_script_box()
		return
	}

	/* 高速公路（15228）：可合法建设陆军地区 -> 高亮，等玩家点地图 */
	if (q === "autobahn_targets") {
		const sps = (params && params.spaces) || []
		const actor = (view.pending_autobahn && view.pending_autobahn.actor) || '德国'
		const title = (actor === '苏联') ? '西伯利亚大铁路' : '高速公路'
		if (!sps.length) {
			autobahn_cands = []
			toast("《" + title + "》当前没有可建设陆军的位置（需处于补给中）")
			return
		}
		/* 【2026-10-20】缓存候选，供 update_map 每帧重贴（见 reapply_all_highlights） */
		autobahn_cands = sps.map(x => x.id)
		highlight_targets({ spaces: sps.map(x => ({ id: x.id, reason: x.name })) })
		toast("请点击一个高亮地区，建设 1 支" + actor + "陆军")
		return
	}

	/* 【2026-10-25】战区移动（17532）：当前步骤的合法目标 -> 缓存 + 高亮 */
	if (q === "theater_targets") {
		const tg = params || {}
		theater_space_cands = null
		theater_piece_cands = null
		const cands = tg.candidates || []
		if (tg.need === 'piece') {
			theater_piece_cands = cands.map(c => c.id)
			if (theater_piece_cands.length)
				highlight_pieces(theater_piece_cands, 'theater')
			else
				toast('《战区移动》当前没有可移除的美国陆军或海军')
		} else if (tg.need === 'space') {
			theater_space_cands = cands.map(c => Number(c.id))
			if (cands.length)
				highlight_targets({ spaces: cands.map(c => ({ id: Number(c.id), reason: c.name })) })
			else
				toast('《战区移动》当前没有可建设的地区')
		}
		return
	}


	/* 资源再分配：牌堆中实际可挑选的基本卡（服务端已按洗牌后的牌堆返回） */
	if (q === "deck_basics") {
		if (!pending_resource)
			return
		pending_resource.basics = params || []
		/* 如果之前选中的那张已经不在牌堆里（被洗到别处等），清掉选择 */
		if (pending_resource.take &&
			!pending_resource.basics.some(c => c.id === pending_resource.take))
			pending_resource.take = null
		update_resource_box()
		return
	}

	/* 资源再分配：弃牌堆中可搜寻的基本卡（17551 战时国债） */
	if (q === "discard_basics") {
		if (!pending_resource)
			return
		pending_resource.discardBasics = params || []
		if (pending_resource.take_discard &&
			!pending_resource.discardBasics.some(c => c.id === pending_resource.take_discard))
			pending_resource.take_discard = null
		update_resource_box()
		return
	}

	/* 战斗第一步：可选的本国发起单位（陆/海军，空军不在其中） */
	if (q === "battle_initiators") {
		if (!battle_flow)
			return
		show_initiator_choices(params || [])
		return
	}

	/* 夺取制空权第一步：可选的本国发起飞机（seize 模式，空军版 battle_initiators） */
	if (q === "air_initiators") {
		if (!battle_flow)
			return
		show_initiator_choices(params || [])
		return
	}

	/*
	 * ---------- EVENT / ECHO 卡的目标查询（2026-09-25）----------
	 *
	 * 客户端打出事件/增强卡前，先查 event_targets 看需要什么：
	 *   need=null     -> 直接打出
	 *   need='choice' -> 弹选择按钮
	 *   need='space'  -> 高亮地图地区让玩家点
	 */
	if (q === "event_targets") {
		if (!pending_event_card)
			return
		const tg = params
		if (!tg) {
			/* 无配置 -> 直接打出 */
			lend_play_action({ card: pending_event_card.id })
			pending_event_card = null
			return
		}
		/*
		 * 【2026-10-06】多步脚本卡（德 15229/15239/14503、日 7900 竭泽而渔）。
		 * 代价与选择都在服务端 pending_script 的【各阶段里】完成，
		 * 客户端直接 play_card 交出去，脚本机会自己弹选牌框 ——
		 * 若在这里再弹"选 N 张弃牌"框，玩家会白选一次（脚本还会再问一遍）。
		 */
		if (tg.need === "script") {
			const nm = pending_event_card.name
			lend_play_action({ card: pending_event_card.id })
			toast("打出《" + nm + "》")
			pending_event_card = null
			return
		}
		/*
		 * 【2026-10-06】一步式：弃 N 张 + 同时指定要打出的那张
		 * （15412 御前会议 —— 复用日本国家技能的一步式弹窗）。
		 */
		if (tg.need === "one_step_pick") {
			start_one_step_picker({
				need: (tg.cost && tg.cost.discard) || 1,
				filter: (tg.cost && tg.cost.filter) || null,
				desc: tg.desc || '',
				source_name: pending_event_card.name,
				one_step: true,
				play_filter: (tg.play && tg.play.filter) || null,
				submit_action: 'play_card',
				submit_card: pending_event_card.id,
			})
			return
		}
		/*
		 * 【2026-10-06】选 1 支部队（15411 夜间运输：选 1 支无补给的）。
		 * 与 need:'space' 同构：有弃牌代价就先弹代价框，再高亮算子。
		 */
		if (tg.need === "piece") {
			if (tg.cost && tg.cost.discard > 0) {
				pending_echo_discard = {
					card: pending_event_card,
					need_targets: tg,
					drop: [],
					limit: tg.cost.discard,
					filter: (tg.cost && tg.cost.filter) || null,
				}
				update_echo_discard_box()
				return
			}
			pending_event_targets = tg
			highlight_event_pieces(tg)
			return
		}
		if (tg.need === null) {
			/*
			 * 【2026-09-28 修复】单候选卡（15312 华沙起义 = 只有<东欧>）
			 * 服务端返回 need:null。若它【有弃牌代价】，仍须先让玩家自选要弃的牌，
			 * 否则会走下面"直接打出"分支 -> 服务端自动 slice(0,cost) 弃掉前 N 张
			 * （玩家没得选，即"自选弃牌未实现"）。
			 *
			 * 注意 need_targets 置为 null：表示【不需要再选地区】，
			 * confirm_echo_discard 会据此直接提交而不是去高亮地图。
			 */
			if (tg.cost && tg.cost.discard > 0) {
				pending_echo_discard = {
					card: pending_event_card,
					need_targets: null,
					drop: [],
					limit: tg.cost.discard,
					/* 【2026-10-06】代价限定牌类型（日本："弃置 1 张【响应卡】"） */
					filter: (tg.cost && tg.cost.filter) || null,
				}
				update_echo_discard_box()
				return
			}
			/*
			 * 【2026-09-29】多步卡：need 为 null 说明"所有步骤都选齐了"，
			 * 此时必须把累积的 spaces 一起提交，否则服务端拿不到各步地区
			 * （15325 会退回"自动取候选"甚至失败）。
			 */
			const arg = { card: pending_event_card.id }
			if (pending_event_spaces && pending_event_spaces.length) {
				arg.spaces = pending_event_spaces.slice()
				const one = pending_event_spaces.find(x => x != null)
				if (one != null) arg.space = one
			}
			/*
			 * 【2026-10-21】与 spaces 同款：多步卡最终提交必须带上累积的 pieces，
			 * 否则服务端 op:'remove' 读不到要移除的部队。
			 */
			if (pending_event_pieces && pending_event_pieces.length) {
				arg.pieces = pending_event_pieces.slice()
				const one = pending_event_pieces.find(x => x != null)
				if (one != null) arg.piece = one
			}
			if (pending_event_choice != null)
				arg.choice = pending_event_choice
			lend_play_action(arg)
			toast("打出《" + pending_event_card.name + "》")
			/*
			 * 【2026-10-22】必须走统一清理：只置空 pending_event_card 会把
			 * pending_event_targets（need:'piece'）留成脏状态，下一帧 update_map
			 * 重贴高亮时 highlight_event_pieces 读到 null.name 直接抛
			 * "Cannot read properties of null (reading 'name')"（17825 多步完成后必现）。
			 */
			cancel_event_card()
			return
		}
		/*
		 * 【2026-09-25 新增】peek_reorder 类型：需要玩家选排序顺序。
		 *
		 * 【2026-09-25 bug 修复】query 是只读 RPC，服务端写 game.peek
		 * 后 view 不会广播——所以客户端不能依赖 view.peek 弹框。
		 *
		 * 正确做法：query 返回的 tg.cards 就是挑出的对手手牌 id，
		 * 客户端【自己】弹排序 UI，记录 pending_peek_for_card + peek_order。
		 * 玩家点【确认顺序】后 submit_peek 用 peek_order 构造 send_action。
		 */
		if (tg.need === "peek_reorder") {
			pending_peek_for_card = pending_event_card
			/*
			 * 【2026-09-25 bug 修复】tg.cards 是卡对象数组（含 id/name/type），
			 * 不是裸 id——服务端 query 出口已转好。
			 * peek_cards 直接存卡对象数组，update_peek_box 直接渲染。
			 */
			peek_cards = tg.cards.slice()
			peek_target = tg.target
			peek_order = []
			update_peek_box()
			toast("《" + pending_event_card.name + "》：观看 " + tg.target +
				" 手牌，按指定顺序置于其牌堆顶")
			return
		}
		if (tg.need === "choice") {
			show_event_choice(tg)
			return
		}
		if (tg.need === "space") {
			/*
			 * 【2026-09-25 新增】若卡片要求弃 N 张手牌作为代价，
			 * 先弹"选 N 张弃牌"框，玩家确认后再高亮地区选空间。
			 * 否则直接高亮地区（无代价的 ECHO/EVENT 卡）。
			 */
			if (tg.cost && tg.cost.discard > 0) {
				pending_echo_discard = {
					card: pending_event_card,
					need_targets: tg,
					drop: [],
					limit: tg.cost.discard,
					/*
					 * 【2026-10-06】代价限定牌类型（日本增强卡："弃置 1 张【响应卡】"）。
					 * filter 由服务端下发（tg.cost.filter），客户端不写死国家/卡。
					 */
					filter: (tg.cost && tg.cost.filter) || null,
				}
				update_echo_discard_box()
				return
			}
			pending_event_targets = tg
			highlight_event_targets(tg)
			return
		}
		/* 兜底 */
		lend_play_action({ card: pending_event_card.id })
		pending_event_card = null
		return
	}
}

/* ============================================================
 * 五、调试面板（验证连通性用）
 * ============================================================ */

let debug_seq = 0

function toggle_debug() {
	const el = document.getElementById("debug_panel")
	if (!el)
		return
	/* 【2026-10-29】三个调试面板互斥（与 toggle_debug_cards 一致） */
	close_other_debug_panels("debug_panel")
	el.classList.toggle("hide")
	document.body.classList.toggle("debug", !el.classList.contains("hide"))
	if (el.classList.contains("hide")) {
		ui.debug_mode = null
		document.querySelectorAll("#debug_panel button").forEach(b => b.classList.remove("on"))
	}
}

function debug_place_mode() {
	ui.debug_mode = ui.debug_mode === "place" ? null : "place"
	document.getElementById("dbg_place_btn").classList.toggle("on", ui.debug_mode === "place")
	document.getElementById("dbg_remove_btn").classList.remove("on")
	set_debug_hint(ui.debug_mode === "place" ? "请点击地图上的格位放置部队" : "")
}

function debug_remove_mode() {
	ui.debug_mode = ui.debug_mode === "remove" ? null : "remove"
	document.getElementById("dbg_remove_btn").classList.toggle("on", ui.debug_mode === "remove")
	document.getElementById("dbg_place_btn").classList.remove("on")
	set_debug_hint(ui.debug_mode === "remove" ? "请点击地图上的部队移除" : "")
}

function debug_do_place(space_id) {
	const nation = document.getElementById("dbg_nation").value
	const type = document.getElementById("dbg_type").value
	const sp = data.spaces[space_id]
	if (!sp)
		return

	/* 校验：陆军只能放陆地，海军只能放海域 */
	if (type === "army" && sp.terrain !== "land") {
		set_debug_hint("陆军只能放在陆地")
		return
	}
	if (type === "navy" && sp.terrain !== "sea") {
		set_debug_hint("海军只能放在海域")
		return
	}

	const piece = `dbg_${++debug_seq}`
	send_action("debug_place", { piece: piece, nation: nation, type: type, space: space_id })
	set_debug_hint(`${nation}${TYPE_LABEL[type]} → ${sp.name}`)
}

function debug_clear() {
	send_action("debug_clear", {})
	set_debug_hint("已清空全部部队")
}

/* 结算当前行动国的断补部队 */
function debug_resolve_supply() {
	const n = view.current_nation
	if (!n) {
		set_debug_hint("未指定行动国")
		return
	}
	const before = (view.supply && view.supply.by_nation[n]) || { total: 0, ok: 0 }
	const bad = before.total - before.ok
	send_action("resolve_supply", { nation: n })
	set_debug_hint(`结算【${n}】补给：断补 ${bad} 个将被移除`)
}

/* 轮转到下一个行动国（德→英→日→苏→意→美） */
function debug_next_nation() {
	send_action("next_nation", {})
	const list = view.order_of_nations || []
	const i = list.indexOf(view.current_nation)
	set_debug_hint("行动国 → " + (list[(i + 1) % list.length] || "?"))
}

function set_debug_hint(text) {
	const el = document.getElementById("dbg_hint")
	if (el)
		el.textContent = text
}

/* ============================================================
 * 【2026-10-29】调试：卡牌 / 阶段（与「调试单位」并列的两个面板）
 * ============================================================ */

/* 面板右上角的 × 关闭按钮（三个调试面板通用） */
function close_debug_panel(id) {
	const el = document.getElementById(id)
	if (!el) return
	el.classList.add("hide")
	document.querySelectorAll("#" + id + " button").forEach(b => b.classList.remove("on"))
	if (id === "debug_panel") {
		ui.debug_mode = null
		set_debug_hint("")
	}
	/* 三个面板都收起时，退出 debug 布局模式 */
	const anyOpen = ["debug_panel", "debug_card_panel", "debug_phase_panel", "debug_view_panel"]
		.some(x => {
			const e = document.getElementById(x)
			return e && !e.classList.contains("hide")
		})
	if (!anyOpen) document.body.classList.remove("debug")
}

/* 三个调试面板互斥：打开一个就把另外两个收起来，避免叠在左下角 */
/*
 * 【2026-10-31】调试：手牌视角。
 *
 * 用途：本方阵营有多国（同盟 英/法/美/苏/中、轴心 德/意/日），
 * 非自己回合时手牌区默认只显示"本阵营排最前"的国家；这里可以让它固定显示某一国的手牌，
 * 便于本地调试/试玩时查看另一国的手牌。
 *
 * 服务端：game.debug_view_nation[side]（只作用于 view 的【兜底】分支，
 * 即"没有任何窗口/让权在等我"的静置状态，不会覆盖正在等表态的国家）。
 */
function toggle_debug_view() {
	const el = document.getElementById("debug_view_panel")
	if (!el) return
	const willOpen = el.classList.contains("hide")
	close_other_debug_panels("debug_view_panel")
	el.classList.toggle("hide", !willOpen)
	document.body.classList.toggle("debug", willOpen)
	if (!willOpen) return
	set_dbg_view_hint("")
	/* 国家列表由服务端按阵营给（客户端不硬编码阵营归属） */
	send_query("debug_view_options")
}

function set_dbg_view_hint(text) {
	const el = document.getElementById("dbg_view_hint")
	if (el) el.textContent = text
}

function populate_debug_view_nations(data) {
	const sel = document.getElementById("dbg_view_nation")
	if (!sel) return
	sel.innerHTML = ""
	const list = (data && data.nations) || []
	list.forEach(x => {
		const o = document.createElement("option")
		o.value = x.nation
		o.textContent = x.nation + "（手牌 " + (x.cards || 0) + " 张）"
		sel.appendChild(o)
	})
	const cur = (data && data.current) || (data && data.my_nation) || ""
	if (cur && list.some(x => x.nation === cur)) sel.value = cur
	const dflt = (data && data.default_nation) || ""
	const sideZh = (data && data.side) === "allies" ? "同盟" : "轴心"
	set_dbg_view_hint(data && data.current
		? ("当前固定为【" + data.current + "】（" + sideZh + "）")
		: ("当前为默认：" + sideZh + " 显示【" + (dflt || "—") + "】"))
}

function debug_do_set_view(reset) {
	const sel = document.getElementById("dbg_view_nation")
	if (reset) {
		send_action("debug_set_view_nation", { nation: null })
		set_dbg_view_hint("已恢复默认（按回合/窗口自动切换）")
		return
	}
	const nation = sel ? sel.value : ""
	if (!nation) {
		set_dbg_view_hint("请选择国家")
		return
	}
	send_action("debug_set_view_nation", { nation: nation })
	set_dbg_view_hint("已固定为【" + nation + "】（静置时生效）")
}

function close_other_debug_panels(keep) {
	["debug_panel", "debug_card_panel", "debug_phase_panel", "debug_view_panel"].forEach(id => {
		if (id === keep) return
		const el = document.getElementById(id)
		if (el && !el.classList.contains("hide")) el.classList.add("hide")
	})
}

let dbg_catalog = null

function toggle_debug_cards() {
	const el = document.getElementById("debug_card_panel")
	if (!el) return
	const willOpen = el.classList.contains("hide")
	close_other_debug_panels("debug_card_panel")
	el.classList.toggle("hide", !willOpen)
	document.body.classList.toggle("debug", willOpen)
	if (!willOpen) return
	const nation = (view && view.current_nation) || ""
	const lab = document.getElementById("dbg_card_nation")
	if (lab) lab.textContent = "当前国家：" + (nation || "—")
	dbg_catalog = null
	const grid = document.getElementById("dbg_card_grid")
	if (grid) grid.innerHTML = ""
	set_dbg_card_hint("正在加载牌面…")
	/* 只拉【当前行动国】的牌面（服务端按 nation 过滤） */
	send_query("debug_card_catalog", { nation: nation })
}

function set_dbg_card_hint(text) {
	const el = document.getElementById("dbg_card_hint")
	if (el) el.textContent = text
}

/*
 * 【2026-10-29 修复】类型下拉按【目录里真实出现的 type】动态生成。
 * 起因：面板原先写死 `<option value="ECHO">增强卡</option>`，但卡库里的增强卡
 * type 是 "EFFECT"（view.card_types 也只有 EFFECT/EVENT/ECON/… 八种），
 * 于是「增强卡」筛选恒为空（德国 13 张增强卡全看不到）。
 * 现在只列该国真实存在的类型，标签取 view.card_types[t].zh，并附带张数。
 */
const DBG_TYPE_ORDER = ["BASIC", "EVENT", "EFFECT", "RESPONSE", "ECON",
	"STATUS", "PRELUDE", "ARMAMENT"]
function populate_debug_card_types() {
	const sel = document.getElementById("dbg_card_type")
	if (!sel || !dbg_catalog) return
	const prev = sel.value || ""
	const count = {}
	dbg_catalog.forEach(c => { count[c.type] = (count[c.type] || 0) + 1 })
	const types = Object.keys(count).sort((a, b) => {
		const ia = DBG_TYPE_ORDER.indexOf(a), ib = DBG_TYPE_ORDER.indexOf(b)
		return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib)
	})
	const zhOf = t => {
		const m = (view && view.card_types) || {}
		return (m[t] && m[t].zh) || t
	}
	sel.innerHTML = ""
	const all = document.createElement("option")
	all.value = ""
	all.textContent = "全部（" + dbg_catalog.length + "）"
	sel.appendChild(all)
	types.forEach(t => {
		const o = document.createElement("option")
		o.value = t
		o.textContent = zhOf(t) + "（" + count[t] + "）"
		sel.appendChild(o)
	})
	/* 保留原选择；若该类型这次不存在则回落到全部 */
	sel.value = types.indexOf(prev) >= 0 ? prev : ""
}

function render_debug_cards() {
	const grid = document.getElementById("dbg_card_grid")
	if (!grid) return
	grid.innerHTML = ""
	if (!dbg_catalog) return
	const tyEl = document.getElementById("dbg_card_type")
	const kwEl = document.getElementById("dbg_card_kw")
	const ty = tyEl ? tyEl.value : ""
	const kw = kwEl ? (kwEl.value || "").trim() : ""
	const list = dbg_catalog.filter(c =>
		(!ty || c.type === ty) &&
		(!kw || (c.name || "").indexOf(kw) >= 0 || (c.text || "").indexOf(kw) >= 0))
	const destEl = document.getElementById("dbg_card_dest")
	const dest = destEl ? destEl.value : "hand"
	const DEST_ZH = { hand: "手牌", deck_top: "牌库顶", deck_bottom: "牌库底", discard: "弃牌堆" }
	list.forEach(c => {
		grid.appendChild(card_elt(c, () => {
			send_action("debug_add_card", {
				face: c.face,
				nation: (view && view.current_nation) || undefined,
				dest: dest,
			})
			set_dbg_card_hint("已加入" + (DEST_ZH[dest] || "手牌") + "：《" + c.name + "》")
		}))
	})
	set_dbg_card_hint("共 " + list.length + " 张（点卡图加入手牌）")
}

function toggle_debug_phase() {
	const el = document.getElementById("debug_phase_panel")
	if (!el) return
	const willOpen = el.classList.contains("hide")
	close_other_debug_panels("debug_phase_panel")
	el.classList.toggle("hide", !willOpen)
	document.body.classList.toggle("debug", willOpen)
	if (!willOpen) return
	const sel = document.getElementById("dbg_phase_nation")
	if (sel && view && view.current_nation) sel.value = view.current_nation
	set_dbg_phase_hint("")
}

function set_dbg_phase_hint(text) {
	const el = document.getElementById("dbg_phase_hint")
	if (el) el.textContent = text
}

function debug_do_set_phase() {
	const nEl = document.getElementById("dbg_phase_nation")
	const pEl = document.getElementById("dbg_phase_key")
	const nation = nEl ? nEl.value : ""
	const phase = pEl ? pEl.value : ""
	if (!nation || !phase) {
		set_dbg_phase_hint("请选择国家与阶段")
		return
	}
	const zh = pEl && pEl.selectedIndex >= 0 ? pEl.options[pEl.selectedIndex].text : phase
	if (!window.confirm("清空所有挂起状态，并把对局直接推到【" + nation + "·" + zh +
		"】？\n（进入该阶段的入口逻辑会真的执行：补给会移除断补部队、计分会结算、抓牌会摸牌）"))
		return
	send_action("debug_set_phase", { nation: nation, phase: phase })
	set_dbg_phase_hint("已跳转：" + nation + " · " + zh)
}

/* ============================================================
 * 六、启动
 * ============================================================ */

/* 地图构建不依赖 view，可以立刻做（client.js 会在拿到 state 后调 on_update） */
if (document.readyState === "loading")
	document.addEventListener("DOMContentLoaded", build_map)
else
	build_map()

/*
 * 【2026-09-29】"各国牌库"按钮：等 DOM 就绪后再绑（元素在 play.html 里）。
 *
 * 为什么要 setTimeout 兜底重试：客户端脚本可能被 client.js 【早于】
 * play.html 解析完成就执行（本文件顶部还有 build_map 的 readyState 分支），
 * 此时 getElementById 拿到 null，按钮就永远绑不上（表现为"按钮不显示/点了没反应"）。
 * 绑成功后用 once 标记避免重复绑定。
 */
let deck_toggle_bound = false
function bind_deck_toggle() {
	if (deck_toggle_bound) return true
	const btn = document.getElementById("deck_toggle")
	if (!btn) return false
	btn.addEventListener("click", (ev) => {
		ev.stopPropagation()
		toggle_deck_panel()
	})
	deck_toggle_bound = true
	update_deck_panel()
	return true
}
function bind_deck_toggle_when_ready(tries) {
	if (bind_deck_toggle()) return
	if ((tries || 0) > 40) return          /* 约 8 秒后放弃，避免无限重试 */
	setTimeout(function () { bind_deck_toggle_when_ready((tries || 0) + 1) }, 200)
}
bind_deck_toggle_when_ready(0)

/* 【2026-10-18】各国后备按钮绑定（与 deck_toggle 同套 when_ready 重试） */
let reserve_toggle_bound = false
function bind_reserve_toggle() {
	if (reserve_toggle_bound) return true
	const btn = document.getElementById("reserve_toggle")
	if (!btn) return false
	btn.addEventListener("click", (ev) => {
		ev.stopPropagation()
		toggle_reserve_panel()
	})
	reserve_toggle_bound = true
	update_reserve_panel()
	return true
}
function bind_reserve_toggle_when_ready(tries) {
	if (bind_reserve_toggle()) return
	if ((tries || 0) > 40) return
	setTimeout(function () { bind_reserve_toggle_when_ready((tries || 0) + 1) }, 200)
}
bind_reserve_toggle_when_ready(0)
