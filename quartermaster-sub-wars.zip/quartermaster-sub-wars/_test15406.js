const rules = require('./rules.js')
const I = rules._internal
const { data } = require('./data.js')

const SEA = 40
function fresh() {
  const g = rules.setup('t-15406-' + Math.random(), 'Standard', {})
  g.location['jp_air'] = SEA;  g.piece_nation['jp_air'] = '日本';  g.piece_type['jp_air'] = 'air'
  g.location['jp_navy'] = SEA; g.piece_nation['jp_navy'] = '日本'; g.piece_type['jp_navy'] = 'navy'
  g.hands['日本'] = ['15406#1', '7902#1', '7902#2']
  return g
}
const ctx = { space: SEA, nation: '日本', card_id: '15406' }
const armed = I.ECHO_EFFECTS['15406'].armed

// 场景A：菲律宾(23)有美军陆军（occupied），另找一块相邻且【无任何棋子】的陆地做空打目标
const LAND_OCC = 23
let emptyLand = null
for (const nb of (data.spaces[SEA].connections || [])) {
  if (data.spaces[nb] && data.spaces[nb].terrain === 'land') { emptyLand = nb; break }
}
const gA = fresh()
gA.location['us_army'] = LAND_OCC; gA.piece_nation['us_army'] = '美国'; gA.piece_type['us_army'] = 'army'
// 清掉 emptyLand 上的初始棋子，确保它是空白地块
for (const p of Object.keys(gA.location)) if (Number(gA.location[p]) === Number(emptyLand)) delete gA.location[p]
console.log('空打空白地块 =', emptyLand, data.name_of(emptyLand))

const rA = armed.run(gA, ctx, { choice: 'land' })
console.log('[choice=land] need=', rA.need, '| candidates(敌方单位)=', JSON.stringify(rA.candidates), '| spaceCandidates(空白地块)=', JSON.stringify(rA.spaceCandidates))
const okCombined = rA.need === 'piece' && (rA.candidates || []).includes('us_army') && (rA.spaceCandidates || []).map(Number).includes(Number(emptyLand))
console.log('同时下发敌方单位+空白地块?', okCombined)

// 场景A2：选空白地块 -> 空打（不应移除任何单位）
const gA2 = fresh()
gA2.location['us_army'] = LAND_OCC; gA2.piece_nation['us_army'] = '美国'; gA2.piece_type['us_army'] = 'army'
for (const p of Object.keys(gA2.location)) if (Number(gA2.location[p]) === Number(emptyLand)) delete gA2.location[p]
const rA2 = armed.run(gA2, ctx, { choice: 'land', space: emptyLand })
console.log('[空打 空白地块] ->', JSON.stringify(rA2))
console.log('空打后 us_army 仍在?', gA2.location['us_army'] === LAND_OCC, '（应 true，空打不移除）')

// 场景B：全空（相邻陆地都无敌军）-> need:'space'
const gB = fresh()
for (const p of Object.keys(gB.location)) { const sp = Number(gB.location[p]); if (sp !== SEA && data.spaces[sp] && data.spaces[sp].terrain === 'land') delete gB.location[p] }
const rB = armed.run(gB, ctx, { choice: 'land' })
console.log('[全空] need=', rB.need, 'candidates=', JSON.stringify(rB.candidates))

// 场景C：完整 action 链（选空白地块空打）
const gC = fresh()
gC.location['us_army'] = LAND_OCC; gC.piece_nation['us_army'] = '美国'; gC.piece_type['us_army'] = 'army'
for (const p of Object.keys(gC.location)) if (Number(gC.location[p]) === Number(emptyLand)) delete gC.location[p]
I.offer_armed_effects(gC, 'after_deploy_air', { space: SEA, nation: '日本' })
rules.action(gC, 'Axis', 'use_armed_offer', { card: '15406#1', drop: ['7902#1'] })
rules.action(gC, 'Axis', 'use_armed_offer', { card: '15406#1', choice: 'land' })
rules.action(gC, 'Axis', 'use_armed_offer', { card: '15406#1', space: emptyLand })
console.log('\n[action 空打链] 弃7902#1?', (gC.discard['日本']||[]).includes('7902#1'), '| 15406离手?', !(gC.hands['日本']||[]).includes('15406#1'), '| us_army未动?', gC.location['us_army'] === LAND_OCC)
