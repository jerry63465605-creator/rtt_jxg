"use strict"
/* 临时验证：15211 授予的 [北方行动] 额外打出 —— 计分阶段能真正打出 15249(STATUS) */
const fs = require('fs')
let src = fs.readFileSync('rules.js', 'utf8')
src = src.replace(/(?<!function )build_map\(\)/g, 'void 0')
src += '\n;globalThis.__T = exports;'
eval(src)
const T = globalThis.__T
let pass = 0, fail = 0
function check(n, c, e) {
	if (c) { pass++; console.log('  PASS  ' + n) }
	else { fail++; console.log('  FAIL  ' + n + (e ? '  << ' + e : '')) }
}

function mk() {
	const g = T.setup(1)
	g.current_nation = '德国'
	g.active = 'Axis'
	g.turn = 3
	g.opening = null
	g.play_done = { 德国: true, 英国: true, 日本: true, 苏联: true, 意大利: true, 美国: true }
	g.hands['德国'] = ['15211#1', '15249#1', '15301#1', '15302#1', '15303#1']
	g.discard['德国'] = []
	g.table['德国'] = []
	g.decks['苏联'] = ['15401#1', '15402#1', '15403#1', '15404#1', '15405#1']
	g.score.axis = 0
	g.status_used = {}
	g.armed_offers = []
	g.armed_offer = null
	g.echo_intercept_skipped = {}
	return g
}

/* 完整流程：计分阶段 -> 15211 窗口 -> 打出 15211 -> 用额外打出打 15249 */
function play15211(g) {
	g.turn_phase = 'scoring'
	T.action(g, 'Axis', 'use_armed_offer', { card: '15211#1' })
}

console.log('=== ① 计分阶段：打出 15211 -> 拿到 [北方行动] 额外打出 ===')
{
	const g = mk()
	g.turn_phase = 'scoring'
	/* 手动派发窗口（等价 phase_scoring 入口） */
	T._internal.offer_armed_effects
		? T._internal.offer_armed_effects(g, 'scoring_north', { nation: '德国' })
		: null
	if (!(g.armed_offers || []).length) {
		/* 未导出时直接授予，等价 15211 run 的效果 */
		T._internal.grant_extra_play(g, '德国', '15211', '威瑟堡行动',
			{ filter: 'north', phase: 'scoring' })
	} else {
		play15211(g)
	}
	console.log('  extra_play =', JSON.stringify(g.extra_play))
	console.log('  turn_phase =', g.turn_phase)
	check('持有额外打出权（filter=north, phase=scoring）',
		!!g.extra_play && g.extra_play.filter === 'north' && g.extra_play.phase === 'scoring')

	/* 关键：此刻 check_phase_for_card 对 15249 应放行 */
	const card49 = (require('./cards.js').CARDS || require('./cards.js')).find(c => c.id === 15249)
	const r = T._internal.check_phase_for_card(g, '德国', card49, { card: '15249#1' })
	console.log('  check_phase_for_card(15249) =', JSON.stringify(r))
	check('15249 通过阶段校验', r.ok, r.reason)
	check('标记为额外打出（不占名额）', r.ok && r.extra === true)

	/* 真打：15249 应离开手牌、进入桌面 */
	T.action(g, 'Axis', 'play_card', { card: '15249#1' })
	console.log('  手牌 =', JSON.stringify(g.hands['德国']))
	console.log('  桌面 =', JSON.stringify(g.table['德国']))
	check('15249 离手', (g.hands['德国'] || []).indexOf('15249#1') < 0)
	check('15249 进入桌面（真实打出）', (g.table['德国'] || []).indexOf('15249#1') >= 0)
	check('额外打出权已消耗', !g.extra_play)
	console.log('  日志尾：' + g.log.slice(-2).join(' | '))
}

console.log('')
console.log('=== ② 对照：没有 15211 授权时，计分阶段打 15249 应被拒（阶段限制仍在）===')
{
	const g = mk()
	g.turn_phase = 'scoring'
	g.extra_play = null
	const card49 = (require('./cards.js').CARDS || require('./cards.js')).find(c => c.id === 15249)
	const r = T._internal.check_phase_for_card(g, '德国', card49, { card: '15249#1' })
	console.log('  check_phase_for_card(15249) =', JSON.stringify(r))
	check('无授权 -> 拒绝', !r.ok, JSON.stringify(r))
}

console.log('')
console.log('=== ③ 出牌阶段权利不会因此在计分阶段放行（has_extra_play 的 phase 校验仍生效）===')
{
	const g = mk()
	g.turn_phase = 'scoring'
	/* 模拟德国国家技能：出牌阶段授予的 status 额外打出 */
	g.extra_play = { nation: '德国', source: 'x', source_name: '德国国家技能',
		filter: 'status', cards: null, count: 1, turn: g.turn, phase: 'play' }
	const card49 = (require('./cards.js').CARDS || require('./cards.js')).find(c => c.id === 15249)
	const r = T._internal.check_phase_for_card(g, '德国', card49, { card: '15249#1' })
	console.log('  check_phase_for_card(15249) =', JSON.stringify(r))
	check('出牌阶段权利在计分阶段仍被拒', !r.ok, JSON.stringify(r))
}

console.log('')
console.log('=== ④ ECON 15224 也应能跨阶段用这条权利打出 ===')
{
	const g = mk()
	g.turn_phase = 'scoring'
	g.extra_play = { nation: '德国', source: '15211', source_name: '威瑟堡行动',
		filter: 'north', cards: null, count: 1, turn: g.turn, phase: 'scoring' }
	g.hands['德国'] = ['15224#1', '15301#1']
	const card24 = (require('./cards.js').CARDS || require('./cards.js')).find(c => c.id === 15224)
	const r = T._internal.check_phase_for_card(g, '德国', card24, { card: '15224#1' })
	console.log('  check_phase_for_card(15224) =', JSON.stringify(r))
	check('15224(ECON) 通过', r.ok && r.extra === true, JSON.stringify(r))
}

console.log('')
console.log('=== 总结论 === ' + (fail === 0 ? 'ALL PASS' : fail + ' 项失败') +
	'（' + pass + '/' + (pass + fail) + '）')
process.exit(fail === 0 ? 0 : 1)
