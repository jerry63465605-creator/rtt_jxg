"use strict"
const fs = require('fs')
const path = require('path')
let src = fs.readFileSync(path.join(__dirname, 'rules.js'), 'utf8')
src = src.replace(/(?<!function )build_map\(\)/g, 'void 0')
src += '\n;globalThis.__T = { setup: exports.setup, grant_extra_play, check_phase_for_card, CARD_BY_ID, has_extra_play };'
eval(src)
const T = globalThis.__T

const g = T.setup('seed-15211', 'Standard', {})
g.turn = 5
g.turn_phase = 'scoring'

/* 模拟 15211 armed run 的授予（与修复后代码同参） */
T.grant_extra_play(g, '德国', '15211', '威瑟堡行动',
	{ filter: 'north', phase: g.turn_phase || 'play' })

const card = T.CARD_BY_ID['15220']
const r = T.check_phase_for_card(g, '德国', card, {})
console.log('[修复后] 计分阶段额外打出 15220 =>', JSON.stringify(r),
	'has_extra_play=', T.has_extra_play(g, '德国'),
	'=> ' + (r.ok && r.extra && T.has_extra_play(g, '德国') ? 'PASS' : 'FAIL'))

/* 反例：授予时 phase 仍是旧缺省 'play'，在计分阶段应打不出（复现原 bug） */
const g2 = T.setup('seed-15211-old', 'Standard', {})
g2.turn = 5
g2.turn_phase = 'scoring'
T.grant_extra_play(g2, '德国', '15211', '威瑟堡行动', { filter: 'north' })
const r2 = T.check_phase_for_card(g2, '德国', card, {})
console.log('[旧缺省对照] =>', r2.ok ? '意外放行' : '拒绝（复现原 bug）: ' + r2.reason)
