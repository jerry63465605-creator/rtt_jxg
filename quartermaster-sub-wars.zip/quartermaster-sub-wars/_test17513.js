const rules = require('./rules.js')

/*
 * 17513 战时生产委员会：美国回合内【任意阶段】可打，但前置 = 美国桌面已有
 * 【本回合已发动】的[状态卡]（freq_key = turn:current_nation）。
 * 覆盖：场景A 任意阶段(空军阶段)+已有已发动 -> 可打并重置/损耗；
 *       场景B 无本回合已发动的状态卡 -> 打不出（挂起不建、牌留手牌）。
 */
function fresh(phase, markUsed) {
	const g = rules.setup('t-17513', 'Standard', {})
	g.turn_phase = phase
	g.current_nation = '美国'
	g.active = 'Allies'
	g.hands['美国'] = ['17513#1']
	g.table['美国'] = ['17553#1']          // 一张美国桌面[状态卡]
	g.status_used = markUsed ? { '17553#1': g.turn + ':' + '美国' } : {}
	return g
}

// 场景A：美国回合、非出牌阶段(空军阶段)、已有本回合已发动状态卡 -> 应可打
{
	const g = fresh('airforce', true)
	const deckBefore = (g.decks['美国'] || []).length
	rules.action(g, 'Allies', 'play_card', { card: '17513#1' })
	const okPlay = g.us_wartime != null
	const v = rules.view(g, 'Allies')
	const hasCand = v.us_wartime && (v.us_wartime.candidates || []).some(c => c.id === '17553#1')
	rules.action(g, 'Allies', 'resolve_us_wartime', { card: '17553#1' })
	const okReset = g.status_used['17553#1'] === undefined
	const okDiscard = (g.discard['美国'] || []).includes('17513#1')
	const okAttrite = (g.decks['美国'] || []).length === deckBefore - 1
	const okCleared = g.us_wartime == null
	console.log('场景A(任意阶段+已有已发动,应可打): 挂起?', okPlay, '候选含17553?', hasCand,
		'| 重置?', okReset, '| 入弃堆?', okDiscard, '| 损耗1?', okAttrite, '| 清除?', okCleared,
		'=>', (okPlay && hasCand && okReset && okDiscard && okAttrite && okCleared) ? 'PASS' : 'FAIL')
}

// 场景B：美国回合、但无本回合已发动的状态卡 -> 应打不出(前置不满足)
{
	const g = fresh('play', false)
	rules.action(g, 'Allies', 'play_card', { card: '17513#1' })
	const okReject = g.us_wartime == null
	const okStillHand = (g.hands['美国'] || []).includes('17513#1')
	console.log('场景B(无已发动,应拒): 未挂起?', okReject, '| 仍在手牌?', okStillHand,
		'=>', (okReject && okStillHand) ? 'PASS' : 'FAIL',
		'\n  log尾:', JSON.stringify((g.log || []).slice(-2)))
}

// 场景C：非美国(轴心)回合，美国手里有 17513 -> action 入口 is_my_turn 应拦下，打不出
{
	const g = fresh('play', true)
	g.current_nation = '日本'
	g.active = 'Axis'
	rules.action(g, 'Axis', 'play_card', { card: '17513#1' })
	const okReject = g.us_wartime == null
	const okStillHand = (g.hands['美国'] || []).includes('17513#1')
	console.log('场景C(非本方回合,应拦): 未挂起?', okReject, '| 仍在手牌?', okStillHand,
		'=>', (okReject && okStillHand) ? 'PASS' : 'FAIL')
}
