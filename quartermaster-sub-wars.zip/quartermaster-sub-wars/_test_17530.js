"use strict"
const fs = require('fs')
const path = require('path')
let src = fs.readFileSync(path.join(__dirname, 'rules.js'), 'utf8')
src = src.replace(/(?<!function )build_map\(\)/g, 'void 0')
src += '\n;globalThis.__T = { setup: exports.setup, action: exports.action, after_card_resolved };'
eval(src)
const T = globalThis.__T

const game = T.setup('seed-17530', 'Standard', {})
game.turn = '美国'
game.active = '美国'

// ---- 17530 端到端：pending_script(jp_facedown_discard) -> resolve_script ----
game.pending_script = {
  kind: 'jp_facedown_discard',
  actor: '美国',
  answer_nation: '美国',
  target_nation: '日本',
  source: '17530',
  source_name: '代号·Magic',
  stage: 1, total: 1, need_pick: 1,
}
game.table_responses = [{ card_id: '15419#1', owner_side: 'axis', nation: '日本' }]
T.action(game, 'Allies', 'resolve_script', { pick: ['15419#1'] })
const r30 = game.national_skill_offer
console.log('[17530] pending_script 清空?', game.pending_script === null,
  '| 暗牌已弃?', !((game.table_responses||[]).some(x => x.card_id === '15419#1')),
  '| offer=', JSON.stringify(r30))

// ---- 17529 / 17531 / 17537：直接验证 after_card_resolved 触发美国★窗口 ----
function check(id) {
  const g = T.setup('seed-' + id, 'Standard', {})
  g.turn = '美国'; g.active = '美国'
  g.national_skill_offer = null
  T.after_card_resolved(g, '美国', id)
  const o = g.national_skill_offer
  console.log('[' + id + '] offer=', JSON.stringify(o),
    '=> nation=' + (o && o.nation) + ' trigger=' + (o && o.trigger))
}
check('17529')
check('17531')
check('17537')

// 对照：14503 提尔比茨号 本身是【德国★卡】，理应触发（德国）国家技能窗口
const g2 = T.setup('seed-14503', 'Standard', {})
g2.turn = '德国'; g2.active = '德国'
g2.national_skill_offer = null
T.after_card_resolved(g2, '德国', '14503')
console.log('[14503 德国★对照] offer=', JSON.stringify(g2.national_skill_offer), '(nation 应为 德国)')
