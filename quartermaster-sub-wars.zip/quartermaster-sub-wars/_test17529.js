/*
 * 17529《摩尔曼斯克运输船队》—— 建设预算改造（2026-10-20）
 *
 * 新机制：步①"在<罗斯>征召"立即执行（不可执行则 autoskip 跳过）；
 * 步②"苏联建设1支陆军"改用【建设预算】(pending_autobahn, source='su_build_delegate')：
 *   · 每次建设走真实 build_piece → 武装 after_build_army（苏联可插入发动本国状态卡）；
 *   · 建设完成【不自动收尾】，预算保留；
 *   · 收尾唯一入口 = 玩家点「结束预算」→ 归还 current_nation='美国' + ★卡 after_card_resolved。
 * 让权主体仍是苏联（切 current_nation，同阵营不翻 active）。
 */
const rules = require('./rules.js')
const I = rules._internal
const D = require('./data.js').data

let ros = null, sea = null
for (let i = 1; i < D.spaces.length; i++) {
	const s = D.spaces[i]
	if (!s) continue
	if (s.name === '罗斯') ros = i
	if (!sea && s.terrain === 'sea') sea = i
}
console.log('罗斯 id =', ros, '| 示例海域 id =', sea)

function countArmy(g, nat) {
	return Object.keys(g.location || {}).filter(p =>
		g.location[p] != null && g.piece_nation[p] === nat && g.piece_type[p] === 'army').length
}

/*
 * 场景1：罗斯被苏联陆军占据 -> 步①征召不可执行 -> autoskip 跳过；
 *        步②建立建设预算 -> 苏联点候选地建设 -> 【预算保留不自动收尾】
 *        -> 点「结束预算」-> 归还美国 + 委托结束日志。
 */
{
	const g = rules.setup('t-17529', 'Standard', {})
	g.current_nation = '美国'; g.active = 'Allies'; g.turn_phase = 'play'
	g.hands['美国'] = ['17529#1']
	g.location['su_a1'] = ros; g.piece_nation['su_a1'] = '苏联'; g.piece_type['su_a1'] = 'army'

	rules.action(g, 'Allies', 'play_card', { card: '17529#1' })
	const cnOffer = g.current_nation
	const skipLogged = (g.log || []).some(l => String(l).includes('自动跳过该步'))
	const pa = g.pending_autobahn
	const budgetOk = !!pa && pa.source === 'su_build_delegate' && pa.actor === '苏联'

	const q = rules.query(g, 'Allies', 'autobahn_targets', {})
	const cands = (q.spaces || [])   /* {id,name} 对象数组 */

	let okBuild = false, okKeep = false, okEnd = false, cnBack = null
	if (budgetOk && cands.length) {
		const before = countArmy(g, '苏联')
		rules.action(g, 'Allies', 'resolve_autobahn', { space: cands[0].id })
		okBuild = countArmy(g, '苏联') === before + 1
		okKeep = !!g.pending_autobahn && g.pending_autobahn.source === 'su_build_delegate'
		rules.action(g, 'Allies', 'finish_su_build_budget', {})
		okEnd = (g.su_build_delegate == null) &&
			(g.log || []).some(l => String(l).includes('委托结束'))
		cnBack = g.current_nation
	}
	const pass = cnOffer === '苏联' && skipLogged && budgetOk && cands.length > 0 &&
		okBuild && okKeep && okEnd && cnBack === '美国'
	console.log('场景1(罗斯被占->跳步①->建预算->建设->预算保留->点结束归还):',
		'挂起国=', cnOffer, '| 跳过=', skipLogged, '| 预算=', budgetOk,
		'| 候选=', cands.length, '| 建设=', okBuild, '| 预算保留=', okKeep,
		'| 收尾=', okEnd, '| 归还=', cnBack, '=>', pass ? 'PASS' : 'FAIL')
}

/*
 * 场景2：罗斯被占 -> 步①跳过 -> 建预算 -> 直接点「结束预算」收尾归还（不死锁）。
 */
{
	const g = rules.setup('t-17529b', 'Standard', {})
	g.current_nation = '美国'; g.active = 'Allies'; g.turn_phase = 'play'
	g.hands['美国'] = ['17529#1']
	g.location['su_a1'] = ros; g.piece_nation['su_a1'] = '苏联'; g.piece_type['su_a1'] = 'army'

	rules.action(g, 'Allies', 'play_card', { card: '17529#1' })
	const cnAfterOffer = g.current_nation
	const skipLogged = (g.log || []).some(l => String(l).includes('自动跳过该步'))
	const pa = g.pending_autobahn
	const budgetOk = !!pa && pa.source === 'su_build_delegate'

	rules.action(g, 'Allies', 'finish_su_build_budget', {})
	const cleared = (g.su_build_delegate == null) && !g.pending_autobahn
	const ended = (g.log || []).some(l => String(l).includes('委托结束'))
	const cnBack = (g.current_nation === '美国')
	const activeOk = (g.active === 'Allies')
	const pass = cnAfterOffer === '苏联' && skipLogged && budgetOk &&
		cleared && ended && cnBack && activeOk
	console.log('场景2(罗斯被占->跳步①->建预算->点结束收尾归还):',
		'挂起国=', cnAfterOffer, '| 跳过=', skipLogged, '| 预算=', budgetOk,
		'| 清除=', cleared, '| 收尾日志=', ended, '| 归还美国=', cnBack,
		'| active仍Allies=', activeOk, '=>', pass ? 'PASS' : 'FAIL')
}
