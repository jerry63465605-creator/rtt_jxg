"use strict"
const fs = require('fs')
const path = require('path')

/* 加载 rules.js 并暴露内部函数（不修改源文件）。
 * 注意：保留 build_map() 以初始化地图（pick_space_then/get_connections 需要）。 */
let src = fs.readFileSync(path.join(__dirname, 'rules.js'), 'utf8')
src += '\n;globalThis.__T = { setup: exports.setup, action: exports.action,' +
	' RESPONSE_EFFECT_IMPL, battle_reconcile_active, response_reconcile_active,' +
	' promote_deferred_response, top_response_frame, push_response_frame, defer_response_frame,' +
	' request_responses, sync_response_queue_view, battle_initiators, clear_armed_offer, removeArmedWindow };'
eval(src)
const T = globalThis.__T
const { data } = require('./data.js')

let pass = true
const log = []
const assert = (name, cond, info) => {
	log.push('[' + name + '] ' + (cond ? 'PASS' : 'FAIL') + (info ? ' :: ' + info : ''))
	if (!cond) pass = false
}
function run(name, fn) {
	try { fn() } catch (e) { assert(name, false, '异常: ' + e.message) }
}

function makeFrame(extra) {
	return {
		card_id: '15425#1', card_face: '15425', name: '海军空降部队',
		owner_side: 'axis', kind: 'option',
		candidates: [{ id: 1, name: '再发起 1 次陆战' }, { id: 0, name: '完成' }],
		prompt: '是否再发起 1 次陆战？', ctx: {}, extra: extra || null,
	}
}

/* ---- T1：battle_reconcile_active 在"无挂起战斗且栈空"时应提升延期帧 ---- */
run('T1', () => {
	const g = T.setup('t15425-1', 'Standard', {})
	g.response_stack = []
	g.pending_battle = null
	g.deferred_response_stack = [makeFrame({ step: 'ask2' })]
	T.battle_reconcile_active(g)
	const promoted = (g.response_stack || []).length === 1 &&
		(g.response_stack[0].extra || {}).step === 'ask2'
	const cleared = (g.deferred_response_stack || []).length === 0
	assert('T1', promoted && cleared,
		'stack=' + (g.response_stack || []).length + ' deferred=' + (g.deferred_response_stack || []).length)
})

/* ---- T2：栈上仍有 on:'battle' 嵌套帧时，battle_reconcile_active 不应抢先提升 ---- */
run('T2', () => {
	const g = T.setup('t15425-2', 'Standard', {})
	g.response_stack = [{
		card_id: '15336#1', card_face: '15336', name: '法兰西爱国者',
		owner_side: 'allies', kind: 'space', candidates: [], prompt: '',
		ctx: {}, extra: null,
	}]
	g.pending_battle = null
	g.deferred_response_stack = [makeFrame({ step: 'ask2' })]
	T.battle_reconcile_active(g)
	const notPromoted = (g.response_stack || []).length === 1 &&
		(g.response_stack[0].card_face === '15336') &&
		(g.deferred_response_stack || []).length === 1
	assert('T2', notPromoted,
		'stack=' + (g.response_stack || []).length + ' top=' +
		((g.response_stack[0] || {}).card_face) + ' deferred=' + (g.deferred_response_stack || []).length)
})

/* ---- T3：有空军代死 pending_battle 时不应抢先提升（等代受结算） ---- */
run('T3', () => {
	const g = T.setup('t15425-3', 'Standard', {})
	g.response_stack = []
	g.pending_battle = { defender_nation: '英国', space: 1 }
	g.deferred_response_stack = [makeFrame({ step: 'ask2' })]
	T.battle_reconcile_active(g)
	const notPromoted = (g.response_stack || []).length === 0 &&
		(g.deferred_response_stack || []).length === 1
	assert('T3', notPromoted,
		'stack=' + (g.response_stack || []).length + ' deferred=' + (g.deferred_response_stack || []).length)
})

/* ---- T4：15425 首调返回 battle1 步（pick_space_then）且 step 标注正确 ---- */
run('T4', () => {
	const g = T.setup('t15425-4', 'Standard', {})
	let ok = false, info = ''
	for (const k of Object.keys(data.spaces)) {
		const sid = Number(k)
		try {
			const r = T.RESPONSE_EFFECT_IMPL['15425'](g, 'axis', { space: sid }, undefined, null)
			if (r && (r.pending || r.candidates) && r.extra && r.extra.step === 'battle1') {
				ok = true; info = 'space=' + sid; break
			}
		} catch (e) { /* 跳过无邻接的空格 */ }
	}
	assert('T4', ok, info || '未找到可解析的相邻空间')
})

/* ---- T5：defer 分支的守卫式提升：无嵌套/无代死时立即恢复"是否再战" ---- */
run('T5', () => {
	const g = T.setup('t15425-5', 'Standard', {})
	g.response_stack = [makeFrame({ step: 'battle1' })]  // 当前 effect 帧（battle1）
	g.deferred_response_stack = [makeFrame({ step: 'ask2' })]
	g.pending_battle = null
	// 复刻 resolve_response_choice 的 defer 分支结尾逻辑
	g.response_stack.pop() // remove_response_frame(pc)：pc 即栈顶
	T.defer_response_frame(g, makeFrame({ step: 'ask2' }))
	if (!g.pending_battle && !T.top_response_frame(g)) T.promote_deferred_response(g)
	const promoted = (g.response_stack || []).length === 1 &&
		(g.response_stack[0].extra || {}).step === 'ask2'
	assert('T5', promoted, 'stack=' + (g.response_stack || []).length)
})

/* ---- T6：response_reconcile_active 的 else 分支提升前须守卫 pending_battle ---- */
run('T6', () => {
	const g = T.setup('t15425-6', 'Standard', {})
	g.response_stack = []
	g.response_queue = []
	g.pending_battle = { defender_nation: '英国', space: 1 }  // 空军代死未结算
	g.deferred_response_stack = [makeFrame({ step: 'ask2' })]
	T.response_reconcile_active(g)
	const notPromoted = (g.response_stack || []).length === 0 &&
		(g.deferred_response_stack || []).length === 1
	assert('T6', notPromoted,
		'stack=' + (g.response_stack || []).length + ' deferred=' + (g.deferred_response_stack || []).length)
})

run('T7', () => {
	const g = T.setup('t15425-7', 'Standard', {})
	g.response_stack = []
	g.response_queue = []
	g.pending_battle = null
	g.deferred_response_stack = [makeFrame({ step: 'ask2' })]
	T.response_reconcile_active(g)
	const promoted = (g.response_stack || []).length === 1 &&
		(g.response_stack[0].extra || {}).step === 'ask2' &&
		(g.deferred_response_stack || []).length === 0
	assert('T7', promoted,
		'stack=' + (g.response_stack || []).length + ' deferred=' + (g.deferred_response_stack || []).length)
})

/* ---- T8：真实 action 链路——defer 后派生队列视图不得残留幽灵触发项（2026-10-20 修复） ----
 * 症状复盘（game 21）：resolve_response_choice 的 defer 分支移除栈帧但未 sync_response_queue_view，
 * game.response_queue 残留 on:'build' 的 15425 触发项 → ①日本 view.pending_trigger 渲染幽灵
 * "是否发动"框（点发动/不发动因栈空空转）；②全局动作闸门见非空队列拦下美国 resolve_battle
 * （空军代死应答）→ 双方卡死。本用例走真实 request_responses → trigger_response →
 * resolve_response_choice 链路，断言 defer 后队列已清空。 */
run('T8', () => {
	const g = T.setup('t15425-8', 'Standard', {})
	g.current_nation = '日本'
	g.active = 'Axis'
	g.turn_phase = 'play'
	/* 桌面只摆 15425，避免其它 on:'build' 卡混入组 */
	g.table_responses = [{ card_id: '15425#1', owner_side: 'axis', nation: '日本' }]
	/* 动态探测摆位（不硬编码地理）：候选陆地 X = 49 的相邻陆地（与 effect 候选同源），
	 * 需满足：美军陆军+空军驻 X（有被移除目标 + 空军代死），且 X 相邻海 S 上
	 * 一支日本海军处于补给态（battle_initiators 非空，探测时逐海挪动验证）。 */
	const pick = T.RESPONSE_EFFECT_IMPL['15425'](g, 'axis', { space: 49 }, undefined, null)
	const cands = (pick.candidates || []).map(c => (c && c.id != null) ? c.id : c)
	const seas = allSeaIds()
	let spot = null
	for (const X of cands) {
		for (const S of seas) {
			if (data.spaces[X].connections.indexOf(S) < 0) continue
			const sg = T.setup('probe_' + X + '_' + S, 'Standard', {})
			sg.current_nation = '日本'; sg.active = 'Axis'; sg.turn_phase = 'play'
			sg.location['p90'] = S; sg.piece_nation['p90'] = '日本'; sg.piece_type['p90'] = 'navy'
			sg.location['p91'] = X; sg.piece_nation['p91'] = '美国'; sg.piece_type['p91'] = 'army'
			sg.location['p92'] = X; sg.piece_nation['p92'] = '美国'; sg.piece_type['p92'] = 'air'
			const ini = T.battle_initiators(sg, '日本', X)
			if (ini && ini.length) { spot = { X, S }; break }
		}
		if (spot) break
	}
	assert('T8p', !!spot, 'cands=' + JSON.stringify(cands) + ' spot=' + JSON.stringify(spot))
	if (!spot) return
	const { X, S } = spot
	g.location['p33'] = S; g.piece_nation['p33'] = '日本'; g.piece_type['p33'] = 'navy'
	g.location['p29'] = X; g.piece_nation['p29'] = '美国'; g.piece_type['p29'] = 'army'
	g.location['p38'] = X; g.piece_nation['p38'] = '美国'; g.piece_type['p38'] = 'air'
	/* 引擎真实路径：建设海军触发 build 响应 → 压 15425 触发帧（内部 sync 队列） */
	const m = T.request_responses(g, 'build', { type: 'navy', nation: '日本', space: 49 })
	assert('T8a', m && m.length === 1 && (g.response_queue || []).length === 1,
		'matched=' + (m || []).length + ' queue=' + (g.response_queue || []).length)
	/* 发动响应 → effect 首调返回选地区 pending 帧 */
	exports.action(g, 'Axis', 'trigger_response', {})
	const top1 = T.top_response_frame(g)
	const candIds1 = ((top1 || {}).candidates || []).map(c => (c && c.id != null) ? c.id : c)
	assert('T8b', top1 && top1.pending && candIds1.indexOf(X) >= 0,
		'pending=' + !!(top1 && top1.pending) + ' cands=' + JSON.stringify(candIds1) + ' X=' + X)
	/* 选 X 发起第一次陆战 → 美国空军代死 pending_battle → effect 返回 defer：
	 * 修复前 game.response_queue 残留触发项（=1），修复后必须为 0 */
	exports.action(g, 'Axis', 'resolve_response_choice', { choice: X })
	const queueClean = (g.response_queue || []).length === 0
	const deferredOk = (g.deferred_response_stack || []).length === 1 &&
		(((g.deferred_response_stack || [])[0] || {}).extra || {}).step === 'ask2'
	assert('T8c', queueClean && deferredOk && !!g.pending_battle,
		'queue=' + (g.response_queue || []).length +
		' deferred=' + (g.deferred_response_stack || []).length +
		' pb=' + !!(g.pending_battle && g.pending_battle.stage))
})

function allSeaIds() {
	const out = []
	for (const k of Object.keys(data.spaces)) {
		const sp = data.spaces[k]
		if (sp.terrain === 'sea') out.push(Number(k))
	}
	return out
}

/* ---- T9：15311(armed 英国) + 15336(on:'battle' 英国) 同场时，15311 结算后
 *       15425 续打帧应被提升为栈顶、active 归还日本（窗门不丢） ---- */
run('T9', () => {
	const g = T.setup('t15425-9', 'Standard', {})
	// 15336 on:'battle' 响应帧（英国持有），已 handoff 给英国
	g.response_stack = [{
		card_id: '15336#1', card_face: '15336', name: '法兰西爱国者',
		owner_side: 'allies', kind: 'space', candidates: [], prompt: '',
		ctx: {}, extra: null,
	}]
	// 15311 armed 窗口（英国持有）已 handoff 给英国
	g.handoff_stack = [
		{ id: 'response', return_active: 'Axis', holder_role: 'Allies' },
		{ id: 'armed', return_active: 'Axis', holder_role: 'Allies' },
	]
	g.active = 'Allies'
	g._handoff_base = 'Axis'
	g.pending_battle = null
	g.battle_in_progress = 0
	// 15425 续打帧已 defer
	g.deferred_response_stack = [makeFrame({ step: 'ask2' })]
	// 模拟 15311 结算：清空 armed 窗口
	T.clear_armed_offer(g)
	const stack = g.response_stack || []
	const top = stack[stack.length - 1]
	const topIs15425 = stack.length === 2 &&
		(top.extra || {}).step === 'ask2' && top.owner_side === 'axis'
	const baseRestored = g.active === 'Axis'
	assert('T9', topIs15425 && baseRestored,
		'stack=' + stack.length + ' top=' + ((top || {}).card_face) +
		' step=' + JSON.stringify((top || {}).extra) + ' active=' + g.active)
})

/* ---- T9b：用真实大小写（holder_role='Allies' 大写、active='Allies'、owner_side='axis' 小写）
 *       验证 promote 在真实约定下能把 active 翻回日本（'Axis'）。 ---- */
run('T9b', () => {
	const g = T.setup('t15425-9b', 'Standard', {})
	g.response_stack = [{
		card_id: '15336#1', card_face: '15336', name: '法兰西爱国者',
		owner_side: 'allies', kind: 'space', candidates: [], prompt: '',
		ctx: {}, extra: null,
	}]
	g.handoff_stack = [
		{ id: 'response', return_active: 'Axis', holder_role: 'Allies' },
		{ id: 'armed', return_active: 'Axis', holder_role: 'Allies' },
	]
	g.active = 'Allies'
	g._handoff_base = 'Axis'
	g.pending_battle = null
	g.battle_in_progress = 0
	g.deferred_response_stack = [makeFrame({ step: 'ask2' })] // owner 'axis'
	T.clear_armed_offer(g)
	const stack = g.response_stack || []
	const top = stack[stack.length - 1]
	const topIs15425 = stack.length === 2 &&
		(top.extra || {}).step === 'ask2' && top.owner_side === 'axis'
	const baseRestored = g.active === 'Axis'
	assert('T9b', topIs15425 && baseRestored,
		'stack=' + stack.length + ' top=' + ((top || {}).card_face) +
		' step=' + JSON.stringify((top || {}).extra) + ' active=' + g.active)
})

/* ---- T11：仅 armed 卡（15311）触发、无 response/代死帧时，armed 窗口清空（removeArmedWindow）
 *       应把 15425 续打帧提升为栈顶、active 归还日本。此前该路径无 promote → 窗口丢失。 ---- */
run('T11', () => {
	const g = T.setup('t15425-11', 'Standard', {})
	g.response_stack = [] // 无 on:'battle' 响应帧
	g.handoff_stack = [
		{ id: 'armed', return_active: 'Axis', holder_role: 'Allies' },
	]
	g.active = 'Allies'
	g._handoff_base = 'Axis'
	g.pending_battle = null
	g.battle_in_progress = 0
	g.deferred_response_stack = [makeFrame({ step: 'ask2' })] // owner 'axis'
	const win = { when: 'piece_removed', nation: '英国', cards: [{ card_id: '15311#1' }], arg: undefined, pending: null }
	g.armed_offers = [win]
	T.removeArmedWindow(g, win)
	const stack = g.response_stack || []
	const top = stack[stack.length - 1]
	const ok = stack.length === 1 &&
		(top.extra || {}).step === 'ask2' && top.owner_side === 'axis' && g.active === 'Axis'
	assert('T11', ok,
		'stack=' + stack.length + ' top=' + ((top || {}).card_face) +
		' step=' + JSON.stringify((top || {}).extra) + ' active=' + g.active)
})

/* ---- T12：armed(15311) + response(15336) 同场，armed 先清空时因 top_response_frame 守卫
 *       暂不提升 15425，留待 15336 结算后再提升（顺序正确、不被盖住）。 ---- */
run('T12', () => {
	const g = T.setup('t15425-12', 'Standard', {})
	g.response_stack = [{
		card_id: '15336#1', card_face: '15336', name: '法兰西爱国者',
		owner_side: 'allies', kind: 'space', candidates: [], prompt: '',
		ctx: {}, extra: null,
	}]
	g.handoff_stack = [
		{ id: 'response', return_active: 'Axis', holder_role: 'Allies' },
		{ id: 'armed', return_active: 'Axis', holder_role: 'Allies' },
	]
	g.active = 'Allies'
	g._handoff_base = 'Axis'
	g.pending_battle = null
	g.battle_in_progress = 0
	g.deferred_response_stack = [makeFrame({ step: 'ask2' })] // owner 'axis'
	const win = { when: 'piece_removed', nation: '英国', cards: [{ card_id: '15311#1' }], arg: undefined, pending: null }
	g.armed_offers = [win]
	T.removeArmedWindow(g, win)
	const top = (g.response_stack || [])[(g.response_stack || []).length - 1]
	const staysDeferred = (g.deferred_response_stack || []).length === 1 && // 15425 仍滞留
		(top || {}).card_face !== '15425'
	assert('T12', staysDeferred,
		'deferred=' + (g.deferred_response_stack || []).length + ' top=' + ((top || {}).card_face) + ' active=' + g.active)
})

console.log(log.join('\n'))
console.log('\n=== 总结论 ===', pass ? 'PASS（15425 defer 恢复机制 9/9 通过）' : 'FAIL')
process.exit(pass ? 0 : 1)
