const rules = require('./rules.js')
const I = rules._internal
const D = require('./data.js').data

function firstBuildable(game, nation) {
	for (let i = 1; i < D.spaces.length; i++)
		if (I.can_build_at(game, nation, i, 'army').ok) return i
	return null
}
function countArmy(game, nation) {
	return Object.keys(game.location).filter(p => game.piece_nation[p] === nation && game.piece_type[p] === 'army').length
}
function runGuard(game, space) {
	// 近卫军是 STATUS(play_start)；直接驱动其 trigger.run（cost.discard=2 由框架在 run 前扣，此处只测 run 的真实打出）
	return I.STATUS_EFFECTS['17841'].trigger.run(game, { nation: '苏联', arg: { space: space }, ctx: {} })
}

/*
 * 场景A：无 17844、桌面有 17847 消耗战 -> 近卫军真实打出[建设陆军]：build + 该卡进弃牌堆 + 17847 计分(axis +1)。
 */
{
	const g = rules.setup('t-17841a', 'Standard', {})
	g.current_nation = '苏联'; g.active = 'Axis'; g.turn_phase = 'play'
	g.discard['苏联'] = ['17800#1']          // 弃牌堆一张[建设陆军]
	g.table['苏联'] = ['17847#1']            // 桌面：消耗战
	g.status_used = {}
	const scoreBefore = g.score['allies'] || 0   // 苏联=allies(同盟国)
	const armyBefore = countArmy(g, '苏联')
	const sp = firstBuildable(g, '苏联')
	const r = runGuard(g, sp)
	const inDiscard = (g.discard['苏联'] || []).includes('17800#1')
	const scoreAfter = g.score['allies'] || 0
	const pass = r.ok && inDiscard && scoreAfter === scoreBefore + 1 && countArmy(g, '苏联') === armyBefore + 1
	console.log('场景A(无17844/有17847->真实打出+17847计分): r.ok=', r.ok,
		'| 建设陆军进弃牌堆=', inDiscard, '| allies分+1=', scoreAfter === scoreBefore + 1,
		'| 陆军+1=', countArmy(g, '苏联') === armyBefore + 1, '=>', pass ? 'PASS' : 'FAIL',
		r.ok ? '' : (' reason=' + r.reason))
}

/*
 * 场景B：桌面有 17844 女性义务兵役 -> 真实打出：17844 置回手牌(早于 build)、build、不进弃牌堆(不触发 17847)。
 */
{
	const g = rules.setup('t-17841b', 'Standard', {})
	g.current_nation = '苏联'; g.active = 'Axis'; g.turn_phase = 'play'
	g.discard['苏联'] = ['17800#1']
	g.table['苏联'] = ['17844#1']            // 桌面：女性义务兵役
	const armyBefore = countArmy(g, '苏联')
	const sp = firstBuildable(g, '苏联')
	const r = runGuard(g, sp)
	const inHand = (g.hands['苏联'] || []).includes('17800#1')     // 置回手牌
	const inDiscard = (g.discard['苏联'] || []).includes('17800#1')
	const logs = g.log || []
	const iRecycle = logs.findIndex(l => String(l).includes('置回手牌'))
	// 时序(17844 早于 after_build_army/17846)由代码结构保证：recycle 置回手牌在 resolve_basic_card(build) 之前
	// (play_build_army_from：recycle push 在 resolve_basic_card 前)，此处验证 recycle 生效 + build。
	const pass = r.ok && inHand && !inDiscard && countArmy(g, '苏联') === armyBefore + 1 && iRecycle >= 0
	console.log('场景B(有17844->置回手牌+早于build[结构保证]): r.ok=', r.ok,
		'| 置回手牌=', inHand, '| 不在弃牌堆=', !inDiscard,
		'| 陆军+1=', countArmy(g, '苏联') === armyBefore + 1,
		'| 17844已生效=', iRecycle >= 0, '=>', pass ? 'PASS' : 'FAIL',
		r.ok ? '' : (' reason=' + r.reason))
}
