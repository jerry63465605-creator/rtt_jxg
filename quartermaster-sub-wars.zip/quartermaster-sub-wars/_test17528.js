const rules = require('./rules.js')
const I = rules._internal

/* 美国★卡（含挂起类）在"完成结算"时调用 after_card_resolved(美国, id)，
 * 只要国家技能 usable（牌库可损耗 + 手牌有状态卡可打），就应弹出美国国家技能窗口。 */

/* 17535 租借法案：选委托国后 return_nation 应被 set_pending_delegate 补成'美国' */
const g = rules.setup('t-ll', 'Standard', {})
g.turn_phase = 'play'
g.current_nation = '美国'
g.active = 'Allies'                 // 对齐回合态：美国(Allies)回合
g.hands['美国'] = ['17553#1', '17554#2']
I.offer_us_lend_lease(g, '17535')
rules.action(g, 'Allies', 'resolve_us_lend_lease_select', { nation: '苏联' })
console.log('17535 选委托后 return_nation =', g.delegate.return_nation, '(应 美国) =>', g.delegate.return_nation === '美国')

/* 逐个★卡：after_card_resolved(美国, id) 是否弹美国国家技能 */
console.log('\n各美国★卡 after_card_resolved(美国, id) 弹技能情况：')
const starred = {
  '17520': 'ECON', '17523': 'ECON',
  '17526': '委托英国(挂起)', '17529': '委托苏联(挂起)', '17530': '脚本(挂起)',
  '17531': '现购自运', '17535': '租借法案(委托挂起)', '17536': 'EVENT',
  '17537': '美帮中', '17553': 'STATUS', '17554': 'STATUS', '16304': 'STATUS(委托挂起)',
}
let allOk = true
for (const id of Object.keys(starred)) {
  const gg = rules.setup('t-' + id, 'Standard', {})
  gg.turn_phase = 'play'
  gg.hands['美国'] = ['17553#1', '17554#2']   // 保证 usable
  gg.national_skill_offer = null
  I.after_card_resolved(gg, '美国', id)
  const ok = !!(gg.national_skill_offer && gg.national_skill_offer.nation === '美国')
  if (!ok) allOk = false
  console.log('  ' + id, '(' + starred[id] + ')', '=>', ok ? '弹技能' : '未弹')
}
console.log('\n全部可弹美国国家技能 ?', allOk)
