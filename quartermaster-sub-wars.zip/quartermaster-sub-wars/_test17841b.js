const rules = require('./rules.js')
const I = rules._internal
const D = require('./data.js').data

function firstBuildable(game, nation) {
	for (let i = 1; i < D.spaces.length; i++)
		if (I.can_build_at(game, nation, i, 'army').ok) return i
	return null
}
function countArmy(game, nation) {
	return Object.keys(game.location).filter(p => game.piece_nation[p] === nation && game.piece_type[p] === 'army').length
}

// 走【真实 activate_status 链路】(含 cost.discard 扣除 + status_window_ready)，复现"弃牌后无建设"
const g = rules.setup('t-17841b', 'Standard', {})
g.current_nation = '苏联'; g.active = 'Allies'; g.turn_phase = 'play'
g.table['苏联'] = ['17841#1']          // 桌面：近卫军
g.discard['苏联'] = ['17800#1']        // 弃牌堆已有[建设陆军](前置闸门)
g.status_used = {}
const hand = (g.hands['苏联'] || []).slice()
const disc = [hand[0], hand[1]]        // 付 cost.discard=2 的 2 张手牌
const armyBefore = countArmy(g, '苏联')
const sp = firstBuildable(g, '苏联')
console.log('before: 手牌=', hand.length, '| 弃牌堆=', JSON.stringify(g.discard['苏联']),
	'| 建设地=', sp, '| 苏联陆军=', armyBefore)

const q = rules.query(g, 'Allies', 'status_build_spaces', { card: '17841#1', nation: '苏联', type: 'army' })
console.log('query status_build_spaces =', JSON.stringify(q))
rules.action(g, 'Allies', 'activate_status', { card: '17841#1', space: sp, discard: disc })

console.log('after: 苏联陆军=', countArmy(g, '苏联'), '(应', armyBefore + 1, ')')
console.log('  手牌=', JSON.stringify(g.hands['苏联']))
console.log('  弃牌堆=', JSON.stringify(g.discard['苏联']))
console.log('  log尾=', JSON.stringify((g.log || []).slice(-6)))
const okBuild = countArmy(g, '苏联') === armyBefore + 1
const okSkip = !!(g.skip_play_done && g.skip_play_done['苏联'] === g.turn)   // 占用/跳过后本回合出牌阶段
console.log('activate_status 近卫军链路 => 建设?', okBuild, '| 占出牌阶段(skip_play)?', okSkip,
	'=>', (okBuild && okSkip) ? 'PASS' : 'FAIL')
