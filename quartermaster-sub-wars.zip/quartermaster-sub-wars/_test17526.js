const rules = require('./rules.js')
const I = rules._internal
const D = require('./data.js').data

/*
 * 17526 民主兵工厂：挂起给【真正的英国】（切 current_nation='英国'，it_delegate 同阵营让权范式）。
 * 英国与美国同属 Allies，active 不翻，靠 current_nation 承载"该英国执行"——本次建设以英国为主体
 * （触发英国状态卡），6 人模式下英国玩家也能收到。view.uk_build_delegate.candidates 为 {id,type}。
 *
 * 场景1：正常流程 —— offer 后 current_nation='英国'；依次建海军/陆军，自动跳过无候选兵种，收尾后归还美国。
 */
{
	const g = rules.setup('t-17526', 'Standard', {})
	g.current_nation = '美国'; g.active = 'Allies'; g.turn_phase = 'play'
	g.hands['美国'] = ['17526#1']

	rules.action(g, 'Allies', 'play_card', { card: '17526#1' })
	const dg = g.uk_build_delegate
	const cnOffer = g.current_nation                 // 应='英国'
	const v = rules.view(g, 'Allies')
	const cands = (v.uk_build_delegate && v.uk_build_delegate.candidates) || []

	let okFinish = false, cnBack = null
	if (dg && cands.length) {
		const first = cands[0]
		rules.action(g, 'Allies', 'resolve_uk_build_delegate', { space: first.id, build: first.type })
		// 若还剩另一兵种且有候选，继续建
		const v2 = rules.view(g, 'Allies')
		const cands2 = (v2.uk_build_delegate && v2.uk_build_delegate.candidates) || []
		if (g.uk_build_delegate && cands2.length) {
			const second = cands2.find(c => c.type !== first.type) || cands2[0]
			rules.action(g, 'Allies', 'resolve_uk_build_delegate', { space: second.id, build: second.type })
		}
		okFinish = (g.uk_build_delegate == null) && (g.log || []).some(l => String(l).includes('委托结束'))
		cnBack = g.current_nation
	}
	const pass = dg && cnOffer === '英国' && okFinish && cnBack === '美国'
	console.log('场景1(正常建海军+陆军->归还): 挂起国=', cnOffer, '| 初始候选=', cands.length,
		'| 收尾=', okFinish, '| 归还=', cnBack, '=>', pass ? 'PASS' : 'FAIL')
}

/*
 * 场景2：无可建/已跳过导致 remaining 空 -> autoskip 收尾，current_nation 归还美国、active 仍 Allies。
 */
{
	const g = rules.setup('t-17526b', 'Standard', {})
	g.current_nation = '美国'; g.active = 'Allies'; g.turn_phase = 'play'
	g.hands['美国'] = ['17526#1']
	rules.action(g, 'Allies', 'play_card', { card: '17526#1' })
	const cnOffer = g.current_nation                 // 应='英国'
	if (g.uk_build_delegate) {
		g.uk_build_delegate.remaining = []           // 模拟两步均已跳过/无可建
		I.uk_build_autoskip(g)
		const cleared = (g.uk_build_delegate == null)
		const cnBack = (g.current_nation === '美国')
		const activeOk = (g.active === 'Allies')
		console.log('场景2(remaining空->收尾归还): 挂起国=', cnOffer, '| 清除=', cleared,
			'| 归还=', cnBack, '| active仍Allies=', activeOk,
			'=>', (cleared && cnBack && activeOk && cnOffer === '英国') ? 'PASS' : 'FAIL')
	} else {
		console.log('场景2: (offer 时即无可建) delegate =', g.uk_build_delegate, '| current=', g.current_nation)
	}
}
